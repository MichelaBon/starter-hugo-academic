# ---------------------------------------------------------------------------
# Paths: run this script from the replication package root, e.g.
#   Rscript R/Main_Analysis.R
# Data are read from the DATA folder (default "data"). To run on the synthetic
# data instead:  REPLICATION_DATA=data_synthetic Rscript R/Main_Analysis.R
# Tables (.tex) are written to the "output" folder.
# ---------------------------------------------------------------------------
DATA <- Sys.getenv("REPLICATION_DATA", "data")
OUT  <- "output"
dir.create(OUT, showWarnings = FALSE)

####ANALYSIS ON SEP VS NON-SEPS GROUP 1 AND 2

# Load libraries
library(data.table)
library(fixest)
library(car)       
library(lmtest)   
library(sandwich)  


# Load and prepare data 
df <- fread(file.path(DATA, "data da usare/final_lag1_TECHall543.csv"))

# Create grouping variables
df[, group_country := .GRP, by = loc]
df[, group_industryFE := .GRP, by = naics]
df[, firms_fe := .GRP, by = company_id]
df[, std_fe := .GRP, by = standard_family1]
df[, firms_std_fe := .GRP, by = .(company_id, standard_family1)]
df[, group_Sage := .GRP, by = Sage]

# Create transformed variables
df[, logsephld := log(sep_hld_TOTF + 1)]
df[, logdocid := log(doc_idn + 1)]
df[, loge := log(E + 1)]
df[, logsale := logSALE]

# Create quartiles based on tech_before
df[, quant := cut(TECH_before, 
                 breaks = quantile(TECH_before, probs = 0:4/4, na.rm = TRUE),
                 labels = FALSE, include.lowest = TRUE)]

df[, quart_tech_u := fcase(
  quant == 1, 0.25,
  quant == 2, 0.50,
  quant == 3, 0.75,
  quant == 4, 1.00
)]

df[, treat1 := (1 - quart_tech_u) + 0.25]
df[, treatt := 1 - TECH_before]
df[, treattt := 1 - TECH_before_var]

# Time variables
df[, post := fifelse(year > 2014, 1L, 0L)]
df[, post_antic := fifelse(year == 2014, 1L, 0L)]

# Create treatment groups
df[, group_treatment := fcase(
  treat1 == 0.25, 1L,
  treat1 == 0.50, 2L,
  treat1 == 0.75, 3L,
  treat1 == 1.00, 4L
)]



# Filter for groups 1 and 2 only
df_q12 <- df[group_treatment %in% c(1, 2)]

# Center standard age 
df_q12[, sage_cont := group_Sage - median(group_Sage)]

# Create the three comparison datasets

# Comparison 1: Within group 1 only
df_comp1 <- df_q12[group_treatment == 1]
df_comp1[, treatment := TREAT_declaring]  # TREAT_declaring=0 vs TREAT_declaring=1

# Comparison 2: Group 1 (TREAT_declaring=0) vs Group 2 (TREAT_declaring=0)
df_comp2 <- df_q12[(group_treatment == 1 & TREAT_declaring == 0) | 
                   (group_treatment == 2 & TREAT_declaring == 0)]
df_comp2[, treatment := fifelse(group_treatment == 2, 1L, 0L)]

# Comparison 3: Group 1 (TREAT_declaring=0) vs Group 2 (TREAT_declaring=1)
df_comp3 <- df_q12[(group_treatment == 1 & TREAT_declaring == 0) | 
                   (group_treatment == 2 & TREAT_declaring == 1)]
df_comp3[, treatment := fifelse(group_treatment == 2, 1L, 0L)]

###Post only

# Function to run the DiD model
run_did_model1 <- function(data) {
  fepois(
    patn_ws ~ 
      # DiD terms (policy effects)
      treatment:post +
      
      # Main effects
       post + treatment +
      
      # Group-specific trends by standard age
      i(treatment):sage_cont +
      
      # Controls
      treattt + logsale + logsephld + logdocid + 
      i(group_Sage) |
      
      # Fixed effects
      std_fe + firms_fe,
    
    data = data,
    vcov = ~firms_std_fe
  )
}

# Run models for all three comparisons
model_comp1_post <- run_did_model1(df_comp1)  # Within group 1: SEP vs non-SEP
model_comp2_post <- run_did_model1(df_comp2)  # Group1 non-SEP vs Group2 non-SEP
model_comp3_post <- run_did_model1(df_comp3)  # Group1 non-SEP vs Group2 SEP

# Summarize results
summary(model_comp1_post)
summary(model_comp2_post)
summary(model_comp3_post)



###Anticipation Effect
# Function to run the DiD model
run_did_model <- function(data) {
  fepois(
    patn_ws ~ 
      # DiD terms (policy effects)
      treatment:post_antic + 
      treatment:post +
      
      # Main effects
      post_antic + post + treatment +
      
      # Group-specific trends by standard age
      i(treatment):sage_cont +
      
      # Controls
      treattt + logsale + logsephld + logdocid + 
      i(group_Sage) |
      
      # Fixed effects
      std_fe + firms_fe,
    
    data = data,
    vcov = ~firms_std_fe
  )
}

# Run models for all three comparisons
model_comp1 <- run_did_model(df_comp1)  # Within group 1: SEP vs non-SEP
model_comp2 <- run_did_model(df_comp2)  # Group1 non-SEP vs Group2 non-SEP
model_comp3 <- run_did_model(df_comp3)  # Group1 non-SEP vs Group2 SEP

# Summarize results
summary(model_comp1)
summary(model_comp2)
summary(model_comp3)


# F-test for joint significance of post-period coefficients across comparisons
library(car)

# Extract coefficients and VCOV matrices
coefs <- c(
  coef(model_comp1)["post:treatment"],
  coef(model_comp2)["post:treatment"],
  coef(model_comp3)["post:treatment"]
)

vcovs <- list(
  vcov(model_comp1, cluster = ~firms_std_fe)["post:treatment", "post:treatment"],
  vcov(model_comp2, cluster = ~firms_std_fe)["post:treatment", "post:treatment"],
  vcov(model_comp3, cluster = ~firms_std_fe)["post:treatment", "post:treatment"]
)

# Create block-diagonal VCOV matrix
library(Matrix)
all_vcov <- bdiag(vcovs)

# Test equality of post-period effects across comparisons
R <- rbind(
  c(1, -1, 0),  # comp1 = comp2
  c(1, 0, -1)   # comp1 = comp3
)

wald_test <- linearHypothesis(
  model = NULL,
  hypothesis.matrix = R,
  rhs = rep(0, nrow(R)),
  coef. = coefs,
  vcov. = all_vcov,
  test = "F"
)

print(wald_test)

# Function to extract coefficients 
extract_sep_coefs <- function(model, coef_type = "post") {
  tryCatch({
    if (is.null(model)) {
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_names <- names(coef(model))
    
    if (coef_type == "post") {
      # Look for post coefficient
      target_coef <- coef_names[grepl("treatment:post$|post:treatment$", coef_names)]
    } else if (coef_type == "antic") {
      # Look for anticipation coefficient
      target_coef <- coef_names[grepl("treatment:post_antic|post_antic:treatment", coef_names)]
    }
    
    if (length(target_coef) == 0) {
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_name <- target_coef[1]
    vcov_matrix <- vcov(model, cluster = ~firms_std_fe)
    std_error <- sqrt(vcov_matrix[coef_name, coef_name])
    
    return(data.frame(
      estimate = coef(model)[coef_name],
      std_error = std_error
    ))
  }, error = function(e) {
    return(data.frame(estimate = NA, std_error = NA))
  })
}

# Function to format coefficients with line break
format_coef_multiline <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) return(" & \\\\\n")
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ \\\\\n & ", se_formatted, " \\\\\n")
}

# Function to format coefficients for table
format_coef_table <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) return(" & ")
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ & ", se_formatted)
}

# Extract coefficients from all models
sep_results <- list()

# Post-only models
sep_results$comp1_post <- extract_sep_coefs(model_comp1_post, "post")
sep_results$comp2_post <- extract_sep_coefs(model_comp2_post, "post")
sep_results$comp3_post <- extract_sep_coefs(model_comp3_post, "post")

# Anticipation models
sep_results$comp1_antic <- extract_sep_coefs(model_comp1, "antic")
sep_results$comp2_antic <- extract_sep_coefs(model_comp2, "antic")
sep_results$comp3_antic <- extract_sep_coefs(model_comp3, "antic")
sep_results$comp1_post_antic <- extract_sep_coefs(model_comp1, "post")
sep_results$comp2_post_antic <- extract_sep_coefs(model_comp2, "post")
sep_results$comp3_post_antic <- extract_sep_coefs(model_comp3, "post")

# Create table content
table_content <- ""

# Anticipation-Period section
table_content <- paste0(table_content, " Anticipation-Period &&\\\\\n")

# 1st Quartile - SEP Holders (Comparison 1: Within group 1)
antic_comp1 <- format_coef_multiline(
  sep_results$comp1_antic$estimate,
  sep_results$comp1_antic$std_error
)
table_content <- paste0(table_content, " & 1st Quartile - SEP Holders", antic_comp1)

# 2nd Quartile - Non SEP Holders (Comparison 2: Group1 non-SEP vs Group2 non-SEP)
antic_comp2 <- format_coef_multiline(
  sep_results$comp2_antic$estimate,
  sep_results$comp2_antic$std_error
)
table_content <- paste0(table_content, " & 2nd Quartile - Non SEP Holders", antic_comp2)

# 2nd Quartile - SEP Holders (Comparison 3: Group1 non-SEP vs Group2 SEP)
antic_comp3 <- format_coef_multiline(
  sep_results$comp3_antic$estimate,
  sep_results$comp3_antic$std_error
)
table_content <- paste0(table_content, " & 2nd Quartile - SEP Holders", antic_comp3)

table_content <- paste0(table_content, "&&&&&&\\\\\n")

# Post-Period section
table_content <- paste0(table_content, " Post-Period &&\\\\\n")

# 1st Quartile - SEP Holders (Comparison 1: Within group 1)
post_comp1 <- format_coef_table(
  sep_results$comp1_post$estimate,
  sep_results$comp1_post$std_error
)
post_antic_comp1 <- format_coef_table(
  sep_results$comp1_post_antic$estimate,
  sep_results$comp1_post_antic$std_error
)
table_content <- paste0(table_content, " & 1st Quartile - SEP Holders", post_comp1, post_antic_comp1, "\\\\\n")

# 2nd Quartile - Non SEP Holders (Comparison 2: Group1 non-SEP vs Group2 non-SEP)
post_comp2 <- format_coef_table(
  sep_results$comp2_post$estimate,
  sep_results$comp2_post$std_error
)
post_antic_comp2 <- format_coef_table(
  sep_results$comp2_post_antic$estimate,
  sep_results$comp2_post_antic$std_error
)
table_content <- paste0(table_content, " & 2nd Quartile - Non SEP Holders", post_comp2, post_antic_comp2, "\\\\\n")

# 2nd Quartile - SEP Holders (Comparison 3: Group1 non-SEP vs Group2 SEP)
post_comp3 <- format_coef_table(
  sep_results$comp3_post$estimate,
  sep_results$comp3_post$std_error
)
post_antic_comp3 <- format_coef_table(
  sep_results$comp3_post_antic$estimate,
  sep_results$comp3_post_antic$std_error
)
table_content <- paste0(table_content, " & 2nd Quartile - SEP Holders", post_comp3, post_antic_comp3, "\\\\\n")

# Create the complete LaTeX table
latex_table <- paste0(
"\\begin{table}[t]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Effect of IEEE policy change on SEPs holders}
\\label{tab:diff3} 
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{3}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{Standard-related Patents}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3}& & (1) & (2)  \\\\\t 
\\midrule\n",
table_content,
"\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: The dependent variable is the weighted number of patents per firm-standard. The method of estimation is maximum likelihood for the Poisson
model. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard. \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print the table
cat(latex_table)

# Write to file
writeLines(latex_table, file.path(OUT, "sep_analysis_table.tex"))


###Non-standard-related patents

###Anticipation Effect
# Function to run the DiD model
run_did_model_ns <- function(data) {
  fepois(
    patNS ~ 
      # DiD terms (policy effects)
      treatment:post_antic + 
      treatment:post +
      
      # Main effects
      post_antic + post + treatment +
      
      # Group-specific trends by standard age
      i(treatment):sage_cont +
      
      # Controls
      treattt + logsale + logsephld + logdocid + 
      i(group_Sage) |
      
      # Fixed effects
      std_fe + firms_fe,
    
    data = data,
    vcov = ~firms_std_fe
  )
}

# Run models for all three comparisons
model_comp1_ns <- run_did_model_ns(df_comp1)  # Within group 1: SEP vs non-SEP
model_comp2_ns <- run_did_model_ns(df_comp2)  # Group1 non-SEP vs Group2 non-SEP
model_comp3_ns <- run_did_model_ns(df_comp3)  # Group1 non-SEP vs Group2 SEP

# Summarize results
summary(model_comp1_ns)
summary(model_comp2_ns)
summary(model_comp3_ns)


###total patenting as the dependent variable

# Function to run the DiD model
run_did_model_tot <- function(data) {
  fepois(
    patTOT ~ 
      # DiD terms (policy effects)
      treatment:post_antic + 
      treatment:post +
      
      # Main effects
      post_antic + post + treatment +
      
      # Group-specific trends by standard age
      i(treatment):sage_cont +
      
      # Controls
      treattt + logsale + logsephld + logdocid + 
      i(group_Sage) |
      
      # Fixed effects
      std_fe + firms_fe,
    
    data = data,
    vcov = ~firms_std_fe
  )
}

# Run models for all three comparisons
model_comp1_tot <- run_did_model_tot(df_comp1)  # Within group 1: SEP vs non-SEP
model_comp2_tot <- run_did_model_tot(df_comp2)  # Group1 non-SEP vs Group2 non-SEP
model_comp3_tot <- run_did_model_tot(df_comp3)  # Group1 non-SEP vs Group2 SEP

# Summarize results
summary(model_comp1_tot)
summary(model_comp2_tot)
summary(model_comp3_tot)



###R&D as the dependent variable

# Function to run the DiD model
run_did_model_rd <- function(data) {
  feglm(
    logRD ~ 
      # DiD terms (policy effects)
      treatment:post_antic + 
      treatment:post +
      
      # Main effects
      post_antic + post + treatment +
      
      # Group-specific trends by standard age
      i(treatment):sage_cont +
      
      # Controls
      treattt + logsale + logsephld + logdocid + 
      i(group_Sage) |
      
      # Fixed effects
      std_fe + firms_fe,
    
    data = data,
    vcov = ~firms_std_fe
  )
}

# Run models for all three comparisons
model_comp1_rd <- run_did_model_rd(df_comp1)  # Within group 1: SEP vs non-SEP
model_comp2_rd <- run_did_model_rd(df_comp2)  # Group1 non-SEP vs Group2 non-SEP
model_comp3_rd <- run_did_model_rd(df_comp3)  # Group1 non-SEP vs Group2 SEP


# Summarize results
summary(model_comp1_rd)
summary(model_comp2_rd)
summary(model_comp3_rd)

# Function to extract coefficients from models
extract_mech_coefs <- function(model, coef_type = "post") {
  tryCatch({
    if (is.null(model)) {
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_names <- names(coef(model))
    
    if (coef_type == "post") {
      # Look for post coefficient
      target_coef <- coef_names[grepl("treatment:post$|post:treatment$", coef_names)]
    } else if (coef_type == "antic") {
      # Look for anticipation coefficient
      target_coef <- coef_names[grepl("treatment:post_antic|post_antic:treatment", coef_names)]
    }
    
    if (length(target_coef) == 0) {
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_name <- target_coef[1]
    vcov_matrix <- vcov(model, cluster = ~firms_std_fe)
    std_error <- sqrt(vcov_matrix[coef_name, coef_name])
    
    return(data.frame(
      estimate = coef(model)[coef_name],
      std_error = std_error
    ))
  }, error = function(e) {
    return(data.frame(estimate = NA, std_error = NA))
  })
}

# Function to format coefficients for table
format_coef_table <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) return(" & ")
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ & ", se_formatted)
}

# Extract coefficients for all mechanism models
mech_results <- list()

# Non-standard patents models
mech_results$ns_comp1_antic <- extract_mech_coefs(model_comp1_ns, "antic")
mech_results$ns_comp2_antic <- extract_mech_coefs(model_comp2_ns, "antic")
mech_results$ns_comp3_antic <- extract_mech_coefs(model_comp3_ns, "antic")
mech_results$ns_comp1_post <- extract_mech_coefs(model_comp1_ns, "post")
mech_results$ns_comp2_post <- extract_mech_coefs(model_comp2_ns, "post")
mech_results$ns_comp3_post <- extract_mech_coefs(model_comp3_ns, "post")

# Total patents models
mech_results$tot_comp1_antic <- extract_mech_coefs(model_comp1_tot, "antic")
mech_results$tot_comp2_antic <- extract_mech_coefs(model_comp2_tot, "antic")
mech_results$tot_comp3_antic <- extract_mech_coefs(model_comp3_tot, "antic")
mech_results$tot_comp1_post <- extract_mech_coefs(model_comp1_tot, "post")
mech_results$tot_comp2_post <- extract_mech_coefs(model_comp2_tot, "post")
mech_results$tot_comp3_post <- extract_mech_coefs(model_comp3_tot, "post")

# R&D models
mech_results$rd_comp1_antic <- extract_mech_coefs(model_comp1_rd, "antic")
mech_results$rd_comp2_antic <- extract_mech_coefs(model_comp2_rd, "antic")
mech_results$rd_comp3_antic <- extract_mech_coefs(model_comp3_rd, "antic")
mech_results$rd_comp1_post <- extract_mech_coefs(model_comp1_rd, "post")
mech_results$rd_comp2_post <- extract_mech_coefs(model_comp2_rd, "post")
mech_results$rd_comp3_post <- extract_mech_coefs(model_comp3_rd, "post")

# Create table content
table_content <- ""

# Anticipation-Period section
table_content <- paste0(table_content, " Anticipation-Period &&&&&&&&&&\\\\\n")

# 1st Quartile - SEP Holders
antic_ns_comp1 <- format_coef_table(mech_results$ns_comp1_antic$estimate, mech_results$ns_comp1_antic$std_error)
antic_rd_comp1 <- format_coef_table(mech_results$rd_comp1_antic$estimate, mech_results$rd_comp1_antic$std_error)
antic_tot_comp1 <- format_coef_table(mech_results$tot_comp1_antic$estimate, mech_results$tot_comp1_antic$std_error)

table_content <- paste0(table_content, " & 1st Quartile - SEP Holders", 
                       antic_ns_comp1, antic_rd_comp1, antic_tot_comp1, "\\\\\n")

# 2nd Quartile - Non SEP Holders
antic_ns_comp2 <- format_coef_table(mech_results$ns_comp2_antic$estimate, mech_results$ns_comp2_antic$std_error)
antic_rd_comp2 <- format_coef_table(mech_results$rd_comp2_antic$estimate, mech_results$rd_comp2_antic$std_error)
antic_tot_comp2 <- format_coef_table(mech_results$tot_comp2_antic$estimate, mech_results$tot_comp2_antic$std_error)

table_content <- paste0(table_content, " & 2nd Quartile - Non SEP Holders", 
                       antic_ns_comp2, antic_rd_comp2, antic_tot_comp2, "\\\\\n")

# 2nd Quartile - SEP Holders
antic_ns_comp3 <- format_coef_table(mech_results$ns_comp3_antic$estimate, mech_results$ns_comp3_antic$std_error)
antic_rd_comp3 <- format_coef_table(mech_results$rd_comp3_antic$estimate, mech_results$rd_comp3_antic$std_error)
antic_tot_comp3 <- format_coef_table(mech_results$tot_comp3_antic$estimate, mech_results$tot_comp3_antic$std_error)

table_content <- paste0(table_content, " & 2nd Quartile - SEP Holders", 
                       antic_ns_comp3, antic_rd_comp3, antic_tot_comp3, "\\\\\n")

table_content <- paste0(table_content, "&&&&&&&&&&\\\\\n")

# Post-Period section
table_content <- paste0(table_content, " Post-Period &&&&&&&&&&\\\\\n")

# 1st Quartile - SEP Holders
post_ns_comp1 <- format_coef_table(mech_results$ns_comp1_post$estimate, mech_results$ns_comp1_post$std_error)
post_rd_comp1 <- format_coef_table(mech_results$rd_comp1_post$estimate, mech_results$rd_comp1_post$std_error)
post_tot_comp1 <- format_coef_table(mech_results$tot_comp1_post$estimate, mech_results$tot_comp1_post$std_error)

table_content <- paste0(table_content, " & 1st Quartile - SEP Holders", 
                       post_ns_comp1, post_rd_comp1, post_tot_comp1, "\\\\\n")

# 2nd Quartile - Non SEP Holders
post_ns_comp2 <- format_coef_table(mech_results$ns_comp2_post$estimate, mech_results$ns_comp2_post$std_error)
post_rd_comp2 <- format_coef_table(mech_results$rd_comp2_post$estimate, mech_results$rd_comp2_post$std_error)
post_tot_comp2 <- format_coef_table(mech_results$tot_comp2_post$estimate, mech_results$tot_comp2_post$std_error)

table_content <- paste0(table_content, " & 2nd Quartile - Non SEP Holders", 
                       post_ns_comp2, post_rd_comp2, post_tot_comp2, "\\\\\n")

# 2nd Quartile - SEP Holders
post_ns_comp3 <- format_coef_table(mech_results$ns_comp3_post$estimate, mech_results$ns_comp3_post$std_error)
post_rd_comp3 <- format_coef_table(mech_results$rd_comp3_post$estimate, mech_results$rd_comp3_post$std_error)
post_tot_comp3 <- format_coef_table(mech_results$tot_comp3_post$estimate, mech_results$tot_comp3_post$std_error)

table_content <- paste0(table_content, " & 2nd Quartile - SEP Holders", 
                       post_ns_comp3, post_rd_comp3, post_tot_comp3, "\\\\\n")

# Create the complete LaTeX table
latex_table <- paste0(
"\\begin{table}[t]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Mechanism Analysis: Effect of IEEE policy change on Innovation Channels}
\\label{tab:mechanism} 
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{7}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{Non-std Patents}&\\multicolumn{2}{c}{R\\&D}&\\multicolumn{2}{c}{Total Patents}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3} \\cmidrule{4-5} \\cmidrule{6-7} & & Post & Antic & Post & Antic & Post & Antic \\\\\t 
\\midrule\n",
table_content,
"\\hline
&&&&&&&&\\\\
Covariates & & Yes & Yes & Yes & Yes & Yes & Yes  \\
Standard Age FE & & Yes & Yes & Yes & Yes & Yes & Yes   \\
Standard FE & & Yes & Yes & Yes & Yes & Yes & Yes   \\
Firm FE & & Yes & Yes & Yes & Yes & Yes & Yes  \\

\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: This table shows the effect of IEEE policy change on different innovation channels. Column (1)-(2) show results for non-standard-related patents, columns (3)-(4) for R\\&D expenditure, and columns (5)-(6) for total patents. The method of estimation is maximum likelihood for the Poisson model for patents and OLS for R\\&D. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard. \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print the table
cat(latex_table)

# Write to file
writeLines(latex_table, file.path(OUT, "mechanism_analysis_table.tex"))

