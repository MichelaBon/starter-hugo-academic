# ---------------------------------------------------------------------------
# Paths: run this script from the replication package root, e.g.
#   Rscript R/Main_Analysis.R
# Data are read from the DATA folder (default "data"). To run on the synthetic
# data instead:  REPLICATION_DATA=data_synthetic Rscript R/Main_Analysis.R
# Tables (.tex) are written to the "output" folder.
# ---------------------------------------------------------------------------
DATA <- Sys.getenv("REPLICATION_DATA", "data")
OUT  <- "output"
dir.create(OUT, showWarnings = FALSE)

# Load libraries
library(data.table)
library(fixest)  
library(car)       
library(lmtest)   
library(sandwich) 

# Load data
df <- fread(file.path(DATA, "data da usare/ETSI/ETSI final.csv"))


# Create grouping variables
df[, group_country := .GRP, by = loc]
df[, group_industryFE := .GRP, by = naics]
df[, firms_fe := .GRP, by = company_id]
df[, std_fe := .GRP, by = standard_family1]
df[, firms_std_fe := .GRP, by = .(company_id, standard_family1)]
df[, group_Sage := .GRP, by = Sage]

# Create transformed variables
df[, logsephld := log(sep_hld_TOTF + 1)]
df[, logdocid := log(doc_idn + 1)]
df[, loge := log(E + 1)]

# Forward-fill logsale by company
#df[, logsale := nafill(logSALE, type = "locf"), by = company_id]
df[, logsale := logSALE]


# Create quartiles based on tech_before
df[, quant := cut(TECH_before, 
                 breaks = quantile(TECH_before, probs = 0:4/4, na.rm = TRUE),
                 labels = FALSE, include.lowest = TRUE)]
df[, quart_tech_u := fcase(
  quant == 1, 0.25,
  quant == 2, 0.50,
  quant == 3, 0.75,
  quant == 4, 1.00
)]


# Define custom thresholds
q1 <- 0.1801442
q2 <- 0.2542376
q3 <- 0.3521804
q4 <- 0.60152217  

# Create the quartile variable using thresholds
df[, quart_tech_u := fcase(
  TECH_before == 0,              0.00,  # Special case for zero
  TECH_before > 0 & TECH_before <= q1, 0.25,
  TECH_before > q1 & TECH_before <= q2, 0.50,
  TECH_before > q2 & TECH_before <= q3, 0.75,
  TECH_before > q3,              1.00,
  default = NA_real_  # Handles NA/missing values
)]

df[, treat1 := (1 - quart_tech_u) + 0.25]
df[, treattt := 1 - TECH_before]

# Time variables
df[, post := fifelse(year > 2014, 1L, 0L)]
df[, post_antic := fifelse(year == 2014, 1L, 0L)]
# Alternative definitions:
# df[, post_antic := fifelse(year > 2012 & year < 2015, 1L, 0L)]
# df[, pre := fifelse(year < 2013 & year > 2010, 1L, 0L)]


# Create treatment groups
df[, group_treatment := fcase(
  treat1 == 0.25, 1L,
  treat1 == 0.50, 2L,
  treat1 == 0.75, 3L,
  treat1 == 1.00, 4L
)]

# Create group dummies
df[, group1 := fifelse(group_treatment == 1, 1L, 0L)]
df[, group2 := fifelse(group_treatment == 2, 1L, 0L)]
df[, group3 := fifelse(group_treatment == 3, 1L, 0L)]
df[, group4 := fifelse(group_treatment == 4, 1L, 0L)]
df[, group1 := 0L]  # Set as reference

# Filter for Q1 vs Q2 comparison
df_q12 <- df[treat1 %in% c(0.25, 0.50)]
df_q12[, group_treatment2Q := fifelse(treat1 == 0.50, 1L, 0L)]

# Filter for Q1 vs Q3 comparison
df_q13 <- df[treat1 %in% c(0.25, 0.75)]
df_q13[, group_treatment2Q := fifelse(treat1 == 0.75, 1L, 0L)]

# Filter for Q1 vs Q4 comparison
df_q14 <- df[treat1 %in% c(0.25, 1)]
df_q14[, group_treatment2Q := fifelse(treat1 == 1, 1L, 0L)]

### Accounting for autonomous patenting growth by including group-specific linear trends (i(group_treatment2Q):sage_cont)


##GROUP 1 VS GROUP 2

# Center standard age
df_q12[, sage_cont := group_Sage - median(group_Sage)]  

#Post Only 
# Estimate with standard-age-specific trends
model_sage_trends12 <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group_treatment2Q:post +
    
    post +
    group_treatment2Q +
    
    # Group-specific trends by standard age
    i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
    
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df_q12,
  vcov = ~firms_std_fe
)


summary(model_sage_trends12)

#Anticipation Effect
#Estimate with standard-age-specific trends
model_sage_trends_12_ant <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group_treatment2Q:post_antic + 
    group_treatment2Q:post +
    
    post_antic + post +
    group_treatment2Q +
    
    # Group-specific trends by standard age
    i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
    
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df_q12,
  vcov = ~firms_std_fe
)


summary(model_sage_trends_12_ant)


##GROUP 1 VS GROUP 3

# Center standard age 
df_q13[, sage_cont := group_Sage - median(group_Sage)]  

#Post Only 
# Estimate with standard-age-specific trends
model_sage_trends13 <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group_treatment2Q:post +
    
    post +
    group_treatment2Q +
    
    # Group-specific trends by standard age
    i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
    
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df_q13,
  vcov = ~firms_std_fe
)


summary(model_sage_trends13)

#Anticipation Effect
#Estimate with standard-age-specific trends
model_sage_trends13_ant <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group_treatment2Q:post_antic + 
    group_treatment2Q:post +
    
    post_antic + post +
    group_treatment2Q +
    
    # Group-specific trends by standard age
    i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
    
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df_q13,
  vcov = ~firms_std_fe
)


summary(model_sage_trends13_ant)

##GROUP 1 VS GROUP 4

# Center standard age
df_q14[, sage_cont := group_Sage - median(group_Sage)]  

#Post Only 
# Estimate with standard-age-specific trends
model_sage_trends14 <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group_treatment2Q:post +
    
    post +
    group_treatment2Q +
    
    # Group-specific trends by standard age
    i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
    
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df_q14,
  vcov = ~firms_std_fe
)


summary(model_sage_trends14)

#Anticipation Effect
#Estimate with standard-age-specific trends
model_sage_trends_14_ant <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group_treatment2Q:post_antic + 
    group_treatment2Q:post +
    
    post_antic + post +
    group_treatment2Q +
    
    # Group-specific trends by standard age
    i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
    
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df_q14,
  vcov = ~firms_std_fe
)


summary(model_sage_trends_14_ant)

# Function to test post-trends coefficients

# Extract coefficients and VCOV matrices
coef_post12 <- coef(model_sage_trends12)["post:group_treatment2Q"]
vcov_post12 <- vcov(model_sage_trends12, cluster = ~firms_std_fe)["post:group_treatment2Q", "post:group_treatment2Q"]

coef_post13 <- coef(model_sage_trends13)["post:group_treatment2Q"]
vcov_post13 <- vcov(model_sage_trends13, cluster = ~firms_std_fe)["post:group_treatment2Q", "post:group_treatment2Q"]

coef_post14 <- coef(model_sage_trends14)["post:group_treatment2Q"]
vcov_post14 <- vcov(model_sage_trends14, cluster = ~firms_std_fe)["post:group_treatment2Q", "post:group_treatment2Q"]

# Stack coefficients and VCOV
all_coefs <- c(coef_post12, coef_post13, coef_post14)
all_vcov <- diag(c(vcov_post12, vcov_post13, vcov_post14))  

# Hypothesis matrix (H0: coef_post12 = coef_post13 = coef_post14)
R <- rbind(
  c(1, -1,  0),  # Q12 = Q13
  c(1,  0, -1)   # Q12 = Q14
)

# Wald test for equality
wald_test <- linearHypothesis(
  model = NULL,
  hypothesis.matrix = R,
  rhs = rep(0, nrow(R)),
  coef. = all_coefs,
  vcov. = all_vcov,
  test = "F"
)

# Print results
print(wald_test)

# Test each pairwise comparison separately with t-tests
test_12_13 <- (all_coefs[1] - all_coefs[2]) / sqrt(all_vcov[1,1] + all_vcov[2,2])
test_12_14 <- (all_coefs[1] - all_coefs[3]) / sqrt(all_vcov[1,1] + all_vcov[3,3])
test_13_14 <- (all_coefs[2] - all_coefs[3]) / sqrt(all_vcov[2,2] + all_vcov[3,3])

p_12_13 <- 2 * pt(-abs(test_12_13), df = Inf)  # Using normal approximation
p_12_14 <- 2 * pt(-abs(test_12_14), df = Inf)
p_13_14 <- 2 * pt(-abs(test_13_14), df = Inf)

cat("Q12 vs Q13: t =", test_12_13, ", p =", p_12_13, "\n")
cat("Q12 vs Q14: t =", test_12_14, ", p =", p_12_14, "\n")
cat("Q13 vs Q14: t =", test_13_14, ", p =", p_13_14, "\n")

# Bonferroni correction for multiple testing
cat("\nWith Bonferroni correction (α = 0.05/3 = 0.0167):\n")
cat("Q12 vs Q13 significant:", p_12_13 < 0.0167, "\n")
cat("Q12 vs Q14 significant:", p_12_14 < 0.0167, "\n")
cat("Q13 vs Q14 significant:", p_13_14 < 0.0167, "\n")


# Function to extract coefficients 
extract_etsi_coefs <- function(model, coef_type = "post") {
  tryCatch({
    if (is.null(model)) {
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_names <- names(coef(model))
    
    if (coef_type == "post") {
      # Look for post coefficient
      target_coef <- coef_names[grepl("group_treatment2Q:post$|post:group_treatment2Q$", coef_names)]
    } else if (coef_type == "antic") {
      # Look for anticipation coefficient
      target_coef <- coef_names[grepl("group_treatment2Q:post_antic|post_antic:group_treatment2Q", coef_names)]
    }
    
    if (length(target_coef) == 0) {
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_name <- target_coef[1]
    vcov_matrix <- vcov(model, cluster = ~firms_std_fe)
    std_error <- sqrt(vcov_matrix[coef_name, coef_name])
    
    return(data.frame(
      estimate = coef(model)[coef_name],
      std_error = std_error
    ))
  }, error = function(e) {
    return(data.frame(estimate = NA, std_error = NA))
  })
}

# Function to format coefficients for table
format_coef_table <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) return(" & ")
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ & ", se_formatted)
}

# Function to format coefficients with line break
format_coef_multiline <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) return(" & \\\\\n")
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ \\\\\n & ", se_formatted, " \\\\\n")
}

# Extract coefficients from all models
etsi_results <- list()

# Post-only models
etsi_results$q12_post <- extract_etsi_coefs(model_sage_trends12, "post")
etsi_results$q13_post <- extract_etsi_coefs(model_sage_trends13, "post")
etsi_results$q14_post <- extract_etsi_coefs(model_sage_trends14, "post")

# Anticipation models
etsi_results$q12_antic <- extract_etsi_coefs(model_sage_trends_12_ant, "antic")
etsi_results$q13_antic <- extract_etsi_coefs(model_sage_trends13_ant, "antic")
etsi_results$q14_antic <- extract_etsi_coefs(model_sage_trends_14_ant, "antic")

etsi_results$q12_post_antic <- extract_etsi_coefs(model_sage_trends_12_ant, "post")
etsi_results$q13_post_antic <- extract_etsi_coefs(model_sage_trends13_ant, "post")
etsi_results$q14_post_antic <- extract_etsi_coefs(model_sage_trends_14_ant, "post")

# Create table content
table_content <- ""

# Anticipation-Period section
table_content <- paste0(table_content, " Anticipation-Period &&\\\\\n")

# 2nd Quartile
antic_q12 <- format_coef_multiline(
  etsi_results$q12_antic$estimate,
  etsi_results$q12_antic$std_error
)
table_content <- paste0(table_content, " & 2nd Quartile", antic_q12)

# 3rd Quartile
antic_q13 <- format_coef_multiline(
  etsi_results$q13_antic$estimate,
  etsi_results$q13_antic$std_error
)
table_content <- paste0(table_content, " & 3rd Quartile", antic_q13)

# 4th Quartile
antic_q14 <- format_coef_multiline(
  etsi_results$q14_antic$estimate,
  etsi_results$q14_antic$std_error
)
table_content <- paste0(table_content, " & 4th Quartile", antic_q14)

table_content <- paste0(table_content, "&&\\\\\n")

# Post-Period section
table_content <- paste0(table_content, " Post-Period &&\\\\\n")

# 2nd Quartile
post_q12 <- format_coef_table(
  etsi_results$q12_post$estimate,
  etsi_results$q12_post$std_error
)
post_antic_q12 <- format_coef_table(
  etsi_results$q12_post_antic$estimate,
  etsi_results$q12_post_antic$std_error
)
table_content <- paste0(table_content, " & 2nd Quartile", post_q12, post_antic_q12, "\\\\\n")

# 3rd Quartile
post_q13 <- format_coef_table(
  etsi_results$q13_post$estimate,
  etsi_results$q13_post$std_error
)
post_antic_q13 <- format_coef_table(
  etsi_results$q13_post_antic$estimate,
  etsi_results$q13_post_antic$std_error
)
table_content <- paste0(table_content, " & 3rd Quartile", post_q13, post_antic_q13, "\\\\\n")

# 4th Quartile
post_q14 <- format_coef_table(
  etsi_results$q14_post$estimate,
  etsi_results$q14_post$std_error
)
post_antic_q14 <- format_coef_table(
  etsi_results$q14_post_antic$estimate,
  etsi_results$q14_post_antic$std_error
)
table_content <- paste0(table_content, " & 4th Quartile", post_q14, post_antic_q14, "\\\\\n")

# Create the complete LaTeX table
latex_table <- paste0(
"\\begin{table}[t]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Effect of IEEE policy change on ETSI Standard-related Patents}
\\label{tab:etsi} 
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{3}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{ETSI Standard-related Patents}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3} & & (1) & (2)  \\\\\t 
\\midrule\n",
table_content,
"\\hline
&&\\\\
Covariates & & Yes & Yes  \\
Standard Age FE & & Yes & Yes   \\
Standard FE & & Yes & Yes   \\
Firm FE & & Yes & Yes  \\

\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: The dependent variable is the weighted number of ETSI standard-related patents per firm-standard. Column (1) shows results from post-only specifications, and column (2) shows results from specifications including anticipation effects. The method of estimation is maximum likelihood for the Poisson model. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard. \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print the table
cat(latex_table)

# Write to file
writeLines(latex_table, file.path(OUT, "etsi_analysis_table.tex"))


