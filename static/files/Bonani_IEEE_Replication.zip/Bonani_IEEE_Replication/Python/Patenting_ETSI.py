import os
# ---------------------------------------------------------------------------
# Paths: all data are read from / written to the DATA folder.
# By default this is <replication package>/data. To run on the synthetic
# data instead, set the environment variable REPLICATION_DATA=data_synthetic.
# ---------------------------------------------------------------------------
try:
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
except NameError:  # interactive session: run from the package root
    ROOT = os.getcwd()
DATA = os.path.join(ROOT, os.environ.get("REPLICATION_DATA", "data"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)



# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
#import seaborn as sb
from scipy.stats import chisquare
#import matplotlib
import matplotlib.pyplot as plt
#import dask.dataframe as dd
#from dask.diagnostics import ProgressBar 
from itertools import tee, islice, chain

####### USEFULL FUNCTION

def num_missing(x):
  return sum(x.isnull())

def tidy_split(df, column, sep='|', keep=False):
    indexes = []
    new_values = []
    df = df.dropna(subset=[column])
    for i, presplit in enumerate(df[column].astype(str)):
        values = presplit.split(sep)
        if keep and len(values) > 1:
            indexes.append(i)
            new_values.append(presplit)
        for value in values:
            indexes.append(i)
            new_values.append(value)
    new_df = df.iloc[indexes, :].copy()
    new_df[column] = new_values
    return new_df

def previous_and_next(some_iterable):
    prevs, current, nexts = tee(some_iterable, 3)
    prevs = chain([None], prevs)
    nexts = chain(islice(nexts, 1, None), [None])
    return zip(prevs, current, nexts)


###########CREATION OF THE DATABASE MERGING FIRMS, ESSENTIAL PATENTS (all) AND STANDARDS

#####SCDB data final: database including only the information about standards, sso and their evolution over time (id variable common to all standard documents with a common version history)

### Standards grouped by version history

standards = pd.read_excel(os.path.join(DATA, "data da usare/SCDB_standards.xlsx"))
history = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_version_history.csv"),low_memory=False)
replacement = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_replacement.csv"),low_memory=False)

std_dic = {row['doc_idn']: row['doc_idn_versionhistory'] for _, row in history.iterrows()}
std_replacement = {row['doc_idn']: row['replaced_doc_idn'] for _, row in replacement.iterrows()}

standards['standard_project'] = standards['doc_idn'].map(std_dic)
standards['standard_replacement'] = standards['doc_idn'].map(std_replacement)
standards1 = standards.dropna(subset=['standard_project'])

#####STANDARD DATABASE for SSOs

##merging with table of correspondences with declarations
disc = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_discl_to_docidn.csv"),low_memory=False)
#standard_declared = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_discl_to_stand_doc.csv"),low_memory=False)

a = disc['doc_idn'].unique()
b = standards1['doc_idn'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]

disc1 = disc[disc.doc_idn.isin(kk)]
standards2  = standards1[standards1.doc_idn.isin(kk)]
disc2 = disc1[['disclosure_id', 'sso','doc_idn','letter_id', 'company_name', 'publicationyear', 'version','documentid','declaration_date']].drop_duplicates()
standards3 = standards2[['doc_idn', 'publicationyear', 'issuingbody', 'withdrawalyear','standard_project']]
std = pd.merge(disc2,standards3, on=['doc_idn','publicationyear'])

std3 = std.join(std['declaration_date'].str.split('-',expand=True).add_prefix('declaration_date'))
std4 = std3.drop(['declaration_date','declaration_date1','declaration_date2'],axis=1).drop_duplicates()
#std5 = std4.dropna(subset=['company_name'])

std_family = {row['standard_project']: row['documentid'] for _, row in std4.iterrows()}
std_family1 = {row['documentid']: row['standard_project'] for _, row in std4.iterrows()}

std4['standard_family'] = std4['standard_project'].map(std_family)
std4['standard_family1'] = std4['documentid'].map(std_family1)
std4_bis = std4[std4.sso=='ETSI']

##Selecting the firms that are also in ETSI

pers = pd.read_excel(os.path.join(DATA, "data da usare/SCDB_ Firms names.xlsx"))
a = std4_bis['company_name'].unique()
b = pers['company_name'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
pers2 = pers[pers.company_name.isin(kk)]
a = std4_bis['company_name'].unique()
b = pers2['company_name'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
std5_first = pd.merge(std4_bis,pers2,on='company_name')

final1 = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"),low_memory=False)

a = final1['company_id'].unique()
b = std5_first['company_id'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
std5 = std5_first[std5_first.company_id.isin(kk)]
std5 = std5.drop(['company_id'],axis=1).drop_duplicates()

###########CREATION OF THE DATABASE MERGING ESSENTIAL PATENTS AND STANDARDS FOR IPC CLASSES AND FIRMS

###Adding IPC classification and creating the standards patent portfolios
###File linking standard projects with the set of associated IPC codes.

test = std5[['standard_family1','disclosure_id','letter_id','company_name']].drop_duplicates()
p1 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_declared_number.csv"),low_memory=False)
test1 = pd.merge(test,p1,on=['disclosure_id','letter_id','company_name'])
p2 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_patn.csv"),low_memory=False)
test2 = pd.merge(test1,p2,on=['patstring_id'])
p3 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_patn_applicationnr.csv"),low_memory=False)
test3 = pd.merge(test2,p3,on=['patn'])
p4 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_patent_info.csv"),low_memory=False)
test4 = pd.merge(test3,p4,on=['application_nr'])

ipc1 = test4[['standard_family1','ipc_current']].drop_duplicates().fillna(0)

checking_zeros = pd.DataFrame()
item = ipc1.standard_family1.unique()

for i in item:
    add = ipc1[ipc1.standard_family1==i]
    zeros = add[add.ipc_current==0]
    num = zeros.ipc_current.count()
    dem = add.ipc_current.count()
    perc = num/dem
    data = {'standard_family1': [i], 'perc': [perc]}
    add1 = pd.DataFrame(data)
    checking_zeros = pd.concat([add1,checking_zeros], axis = 0, sort=True)

checking_zeros1 = checking_zeros[checking_zeros.perc<0.25]
a = checking_zeros1.standard_family1.unique()
ipc3 = ipc1[ipc1.standard_family1.isin(a)]
#ipc3 = ipc1[ipc1.ipc_current !=0]
ipc4 = tidy_split(ipc3,'ipc_current')
ipc4['ipc_current'] = ipc4['ipc_current'].map(lambda x: x.strip())
ipc4['ipc1'] = ipc4['ipc_current'].str[0:4]

a = ipc4['standard_family1'].unique()
b = std5['standard_family1'].unique()
kk = set(a).intersection(b)
ipc5 = ipc4[ipc4.standard_family1.isin(kk)]

data1 = ipc5[['standard_family1','ipc1']].drop_duplicates() 

checking_zeros2 = pd.DataFrame()
item = data1.standard_family1.unique()

for i in item:
    add = data1[data1.standard_family1==i]
    zeros = add[add.ipc1=='0']
    num = zeros.ipc1.count()
    dem = add.ipc1.count()
    perc = num/dem
    data = {'standard_family1': [i], 'perc': [perc]}
    add1 = pd.DataFrame(data)
    checking_zeros2 = pd.concat([add1,checking_zeros2], axis = 0, sort=True)

#Selecting only the standard families for which I have less than 10% of 4-digit IPC classes that are 0
    
checking_zeros3 = checking_zeros2[checking_zeros2.perc<0.25]
a = checking_zeros3.standard_family1.unique()
data2 = data1[data1.standard_family1.isin(a)]

data2.to_csv(os.path.join(DATA, "data da usare/ETSI/standard patent portfolio_ETSI.csv"))

##IPC classes before 2015 (after 2015 is data2 since I have all the ipc classes declared)

ipc1 = test4[['standard_family1','ipc_current','declaration_date']].drop_duplicates().fillna(0)
a = data2.standard_family1.unique()
ipc3 = ipc1[ipc1.standard_family1.isin(a)]
#ipc3 = ipc1[ipc1.ipc_current !=0]
ipc4 = tidy_split(ipc3,'ipc_current')
ipc4['ipc_current'] = ipc4['ipc_current'].map(lambda x: x.strip())
ipc4['ipc1'] = ipc4['ipc_current'].str[0:4]
#ipc5 = ipc4[ipc4.declaration_date !=0]
ipc5 = ipc4
ipc6 = ipc5.join(ipc5['declaration_date'].str.split('-',expand=True).add_prefix('declaration_date'))
ipc7 = ipc6.drop(['declaration_date','declaration_date1','declaration_date2'],axis=1).drop_duplicates()
ipc7['declaration_date0'] = ipc7['declaration_date0'].fillna(0)
ipc7 = ipc7[ipc7.declaration_date0 != '"']
ipc7['year'] = ipc7['declaration_date0'].map(int)
ipc8 = ipc7[ipc7.year<2015]

ipc9 = ipc8.drop('ipc_current',axis=1).drop_duplicates()
ipc9.to_csv(os.path.join(DATA, "data da usare/ETSI/standard patent portfolio_ETSI_before2015NEW.csv"))


#### STANDARDS INFORMATION and creation of the standards databases based on contributions before and after

##Selecting the standard families for which I have information about less than 25% of disclosures/ipc-current classes missing info and less than 10% of 4-digit IPC classes == 0
std6 = std5[std5.standard_family1.isin(a)]

##Replacing the missing declaration_dates with the median of the other declarations
proxy = std6[['publicationyear','doc_idn']].drop_duplicates()
std6 = std6[std6.declaration_date0 != '"']
std6['declaration_date0'] = std6['declaration_date0'].map(float)
std6['declaration_date0'] = std6['declaration_date0'].fillna(std6['publicationyear'])
std6 = std6.dropna(subset=['company_name'])
std7 = std6.dropna(subset=['declaration_date0'])

### Creating standards information using std7 

std7['year'] = std7['declaration_date0'].map(int)
std_info = std7.groupby(['year','standard_family1'])['disclosure_id', 'doc_idn', 'letter_id', 'company_name'].nunique().reset_index()

#Adding info about the number of SEPs declared per standard
a = std7.standard_family1.unique()
seps_info = test4[test4.standard_family1.isin(a)]

seps_info1 = seps_info.join(seps_info['declaration_date'].str.split('-',expand=True).add_prefix('declaration_date'))
seps_info2 = seps_info1.drop(['declaration_date','declaration_date1','declaration_date2'],axis=1).drop_duplicates()
seps_info3 = seps_info2.dropna(subset=['declaration_date0'])
seps_info3['year'] = seps_info3['declaration_date0'].map(int)

seps_info4 = seps_info3.groupby(['year','standard_family1'])['patn'].nunique().reset_index()
std_info1 = pd.merge(std_info,seps_info4,on=['year','standard_family1'])

a = std_info1.standard_family1.unique()
std_info2 = pd.DataFrame()

for item in a:
    add = std_info1[std_info1.standard_family1 == item]
    add1 = add.sort_values("year")
    add1['sepTOTF'] = add1['patn'].cumsum()
    add1['sep_hld_TOTF'] = add1['company_name'].cumsum()
    add1['disclosure_id_TOTF'] = add1['disclosure_id'].cumsum()
    add1['doc_idn_TOTF'] = add1['doc_idn'].cumsum()
    add1['letter_id_TOTF'] = add1['letter_id'].cumsum()
    std_info2 = pd.concat([add1,std_info2],sort=True)


item = std_info2.standard_family1.unique()
std_final = pd.DataFrame()

for i in item:
    add = std_info2[std_info2.standard_family1==i]
    indeces = add.index.tolist()
    add1_master = pd.DataFrame()
    add2_master = pd.DataFrame()
    add3_master = pd.DataFrame()
    df0 = pd.DataFrame()
    for idx in indeces:
        if idx==min(indeces):
            add1 = add[add.index.isin([idx])]
            add1_master = pd.concat([add1,add1_master],axis=0,sort=True)
        elif idx==max(indeces):
            add2 = add[add.index.isin([idx])]
            add2_master = pd.concat([add2,add2_master],axis=0,sort=True)
        else:
            index_pre = indeces.index(idx) -1
            index_pre1 = indeces[index_pre]
            year_pre = add.loc[index_pre1, 'year']
            #index_post = indeces[idx] 
            year_post = add.loc[idx, 'year']
            if year_post == year_pre+1:
                add3 = add[add.year==year_post]
                add3_master = pd.concat([add3,add3_master],axis=0,sort=True)
            elif year_post != year_pre+1:
                lenght = year_post - year_pre
                years_new = list(range(year_pre+1,year_post+1))
                for y in years_new:
                    transition_df = add[add.year==year_pre]
                    add4 = pd.DataFrame({'year': [y], 'standard_family1': [i], 'disclosure_id': transition_df['disclosure_id'],'disclosure_id_TOTF': transition_df['disclosure_id_TOTF'],'doc_idn':transition_df['doc_idn'], 'doc_idn_TOTF':transition_df['doc_idn_TOTF'], 'letter_id_TOTF':transition_df['letter_id_TOTF'],'letter_id':transition_df['letter_id'], 'company_name':transition_df['company_name'],  'sep_hld_TOTF':transition_df['sep_hld_TOTF'],  'patn':transition_df['patn'],  'sepTOTF':transition_df['sepTOTF']})
                    df0 = pd.concat([add4,df0], axis=0,sort=True)
        df1 = pd.concat([add1_master,add2_master], axis=0,sort=True)
        df2 = pd.concat([add3_master,df1], axis=0,sort=True)
        df3 = pd.concat([df0,df2], axis=0,sort=True)
        std_final = pd.concat([df3,std_final], axis=0,sort=True)   

std_final.drop_duplicates(inplace=True)
std_final.to_csv(os.path.join(DATA, "data da usare/ETSI/10standards_family_info.csv"))

###Creation of the weights for the IPC classes
a = std_final.standard_family1.unique()
ipc1 = test4[['standard_family1','ipc_current','patn']].drop_duplicates().fillna(0)
ipc1['standard_family2'] = ipc1['standard_family1'].map(std_family2)
ipc3 = ipc1[ipc1.standard_family1.isin(a)]
ipc4 = tidy_split(ipc3,'ipc_current')
ipc4['ipc_current'] = ipc4['ipc_current'].map(lambda x: x.strip())
ipc4['ipc1'] = ipc4['ipc_current'].str[0:4]
ipc5 = ipc4.drop('ipc_current',axis=1).drop_duplicates()
ipc6 = ipc5.groupby(['standard_family1','ipc1'])['patn'].nunique().reset_index()

item = ipc6.standard_family1.unique()
standard = pd.DataFrame()

for x in item:
    prova = ipc6[ipc6.standard_family1==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight'] = prova1['patn']/total
        standard = pd.concat([prova1,standard],axis=0,sort=True)

ipc7 = ipc6[ipc6.ipc1 != '0']
item = ipc7.standard_family1.unique()
standard0 = pd.DataFrame()

for x in item:
    prova = ipc7[ipc7.standard_family1==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight_w0'] = prova1['patn']/total
        standard0 = pd.concat([prova1,standard0],axis=0,sort=True)

standard_all = pd.merge(standard, standard0, on=['standard_family1','patn','ipc1'],how='left')
standard_all.to_csv(os.path.join(DATA, "data da usare/ETSI/10standard_weighted classes.csv"))



####PATSTAT DATABASE of all FIRMS ---  (I need this information to then compute the cosine similarity in the pre-period, in post-period and the differences even if I do not know whether it makes sense)

####Firms declaring standard essential patents to IEEE
#Including info about company_id

pers = pd.read_excel(os.path.join(DATA, "data da usare/SCDB_ Firms names.xlsx"))
a = std7['company_name'].unique()
b = pers['company_name'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
pers2 = pers[pers.company_name.isin(kk)]
a = std7['company_name'].unique()
b = pers2['company_name'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
std8 = pd.merge(std7,pers2,on='company_name')


##Selecting the firms for which I am able to collect info on patstat (ipc, patn, appl date)

per = pd.read_csv(os.path.join(DATA, "data da usare/HanPer_id fin 1.1.1.csv"))
a = std8['company_id'].unique()
b = per['company_id'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
pr = per[per['company_id'].isin(kk)]

pat = pd.read_csv(os.path.join(DATA, "data da usare/Patstat cited new.csv"),low_memory=False)
a = pr['person_id'].unique()
b = pat['person_id'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
per4 = pr[pr.person_id.isin(kk)]
per5 = per4[['person_id','company_id']].drop_duplicates()

data = pd.merge(per5,pat,on='person_id',how='inner')
data1 = data.drop_duplicates()
agg = data1.loc[data1['appln_filing_year']!=9999]
data2 = agg[['company_id','appln_nr','appln_filing_year','appln_nr_original', 'ipc_class_symbol','cited_pat_publn_id']].drop_duplicates()
a = data2['company_id'].unique()
b = std8['company_id'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
#data3 = data2.loc[data2['appln_filing_year']>1999]
data2['family_proxy'] = (
    data2['company_id'].astype(str) + "_" +
    data2['appln_nr_original'].astype(str).fillna("") + "_" +
    data2['appln_filing_year'].astype(str)
)

df_sorted = data2.sort_values(by=['company_id','appln_filing_year'])
data3 = df_sorted.drop_duplicates(subset=['family_proxy'], keep='first')
data3['ipc1'] = data3['ipc_class_symbol'].str[0:4]
data3['year'] = data3['appln_filing_year'].map(int)
data3['patn'] = data3['appln_nr_original']
data3['citation'] = data3['cited_pat_publn_id']
daa3 = data3[['company_id', 'ipc1', 'year', 'patn','citation']].drop_duplicates()

####Creation of the patent portfolio for the similarity comparison

pat_port = daa3[daa3.year<2015]
pat_port1 = pat_port.groupby(['company_id','ipc1'])['patn'].count().reset_index().drop_duplicates()

item = pat_port1.company_id.unique()
firms_portfolio = pd.DataFrame()

for x in item:
    prova = pat_port1[pat_port1.company_id==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight'] = prova1['patn']/total
        firms_portfolio = pd.concat([prova1,firms_portfolio],axis=0,sort=True)

firms_portfolio.to_csv(os.path.join(DATA, "data da usare/ETSI/firms_portfolio_for_similarity_IEEE2.csv"))


###Collecting the set of ipc associated to each standard
#IEEE_ipc = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_IEEE.csv"))

daa3[['patn','citation']] = daa3[['patn','citation']].fillna(1)
da6 = daa3.fillna(0)
patot = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index()
da6['weight'] = da6['citation']
da1 = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index().drop_duplicates()
da2 = da6.groupby(['company_id','year','ipc1'])['weight'].sum().reset_index().drop_duplicates()
da3 = pd.merge(da1,da2,on=['company_id','year','ipc1'])
da3['patT_c'] = da3['patn']*da3['weight']

standard_weights = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10standard_weighted classes.csv"))
standard_weights['weights_s'] = standard_weights['weight']
standard_weights['weights_s_w0'] = standard_weights['weight_w0']

a = da3['ipc1'].unique()
b = standard_weights['ipc1'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
da5 = da3[da3.ipc1.isin(kk)]
ipc_weight = standard_weights[['standard_family1','ipc1','weights_s','weights_s_w0']].drop_duplicates()
daa = pd.merge(ipc_weight,da5,on='ipc1').drop_duplicates()
daa['patn_ws'] = daa['patn']*daa['weights_s']
daa['patT_c_ws'] = daa['patT_c']*daa['weights_s']
daa['patn_ws_w0'] = daa['patn']*daa['weights_s_w0']
daa['patT_c_ws_w0'] = daa['patT_c']*daa['weights_s_w0']

daa1 = daa.groupby(['company_id','year','standard_family1'])['patT_c'].sum().reset_index().drop_duplicates()
daa2 = daa.groupby(['company_id','year','standard_family1'])['patn'].sum().reset_index().drop_duplicates()
daa11 = daa.groupby(['company_id','year','standard_family1'])['patn_ws'].sum().reset_index().drop_duplicates()
daa22 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws'].sum().reset_index().drop_duplicates()
daa110 = daa.groupby(['company_id','year','standard_family1'])['patn_ws_w0'].sum().reset_index().drop_duplicates()
daa220 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws_w0'].sum().reset_index().drop_duplicates()

daa111 = pd.merge(daa1,daa2,on=['company_id','year','standard_family1'])
daa222 = pd.merge(daa11,daa22,on=['company_id','year','standard_family1'])
daa333 = pd.merge(daa110, daa220, on=['company_id','year','standard_family1'])
daa0 = pd.merge(daa111,daa222,on=['company_id','year','standard_family1'])
daa3_new = pd.merge(daa333,daa0,on=['company_id','year','standard_family1'])


testf = daa3_new
df1 = pd.DataFrame()
a = testf.company_id.unique()

for item in a:
    test = testf[testf['company_id']== item]
    c = test.standard_family1.unique().tolist()
    d = test.year.unique()
    for x in d:
        test1 = test[test.year==x]
        e = test1.standard_family1.unique()
        if len(c)==len(e):
            print(x)
        else:
            f = [item for item in c if item not in e]
            for idx, val in enumerate(f):
                test2 = pd.DataFrame({'standard_family1':[val],'year':[x],'company_id': [item]})
                df1 = pd.concat([df1,test2],axis=0)

patstd = pd.concat([df1,testf],axis=0,sort=True)
patstd['patT_c'] = patstd['patT_c'].fillna(0)
patstd['patn'] = patstd['patn'].fillna(0)
patstd['patn_ws'] = patstd['patn_ws'].fillna(0)
patstd['patT_c_ws'] = patstd['patT_c_ws'].fillna(0)
patstd['patn_ws_w0'] = patstd['patn_ws_w0'].fillna(0)
patstd['patT_c_ws_w0'] = patstd['patT_c_ws_w0'].fillna(0)

patstd.to_csv(os.path.join(DATA, "data da usare/ETSI/IEEE 10std patents2.csv"))

a = patstd.company_id.unique()
patot1 = da3[da3.company_id.isin(a)]
patot2 = patot1.groupby(['company_id','year'])['patT_c'].sum().reset_index().drop_duplicates()
patot3 = patot1.groupby(['company_id','year'])['patn'].sum().reset_index().drop_duplicates()
patot4 = pd.merge(patot2,patot3,on=['company_id','year'])

patot4.to_csv(os.path.join(DATA, "data da usare/ETSI/IEEE patents2.csv"))

sep = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/IEEE 10std patents2.csv"))
pat = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/IEEE patents2.csv"))

sep1 = sep.drop('Unnamed: 0',axis=1).drop_duplicates()
sep1['patT_c']=sep1['patT_c'].map(int)

##Adding patenting behavior 

pat['patTOT_c'] = pat['patT_c']
pat['patTOT'] = pat['patn']
pat['patTOT_c']=pat['patTOT_c'].map(int)
pat1 = pat.drop(['patT_c','patn','Unnamed: 0'],axis=1)
df1 = pd.merge(pat1,sep1,on=['company_id','year'],how='outer')

df1['standard_family1'] = df1['standard_family1'].fillna(11)
tt = df1
tt1 = tt[tt.standard_family1==11]
tt2 = tt1
a = tt2['company_id'].unique()
df2 = tt2

b = df1.company_id.unique()
c=[item for item in b if item not in a]
df3 = df1[df1.company_id.isin(c)]
df4 = pd.concat([df3,df2],axis=0,sort=True).drop_duplicates()
df4['patT_c'] = df4['patT_c'].fillna(0) 
df4['patn'] = df4['patn'].fillna(0) 
df4['patNS_c'] = df4['patTOT_c'] - df4['patT_c']
df4['patNS'] = df4['patTOT'] - df4['patn']

df4['sso'] = 'ETSI'
df4['POST'] = np.where(df4['year'] > 2014, 1, 0)
df4['TREAT_declaring'] = 1
df5 = df4[df4.standard_family1 != 11]
patenting_IEEE = df5

df5.to_csv(os.path.join(DATA, "data da usare/ETSI/10IEEE patents revised_all patents with weights2.csv"))

##Creating the patent portfolio of firms before and after 2015

pat_port = daa3[['company_id','ipc1','year']].drop_duplicates()

pat_port_tot = daa3[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])
pat_port_before = daa3[daa3.year<2015]
pat_port_before1 = pat_port_before[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])

pat_port.to_csv(os.path.join(DATA, "data da usare/ETSI/firms patent portfolio_IEEE2.csv"))
pat_port_before1.to_csv(os.path.join(DATA, "data da usare/ETSI/firms patent portfolio_IEEE_before20152.csv"))

###Firms active in the same industries as IEEE firms but with no SEPs

han_per_control = pd.read_csv(os.path.join(DATA, "data da usare/HanPer_id fin control.csv"))
pat = pd.read_csv(os.path.join(DATA, "data da usare/Patstat control cited.csv"),low_memory=False)

a = han_per_control['person_name_clean'].unique()
b = per['person_name_clean'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
per1 = han_per_control[han_per_control.person_name_clean.isin(c)]
a = per1['person_id'].unique()
b = pat['person_id'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
per4 = per1[per1.person_id.isin(kk)]
per5 = per4[['person_id','company_id']].drop_duplicates()

data_plus = pd.merge(per5,pat,on='person_id',how='inner')

final1 = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"),low_memory=False)

a = final1['company_id'].unique()
b = data_plus['company_id'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
data = data_plus[data_plus.company_id.isin(kk)]
data1 = data.drop_duplicates()

agg = data1.loc[data1['appln_filing_year']!=9999]
data2 = agg[['company_id','appln_nr','appln_filing_year','appln_nr_original', 'ipc_class_symbol','cited_pat_publn_id']].drop_duplicates()
data2['family_proxy'] = (
    data2['company_id'].astype(str) + "_" +
    data2['appln_nr_original'].astype(str).fillna("") + "_" +
    data2['appln_filing_year'].astype(str)
)

df_sorted = data2.sort_values(by=['company_id','appln_filing_year'])
data3 = df_sorted.drop_duplicates(subset=['family_proxy'], keep='first')
data3['ipc1'] = data3['ipc_class_symbol'].str[0:4]
data3['year'] = data3['appln_filing_year'].map(int)
data3['patn'] = data3['appln_nr_original']
data3['citation'] = data3['cited_pat_publn_id']
daa3 = data3[['company_id', 'ipc1', 'year', 'patn','citation']].drop_duplicates()


####Creation of the patent portfolio for the similarity comparison

pat_port = daa3[daa3.year<2015]
pat_port1 = pat_port.groupby(['company_id','ipc1'])['patn'].count().reset_index().drop_duplicates()

item = pat_port1.company_id.unique()
firms_portfolio = pd.DataFrame()

for x in item:
    prova = pat_port1[pat_port1.company_id==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight'] = prova1['patn']/total
        firms_portfolio = pd.concat([prova1,firms_portfolio],axis=0,sort=True)

firms_portfolio.to_csv(os.path.join(DATA, "data da usare/ETSI/firms_portfolio_for_similarity_others2.csv"))

###Collecting the set of ipc associated to each standard

daa3[['patn','citation']] = daa3[['patn','citation']].fillna(1)
da6 = daa3.fillna(0)
patot = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index()
da6['weight'] = da6['citation']
da1 = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index().drop_duplicates()
da2 = da6.groupby(['company_id','year','ipc1'])['weight'].sum().reset_index().drop_duplicates()
da3 = pd.merge(da1,da2,on=['company_id','year','ipc1'])
da3['patT_c'] = da3['patn']*da3['weight']

standard_weights = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10standard_weighted classes.csv"))
standard_weights['weights_s'] = standard_weights['weight']
standard_weights['weights_s_w0'] = standard_weights['weight_w0']

a = da3['ipc1'].unique()
b = standard_weights['ipc1'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
da5 = da3[da3.ipc1.isin(kk)]
ipc_weight = standard_weights[['standard_family1','ipc1','weights_s','weights_s_w0']].drop_duplicates()
daa = pd.merge(ipc_weight,da5,on='ipc1').drop_duplicates()
daa['patn_ws'] = daa['patn']*daa['weights_s']
daa['patT_c_ws'] = daa['patT_c']*daa['weights_s']
daa['patn_ws_w0'] = daa['patn']*daa['weights_s_w0']
daa['patT_c_ws_w0'] = daa['patT_c']*daa['weights_s_w0']

daa1 = daa.groupby(['company_id','year','standard_family1'])['patT_c'].sum().reset_index().drop_duplicates()
daa2 = daa.groupby(['company_id','year','standard_family1'])['patn'].sum().reset_index().drop_duplicates()
daa11 = daa.groupby(['company_id','year','standard_family1'])['patn_ws'].sum().reset_index().drop_duplicates()
daa22 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws'].sum().reset_index().drop_duplicates()
daa110 = daa.groupby(['company_id','year','standard_family1'])['patn_ws_w0'].sum().reset_index().drop_duplicates()
daa220 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws_w0'].sum().reset_index().drop_duplicates()

daa111 = pd.merge(daa1,daa2,on=['company_id','year','standard_family1'])
daa222 = pd.merge(daa11,daa22,on=['company_id','year','standard_family1'])
daa333 = pd.merge(daa110, daa220, on=['company_id','year','standard_family1'])
daa0 = pd.merge(daa111,daa222,on=['company_id','year','standard_family1'])
daa3_new = pd.merge(daa333,daa0,on=['company_id','year','standard_family1'])

df1 = pd.DataFrame()
a = daa3_new.company_id.unique()

for item in a:
    test = daa3_new[daa3_new['company_id']== item]
    c = test.standard_family1.unique().tolist()
    d = test.year.unique()
    for x in d:
        test1 = test[test.year==x]
        e = test1.standard_family1.unique()
        if len(c)==len(e):
            print(x)
        else:
            f = [item for item in c if item not in e]
            for idx, val in enumerate(f):
                test2 = pd.DataFrame({'standard_family1':[val],'year':[x],'company_id': [item]})
                df1 = pd.concat([df1,test2],axis=0)

#patstd = pd.concat([df1,daa3_new],axis=0,sort=True)
patstd = daa3_new
patstd['patT_c'] = patstd['patT_c'].fillna(0)
patstd['patn'] = patstd['patn'].fillna(0)
patstd['patn_ws'] = patstd['patn_ws'].fillna(0)
patstd['patT_c_ws'] = patstd['patT_c_ws'].fillna(0)
patstd['patn_ws_w0'] = patstd['patn_ws_w0'].fillna(0)
patstd['patT_c_ws_w0'] = patstd['patT_c_ws_w0'].fillna(0)

patstd.to_csv(os.path.join(DATA, "data da usare/ETSI/Others 10std patents2.csv"))

a = patstd.company_id.unique()
patot1 = da3[da3.company_id.isin(a)]
patot2 = patot1.groupby(['company_id','year'])['patT_c'].sum().reset_index().drop_duplicates()
patot3 = patot1.groupby(['company_id','year'])['patn'].sum().reset_index().drop_duplicates()
patot4 = pd.merge(patot2,patot3,on=['company_id','year'])

patot4.to_csv(os.path.join(DATA, "data da usare/ETSI/Others patents2.csv"))

sep = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/Others 10std patents2.csv"))
pat = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/Others patents2.csv"))

sep1 = sep.drop('Unnamed: 0',axis=1).drop_duplicates()
sep1['patT_c']=sep1['patT_c'].map(int)

##Adding patenting behavior 

pat['patTOT_c'] = pat['patT_c']
pat['patTOT'] = pat['patn']
pat['patTOT_c']=pat['patTOT_c'].map(int)
pat1 = pat.drop(['patT_c','patn','Unnamed: 0'],axis=1)
df1 = pd.merge(pat1,sep1,on=['company_id','year'],how='outer')

df1['standard_family1'] = df1['standard_family1'].fillna(11)
tt = df1
tt1 = tt[tt.standard_family1==11]
tt2 = tt1
a = tt2['company_id'].unique()
df2 = pd.DataFrame()

for i in a:
    test = df1[df1['company_id']==i]
    mam = test.dropna()
    c = mam.standard_family1.unique().tolist()
    for idx, val in enumerate(c):
        test2 = test.fillna({'standard_family1':val})
        df2 = pd.concat([df2,test2],axis=0)

b = df1.company_id.unique()
c=[item for item in b if item not in a]
df3 = df1[df1.company_id.isin(c)]
df4 = pd.concat([df3,df2],axis=0,sort=True).drop_duplicates()
df4['patT_c'] = df4['patT_c'].fillna(0) 
df4['patn'] = df4['patn'].fillna(0) 
df4['patn_ws_w0'] = df4['patn_ws_w0'].fillna(0) 
df4['patT_c_ws_w0'] = df4['patT_c_ws_w0'].fillna(0) 
df4['patn_ws'] = df4['patn_ws'].fillna(0) 
df4['patT_c_ws'] = df4['patT_c_ws'].fillna(0) 
df4['patNS_c'] = df4['patTOT_c'] - df4['patT_c']
df4['patNS'] = df4['patTOT'] - df4['patn']

df4['sso'] = 'ETSI'
df4['POST'] = np.where(df4['year'] > 2014, 1, 0)
df4['TREAT_declaring'] = 0
df5 = df4[df4.standard_family1 != 11]
patenting_others = df5

patenting_others.to_csv(os.path.join(DATA, "data da usare/ETSI/10Others patents revised_all patents with weights2.csv"))

##Creating the patent portfolio of firms before and after 2015

pat_port = daa3[['company_id','ipc1','year']].drop_duplicates()

pat_port_tot = daa3[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])
pat_port_before = daa3[daa3.year<2015]
pat_port_before1 = pat_port_before[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])

pat_port.to_csv(os.path.join(DATA, "data da usare/ETSI/others patent portfolio_IEEE2.csv"))
pat_port_before1.to_csv(os.path.join(DATA, "data da usare/ETSI/others patent portfolio_IEEE_before20152.csv"))


#### ALL FIRMS FINAL DATABASE

##Adding standards information
std = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10standards_family_info.csv"))
age = std7[['standard_family1','publicationyear']].drop_duplicates()

a = std7.standard_family1.unique()
age_min = pd.DataFrame()

for x in a:
    add = age[age.standard_family1==x]
    min_year = add.publicationyear.min()
    add1 = add[add.publicationyear==min_year]
    age_min = pd.concat([age_min,add1], axis=0, sort= True)

age_min = age_min[age_min.standard_family1 != 'SCDB659749']
age_min = age_min[age_min.standard_family1 != 'SCDB661112']
df_age = pd.merge(age_min,std, on=['standard_family1'])
df_age['Sage'] = df_age['year'] - df_age['publicationyear']

std_info_new = df_age
a = std_info_new.standard_family1.unique()
std_info_new1 = pd.DataFrame()

for x in a:
    add = std_info_new[std_info_new.standard_family1 == x]
    add1 = add.sort_values("year")
    year = add1.year.unique()
    for y in year:
        if y< max(year):
            add2 = add1[add1.year==y]
            std_info_new1 = pd.concat([std_info_new1,add2],axis=0,sort=True)
        else:
            add3 = add1[add1.year==y]
            new_years = list(range(y+1, 2018))
            std_info_new1 = pd.concat([std_info_new1,add3],axis=0,sort=True)
            for yrs in new_years:
                new_df = pd.DataFrame({ 'standard_family1': [x], 'year': [yrs], 'publicationyear': add3['publicationyear'],'company_name': add3['company_name'],'disclosure_id': add3['disclosure_id'],'disclosure_id_TOTF': add3['disclosure_id_TOTF'], 'doc_idn': add3['doc_idn'],'doc_idn_TOTF': add3['doc_idn_TOTF'],'letter_id': add3['letter_id'],'letter_id_TOTF':add3['letter_id_TOTF'],'patn': add3['patn'], 'sepTOTF':add3['sepTOTF'],'sep_hld_TOTF':add3['sep_hld_TOTF']})
                std_info_new1 = pd.concat([std_info_new1,new_df],axis=0,sort=True)

std_info_new1.drop(['Unnamed: 0','Sage'],axis=1,inplace=True)

##Adding patenting behaviors

df = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"), low_memory=False)
patenting_others = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10Others patents revised_all patents with weights2.csv"))
patenting_firms = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10IEEE patents revised_all patents with weights2.csv"))

df1 = df[['E', 'RD', 'SALE', 'company_id',
       'curcd', 'inv_', 'inv_prop', 'loc', 'naics',
        'year', 'year-1',
       'year-2', 'S1', 'M1', 'L1', 'G1', 'logSALE', 'logRD', 'logRD2', 'patn_mean_before',
       'patn_mean_before_cited', 'VI',
       'U', 'D','TECH_before_var']].drop_duplicates()

tech_sim = pd.read_excel(os.path.join(DATA, "data da usare/ETSI/tech similarity before 2015_allNEW10.xlsx"))

tech_sim = df[['TECH_before','company_id']].drop_duplicates()

pat_others = patenting_others.drop_duplicates()
pat_firms = patenting_firms.drop_duplicates()
sample_all = pd.concat([pat_others,pat_firms],axis=0,sort=True)
sample_all1 = pd.merge(sample_all, tech_sim, on=['company_id'])

a = std_info_new1.standard_family1.unique()
b = sample_all1['standard_family1'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
sample_all2 = sample_all1[sample_all1.standard_family1.isin(kk)]

#sample_all2 = pd.merge(sample_all1,firms_charact1,on=['company_id','year'],how='right')

sample_right_years = sample_all2[sample_all2.year>2009]
sample_right_years1 = sample_right_years[sample_right_years.year<2019]
prova = sample_right_years1.groupby(['company_id','standard_family1'])['year'].nunique().reset_index()
prova1 = prova[prova.year>3]
prova2 = prova1[['company_id','standard_family1']].drop_duplicates()
sample_final_patenting = pd.merge(prova2,sample_right_years1,on=['company_id','standard_family1'])

# Check if any firm-standard pair has ONLY years before 2015
firms_with_only_pre2015 = (
    sample_final_patenting
    .groupby(['company_id', 'standard_family1'])
    .filter(lambda group: group['year'].max() < 2015)
)

# Get the unique list of these firms
bad_firms = firms_with_only_pre2015[['company_id', 'standard_family1']].drop_duplicates()

# Filter them out from the original dataset
sample_patenting = sample_final_patenting.merge(
    bad_firms, 
    on=['company_id', 'standard_family1'],
    how='left',
    indicator=True
).query('_merge == "left_only"').drop(columns='_merge')

##Merging infor about firms

a = sample_patenting['company_id'].unique()
b = df1['company_id'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
df2 = df1[df1.company_id.isin(kk)]

df3 = df2[['E','company_id', 'loc',
       'naics', 'year', 'logSALE',
       'logRD', 'logRD2']].drop_duplicates()


fn = pd.merge(sample_patenting,df3,on=['company_id','year'], how='right')
fn[['patNS','patNS_c','patTOT', 'patTOT_c','patT_c','patT_c_ws','patT_c_ws_w0','patn','patn_ws','patn_ws_w0']] = fn[['patNS','patNS_c','patTOT', 'patTOT_c','patT_c','patT_c_ws','patT_c_ws_w0','patn','patn_ws','patn_ws_w0']].fillna(0)
fn['sso']  = fn['sso'].fillna('ETSI')

prova = fn[fn.year<2015]
prova1 = fn[fn.year>2014]
a = prova['company_id'].unique()
b = prova1['company_id'].unique()
kk = set(a).intersection(b)
final = fn[fn.company_id.isin(kk)]

df1 = final.drop_duplicates()

std_info_new2 = std_info_new1[std_info_new1.year>2009]
add = std_info_new2.groupby('standard_family1')['year'].nunique().reset_index()
add1 = add[add.year>5]
a = add1.standard_family1.unique()
finall = df1[df1.standard_family1.isin(a)]

final1 = pd.merge(finall,std_info_new1, on=['standard_family1','year'],how='left').drop_duplicates()
final1['Sage'] = final1['year'] - final1['publicationyear']
final1[['company_name', 'disclosure_id', 'disclosure_id_TOTF',
       'doc_idn', 'doc_idn_TOTF', 'letter_id', 'letter_id_TOTF', 'patn_y',
       'sepTOTF', 'sep_hld_TOTF']] = final1[['company_name', 'disclosure_id', 'disclosure_id_TOTF',
       'doc_idn', 'doc_idn_TOTF', 'letter_id', 'letter_id_TOTF', 'patn_y',
       'sepTOTF', 'sep_hld_TOTF']].fillna(0)


final1.to_csv(os.path.join(DATA, "data da usare/ETSI/Final database lag 1_10std.csv"))




