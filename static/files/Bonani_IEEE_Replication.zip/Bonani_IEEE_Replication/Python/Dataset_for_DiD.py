import os
# ---------------------------------------------------------------------------
# Paths: all data are read from / written to the DATA folder.
# By default this is <replication package>/data. To run on the synthetic
# data instead, set the environment variable REPLICATION_DATA=data_synthetic.
# ---------------------------------------------------------------------------
try:
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
except NameError:  # interactive session: run from the package root
    ROOT = os.getcwd()
DATA = os.path.join(ROOT, os.environ.get("REPLICATION_DATA", "data"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols


####Dataset for Diff-in-diff analysis

final = pd.read_csv(os.path.join(DATA, "data da usare/Final database lag 1_10std558firms.csv"), low_memory=False)
tech_sim = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEW10.xlsx"))

#tech_sim = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEW_patents_with0.xlsx"))

##Data from tech distance based on 2012
#final = pd.read_csv(os.path.join(DATA, "data da usare/Final database lag 1_10std558firms2012.csv"), low_memory=False)
#tech_sim = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity before 2013_allNEW10.xlsx"))


final['TECH_before_var'] = final['TECH_before']
final.drop(['Unnamed: 0','TECH_before'],axis=1,inplace=True)

tech_sim = tech_sim[['company_id','TECH_before']]
#final = pd.merge(final,tech,on=['company_id'])

#tech_sim = final[['company_id','TECH_before']]
df = pd.DataFrame()
item = tech_sim.company_id.unique()

for x in item:
    pr1 = tech_sim[tech_sim.company_id==x]
    #pr1 = pr[pr.standard_family1==y]
    a = pr1['TECH_before'].iloc[0]
    q1 = 0.1801442
    q2 = 0.2542376
    q3 = 0.3521804
    q4 = 0.60152217 
    if a <= q1:
        pr1['quart_tehc'] = 0.25
    elif q1 < a <= q2:
        pr1['quart_tehc'] = 0.50
    elif q2 < a <= q3:
        pr1['quart_tehc'] = 0.75
    elif a > q3:
        pr1['quart_tehc'] = 1
    df = pd.concat([pr1,df],axis=0,sort=True)

#df1 = df.drop('TECH_before',axis=1).drop_duplicates()
df1 =df
final = pd.merge(final,df1,on=['company_id'])

#final['TREAT'] = 1-final['TECH_before']
final['TREAT'] = 1 + final['TECH_before']
#final['interaction'] = final['TREAT']*final['POST']
final['interaction'] = (final['TREAT'])*np.log(1+final['quart_tehc'])*final['POST']
final['interaction_check'] = final['TECH_before']*final['POST']
final['logPat'] = np.log(final['patn_ws']+1)
final['logPat_w0'] = np.log(final['patn_ws_w0']+1)
pd.get_dummies(final, 'standard_family1')
final['standards'] = pd.Categorical(final.standard_family1).codes
final['firms'] = pd.Categorical(final.company_id)
final['combination'] = final[['company_id','standard_family1']].agg(tuple, axis=1)
final['firms-standard-pair'] = final['combination'].factorize()[0]
final['logSALE'] = np.log(final['SALE']+1)
final['logPat_NS'] = np.log(final['patNS']+1)
final['logPat_cit'] = np.log(final['patT_c_ws']+1)
final['logPatTOT'] = np.log(final['patTOT']+1)
final['logRD'] = np.log(final['RD']+1)
final['logRD2'] = final['logRD']*final['logRD']

prova = final[final.year<2015]
mean_pat = prova['patn_ws'].mean()
prova1 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patn_ws'].mean().reset_index()
prova2 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patT_c_ws'].mean().reset_index()
prova1['patn_mean_before'] = prova1['patn_ws']
prova1.drop('patn_ws',axis=1,inplace=True)
prova2['patn_mean_before_cited'] = prova2['patT_c_ws']
prova2.drop('patT_c_ws',axis=1,inplace=True)

sample_final1 = pd.merge(final,prova1,on=['company_id'])
sample_final2 = pd.merge(sample_final1,prova2,on=['company_id'])
sample_final2['patn_nomr'] = sample_final2['patn_ws']/sample_final2['patn_mean_before']
sample_final2['patc_nomr'] = sample_final2['patT_c_ws']/sample_final2['patn_mean_before_cited']
sample_final2['logPatn'] = np.log(sample_final2['patn_nomr']+1)
sample_final2['logPatn'] = sample_final2['logPatn'].replace([np.inf, -np.inf], 0)

business_model = pd.read_csv(os.path.join(DATA, "data da usare/dic_lic_lic187.csv"))
sample_final3 = pd.merge(sample_final2, business_model,on=['company_id'], how='left')

tech_sim_var = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity before 2015NEW10.xlsx"))
tech_sim_var['TECH_before_var'] = tech_sim_var['TECH_before']
tech_sim_var1 = tech_sim_var[['company_id', 'standard_family1','TECH_before_var']].drop_duplicates()
sample_final4 = sample_final3.drop(['TECH_before_var','Unnamed: 0'],axis=1)
sample_final5 = pd.merge(sample_final4,tech_sim_var1,on=['company_id','standard_family1'])
sample_final5.to_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall558.csv"))


###543 is the number of firms that have data post 2014 but also before 2014, so more than 1 year in the pre period

prova =  sample_final5[sample_final5.year<2014]
a = prova.company_id.unique()

sample_final6 = sample_final5[sample_final5.company_id.isin(a)]
sample_final6.to_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"))

#sample_final6.to_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall5432012.csv"))


###Final database with tech similarity based on before 2013

##Data based on 2012
firms = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"),low_memory=False)
a = firms.company_id.unique()
b = sample_final5.company_id.unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]

sample_final6 = sample_final5[sample_final5.company_id.isin(kk)]
sample_final6.to_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall5432012.csv"))

###Final database including average total patenting

firms = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"),low_memory=False)

group4 = firms[firms.quart_tehc==0.25]
group41 = group4.groupby(['year'])['patTOT'].mean().reset_index()
group41['avrg_patenting'] = group41['patTOT']
group41.drop('patTOT',axis=1,inplace=True)
group41['quart_tehc'] = 0.25

group3 = firms[firms.quart_tehc==0.50]
group31 = group3.groupby(['year'])['patTOT'].mean().reset_index()
group31['avrg_patenting'] = group31['patTOT']
group31.drop('patTOT',axis=1,inplace=True)
group31['quart_tehc'] = 0.50

group2 = firms[firms.quart_tehc==0.75]
group21 = group2.groupby(['year'])['patTOT'].mean().reset_index()
group21['avrg_patenting'] = group21['patTOT']
group21.drop('patTOT',axis=1,inplace=True)
group21['quart_tehc'] = 0.75

group1 = firms[firms.quart_tehc==1]
group11 = group1.groupby(['year'])['patTOT'].mean().reset_index()
group11['avrg_patenting'] = group11['patTOT']
group11.drop('patTOT',axis=1,inplace=True)
group11['quart_tehc'] = 1

groups = pd.concat([group41,group31,group21,group11], axis=0,sort=True)

sample = pd.merge(firms,groups,on=['quart_tehc','year'])
sample.to_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543_v2.csv"))








