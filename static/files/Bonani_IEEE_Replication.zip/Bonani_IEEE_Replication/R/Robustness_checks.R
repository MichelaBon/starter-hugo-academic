# ---------------------------------------------------------------------------
# Paths: run this script from the replication package root, e.g.
#   Rscript R/Main_Analysis.R
# Data are read from the DATA folder (default "data"). To run on the synthetic
# data instead:  REPLICATION_DATA=data_synthetic Rscript R/Main_Analysis.R
# Tables (.tex) are written to the "output" folder.
# ---------------------------------------------------------------------------
DATA <- Sys.getenv("REPLICATION_DATA", "data")
OUT  <- "output"
dir.create(OUT, showWarnings = FALSE)

# Load libraries
library(data.table)
library(fixest)  
library(car)       
library(lmtest)   
library(sandwich) 


###STANDARD-PATENTS WITH ZERO INCLUDED IN WEIGHTS
# Load data
df <- fread(file.path(DATA, "data da usare/final_lag1_TECHall543.csv"))

# Create grouping variables
df[, group_country := .GRP, by = loc]
df[, group_industryFE := .GRP, by = naics]
df[, firms_fe := .GRP, by = company_id]
df[, std_fe := .GRP, by = standard_family1]
df[, firms_std_fe := .GRP, by = .(company_id, standard_family1)]
df[, group_Sage := .GRP, by = Sage]

# Create transformed variables
df[, logsephld := log(sep_hld_TOTF + 1)]
df[, logdocid := log(doc_idn + 1)]
df[, loge := log(E + 1)]
df[, logsale := logSALE]


# Create quartiles based on tech_before
df[, quant := cut(TECH_before, 
                 breaks = quantile(TECH_before, probs = 0:4/4, na.rm = TRUE),
                 labels = FALSE, include.lowest = TRUE)]

df[, quart_tech_u := fcase(
  quant == 1, 0.25,
  quant == 2, 0.50,
  quant == 3, 0.75,
  quant == 4, 1.00
)]

df[, treat1 := (1 - quart_tech_u) + 0.25]
df[, treatt := 1 - TECH_before]
df[, treattt := 1 - TECH_before_var]

# Time variables
df[, post := fifelse(year > 2014, 1L, 0L)]
df[, post_antic := fifelse(year == 2014, 1L, 0L)]
# Alternative definitions:
df[, post_antic_1 := fifelse(year > 2012 & year < 2015, 1L, 0L)]
df[, post_antic_2013 := fifelse(year == 2013, 1L, 0L)]



# Create treatment groups
df[, group_treatment := fcase(
  treat1 == 0.25, 1L,
  treat1 == 0.50, 2L,
  treat1 == 0.75, 3L,
  treat1 == 1.00, 4L
)]

# Create group dummies (not needed in R's formula syntax)
df[, group1 := fifelse(group_treatment == 1, 1L, 0L)]
df[, group2 := fifelse(group_treatment == 2, 1L, 0L)]
df[, group3 := fifelse(group_treatment == 3, 1L, 0L)]
df[, group4 := fifelse(group_treatment == 4, 1L, 0L)]
df[, group1 := 0L]  # Set as reference



# Filter for Q1 vs Q2 comparison
df_q12 <- df[treat1 %in% c(0.25, 0.50)]
df_q12[, group_treatment2Q := fifelse(treat1 == 0.50, 1L, 0L)]

# Filter for Q1 vs Q3 comparison
df_q13 <- df[treat1 %in% c(0.25, 0.75)]
df_q13[, group_treatment2Q := fifelse(treat1 == 0.75, 1L, 0L)]

# Filter for Q1 vs Q4 comparison
df_q14 <- df[treat1 %in% c(0.25, 1)]
df_q14[, group_treatment2Q := fifelse(treat1 == 1, 1L, 0L)]

# Function to run the zero-included weights estimation
run_zero_weights_estimation <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  # Run the model
  model <- fepois(
    patn_ws_w0 ~ 
      # DiD terms (policy effects)
      group_treatment2Q:post +
      
      post +
      group_treatment2Q +
      
      # Group-specific trends by standard age
      i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
      
      # Controls
      treattt + logsale + logsephld + logdocid  + 
      i(group_Sage) |  # Standard age FE (non-linear adjustments)
      
      # Fixed effects
      std_fe + firms_fe,
    
    data = data,
    vcov = ~firms_std_fe
  )
  
}

run_zero_weights_estimation_antic <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  # Run the model
  model <- fepois(
    patn_ws_w0 ~ 
      # DiD terms (policy effects)
      group_treatment2Q:post +
      group_treatment2Q:post_antic + 
      group_treatment2Q:post +
      post_antic+
      post +
      group_treatment2Q +
      
      # Group-specific trends by standard age
      i(group_treatment2Q):sage_cont +  # Treated vs. control trends by age
      
      # Controls
      treattt + logsale + logsephld + logdocid  + 
      i(group_Sage) |  # Standard age FE (non-linear adjustments)
      
      # Fixed effects
      std_fe + firms_fe,
    
    data = data,
    vcov = ~firms_std_fe
  )
  
}


# Apply to all three datasets
q12_wz = run_zero_weights_estimation(df_q12)
q13_wz = run_zero_weights_estimation(df_q13)
q14_wz = run_zero_weights_estimation(df_q14)

q12_wz_ant = run_zero_weights_estimation_antic(df_q12)
q13_wz_ant = run_zero_weights_estimation_antic(df_q13)
q14_wz_ant = run_zero_weights_estimation_antic(df_q14)



###BLUETOOTH STANDARDS

# Load data
df <- fread(file.path(DATA, "data da usare/final_lag1_TECHallBluetooth.csv"))

# Create grouping variables
df[, group_country := .GRP, by = loc]
df[, group_industryFE := .GRP, by = naics]
df[, firms_fe := .GRP, by = company_id]
df[, std_fe := .GRP, by = standard_family1]
df[, firms_std_fe := .GRP, by = .(company_id, standard_family1)]
df[, group_Sage := .GRP, by = Sage]

# Create transformed variables
df[, logsephld := log(sep_hld_TOTF + 1)]
df[, logdocid := log(doc_idn + 1)]
df[, loge := log(E + 1)]
df[, logsale := logSALE]


# Create quartiles based on tech_before
df[, quant := cut(TECH_before, 
                 breaks = quantile(TECH_before, probs = 0:4/4, na.rm = TRUE),
                 labels = FALSE, include.lowest = TRUE)]

df[, quart_tech_u := fcase(
  quant == 1, 0.25,
  quant == 2, 0.50,
  quant == 3, 0.75,
  quant == 4, 1.00
)]

df[, treat1 := (1 - quart_tech_u) + 0.25]
df[, treatt := 1 - TECH_before]

# Time variables
df[, post := fifelse(year > 2014, 1L, 0L)]
df[, post_antic := fifelse(year == 2014, 1L, 0L)]
# Alternative definitions:
# df[, post_antic := fifelse(year > 2012 & year < 2015, 1L, 0L)]
# df[, pre := fifelse(year < 2013 & year > 2010, 1L, 0L)]



# Create treatment groups
df[, group_treatment := fcase(
  treat1 == 0.25, 1L,
  treat1 == 0.50, 2L,
  treat1 == 0.75, 3L,
  treat1 == 1.00, 4L
)]

# Create group dummies (not needed in R's formula syntax)
df[, group1 := fifelse(group_treatment == 1, 1L, 0L)]
df[, group2 := fifelse(group_treatment == 2, 1L, 0L)]
df[, group3 := fifelse(group_treatment == 3, 1L, 0L)]
df[, group4 := fifelse(group_treatment == 4, 1L, 0L)]
df[, group1 := 0L]  # Set as reference



# Filter for Q1 vs Q2 comparison
df_q12 <- df[treat1 %in% c(0.25, 0.50)]
df_q12[, group_treatment2Q := fifelse(treat1 == 0.50, 1L, 0L)]

# Filter for Q1 vs Q3 comparison
df_q13 <- df[treat1 %in% c(0.25, 0.75)]
df_q13[, group_treatment2Q := fifelse(treat1 == 0.75, 1L, 0L)]

# Filter for Q1 vs Q4 comparison
df_q14 <- df[treat1 %in% c(0.25, 1)]
df_q14[, group_treatment2Q := fifelse(treat1 == 1, 1L, 0L)]



# Function to run the bluetooth estimation
run_sage_trends_post <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post + 
      post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treatt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Function for Specification 3: Sage Trends (Regular Anticipation Effect)
run_sage_trends_antic <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post_antic + group_treatment2Q:post + 
      post_antic + post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treatt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}


q12_blue = run_sage_trends_post(df_q12)
q13_blue = run_sage_trends_post(df_q13)
q14_blue = run_sage_trends_post(df_q14)

q12_blue_antic = run_sage_trends_antic(df_q12)
q13_blue_antic = run_sage_trends_antic(df_q13)
q14_blue_antic = run_sage_trends_antic(df_q14)

###TECH DISTANCE DEFINED IN 2012

# Load data
df <- fread(file.path(DATA, "data da usare/final_lag1_TECHall5432012.csv"))

# Create grouping variables
df[, group_country := .GRP, by = loc]
df[, group_industryFE := .GRP, by = naics]
df[, firms_fe := .GRP, by = company_id]
df[, std_fe := .GRP, by = standard_family1]
df[, firms_std_fe := .GRP, by = .(company_id, standard_family1)]
df[, group_Sage := .GRP, by = Sage]

# Create transformed variables
df[, logsephld := log(sep_hld_TOTF + 1)]
df[, logdocid := log(doc_idn + 1)]
df[, loge := log(E + 1)]
df[, logsale := logSALE]


# Create quartiles based on tech_before
df[, quant := cut(TECH_before, 
                 breaks = quantile(TECH_before, probs = 0:4/4, na.rm = TRUE),
                 labels = FALSE, include.lowest = TRUE)]

df[, quart_tech_u := fcase(
  quant == 1, 0.25,
  quant == 2, 0.50,
  quant == 3, 0.75,
  quant == 4, 1.00
)]

df[, treat1 := (1 - quart_tech_u) + 0.25]
df[, treatt := 1 - TECH_before]
df[, treattt := 1 - TECH_before_var]

# Time variables
df[, post := fifelse(year > 2014, 1L, 0L)]
df[, post_antic := fifelse(year == 2014, 1L, 0L)]
# Alternative definitions:
# df[, post_antic := fifelse(year > 2012 & year < 2015, 1L, 0L)]
# df[, pre := fifelse(year < 2013 & year > 2010, 1L, 0L)]



# Create treatment groups
df[, group_treatment := fcase(
  treat1 == 0.25, 1L,
  treat1 == 0.50, 2L,
  treat1 == 0.75, 3L,
  treat1 == 1.00, 4L
)]

# Create group dummies (not needed in R's formula syntax)
df[, group1 := fifelse(group_treatment == 1, 1L, 0L)]
df[, group2 := fifelse(group_treatment == 2, 1L, 0L)]
df[, group3 := fifelse(group_treatment == 3, 1L, 0L)]
df[, group4 := fifelse(group_treatment == 4, 1L, 0L)]
df[, group1 := 0L]  # Set as reference

# Filter for Q1 vs Q2 comparison
df_q12 <- df[treat1 %in% c(0.25, 0.50)]
df_q12[, group_treatment2Q := fifelse(treat1 == 0.50, 1L, 0L)]

# Filter for Q1 vs Q3 comparison
df_q13 <- df[treat1 %in% c(0.25, 0.75)]
df_q13[, group_treatment2Q := fifelse(treat1 == 0.75, 1L, 0L)]

# Filter for Q1 vs Q4 comparison
df_q14 <- df[treat1 %in% c(0.25, 1)]
df_q14[, group_treatment2Q := fifelse(treat1 == 1, 1L, 0L)]




# Function to run the Technology2012 estimation

run_sage_trends_post <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post + 
      post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treattt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Function for Specification 3: Sage Trends (Regular Anticipation Effect)
run_sage_trends_antic <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post_antic + group_treatment2Q:post + 
      post_antic + post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treattt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}


q12_2012 = run_sage_trends_post(df_q12)
q13_2012 = run_sage_trends_post(df_q13)
q14_2012 = run_sage_trends_post(df_q14)

q12_2012_antic = run_sage_trends_antic(df_q12)
q13_2012_antic = run_sage_trends_antic(df_q13)
q14_2012_antic = run_sage_trends_antic(df_q14)


# Function to extract coefficients from models 

extract_robustness_coefs <- function(model, coef_type = "post") {
  tryCatch({
    if (is.null(model)) {
      return(data.frame(estimate = NA, std_error = NA, p_value = NA))
    }
    
    # Get coefficient names from the model
    coef_names <- names(coef(model))
    cat("Available coefficients for", coef_type, ":", paste(coef_names, collapse = ", "), "\n")
    
    # Look for the specific coefficient based on type
    if (coef_type == "post") {
      # For post coefficient: look for interaction with post (but not post_antic)
      target_coef <- coef_names[grepl("group_treatment2Q.*post[^_antic]|post[^_antic].*group_treatment2Q", coef_names)]
      if (length(target_coef) == 0) {
        # Fallback: look for any post coefficient that doesn't contain "antic"
        target_coef <- coef_names[grepl("post", coef_names) & !grepl("antic", coef_names)]
      }
    } else if (coef_type == "antic") {
      # For anticipation coefficient: look specifically for post_antic
      target_coef <- coef_names[grepl("group_treatment2Q.*post_antic|post_antic.*group_treatment2Q", coef_names)]
      if (length(target_coef) == 0) {
        # Fallback: look for any coefficient containing "antic"
        target_coef <- coef_names[grepl("antic", coef_names)]
      }
    }
    
    if (length(target_coef) == 0) {
      cat("No target coefficient found for", coef_type, "\n")
      return(data.frame(estimate = NA, std_error = NA, p_value = NA))
    }
    
    # Take the first match
    coef_name <- target_coef[1]
    cat("Using coefficient for", coef_type, ":", coef_name, "\n")
    
    # Extract standard error
    vcov_matrix <- vcov(model, cluster = ~firms_std_fe)
    std_error <- sqrt(vcov_matrix[coef_name, coef_name])
    
    # Extract p-value
    p_value <- summary(model)$coeftable[coef_name, "Pr(>|z|)"]
    
    return(data.frame(
      estimate = coef(model)[coef_name],
      std_error = std_error,
      p_value = p_value
    ))
  }, error = function(e) {
    cat("Error:", e$message, "\n")
    return(data.frame(estimate = NA, std_error = NA, p_value = NA))
  })
}

# Helper: format a coefficient with significance stars and standard error
format_coef <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) {
    return("&")
  }
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                  ifelse(abs(estimate) > 1.96 * se, "^{**}",
                         ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted  <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ & ", se_formatted)
}

# Collect the robustness models (q12 = Q1 vs Q2, q13 = Q1 vs Q3, q14 = Q1 vs Q4)
model_sets <- list(
  blue_post      = list(q12 = q12_blue,       q13 = q13_blue,       q14 = q14_blue),
  blue_antic     = list(q12 = q12_blue_antic, q13 = q13_blue_antic, q14 = q14_blue_antic),
  wz_post        = list(q12 = q12_wz,         q13 = q13_wz,         q14 = q14_wz),
  wz_antic       = list(q12 = q12_wz_ant,     q13 = q13_wz_ant,     q14 = q14_wz_ant),
  tech2012_post  = list(q12 = q12_2012,       q13 = q13_2012,       q14 = q14_2012),
  tech2012_antic = list(q12 = q12_2012_antic, q13 = q13_2012_antic, q14 = q14_2012_antic)
)
robustness_results <- list()

#Extract coefficients
for (set_name in names(model_sets)) {
  robustness_results[[set_name]] <- list()
  is_antic <- grepl("antic", set_name)
  
  for (q in c("q12", "q13", "q14")) {
    model <- model_sets[[set_name]][[q]]
    
    if (is_antic) {
      # For anticipation models
      cat("\nExtracting from", set_name, q, "(anticipation model):\n")
      robustness_results[[set_name]][[q]] <- list(
        post_coef = extract_robustness_coefs(model, "post"),
        antic_coef = extract_robustness_coefs(model, "antic")
      )
    } else {
      # For post-only models
      cat("\nExtracting from", set_name, q, "(post-only model):\n")
      robustness_results[[set_name]][[q]] <- list(
        post_coef = extract_robustness_coefs(model, "post"),
        antic_coef = data.frame(estimate = NA, std_error = NA, p_value = NA)
      )
    }
  }
}


cat("\n=== Final extracted coefficients ===\n")
for (set_name in names(robustness_results)) {
  cat("\n", set_name, ":\n")
  for (q in c("q12", "q13", "q14")) {
    result <- robustness_results[[set_name]][[q]]
    cat("  ", q, ": post =", result$post_coef$estimate, 
        ", antic =", result$antic_coef$estimate, "\n")
  }
}

# Create table content
table_content <- ""

# Post-Period section
table_content <- paste0(table_content, " Post-Period &&&&&&\\\\\n")
for (q in c("q12", "q13", "q14")) {
  quartile_name <- switch(q, "q12" = "2nd", "q13" = "3rd", "q14" = "4th")
  
  # Format each coefficient
  # For post columns: use post coefficient from post models
  blue_post <- format_coef(robustness_results$blue_post[[q]]$post_coef$estimate, 
                          robustness_results$blue_post[[q]]$post_coef$std_error)
  
  # For antic columns: use post coefficient from antic models 
  blue_antic <- format_coef(robustness_results$blue_antic[[q]]$post_coef$estimate, 
                           robustness_results$blue_antic[[q]]$post_coef$std_error)
  
  wz_post <- format_coef(robustness_results$wz_post[[q]]$post_coef$estimate, 
                        robustness_results$wz_post[[q]]$post_coef$std_error)
  
  wz_antic <- format_coef(robustness_results$wz_antic[[q]]$post_coef$estimate, 
                         robustness_results$wz_antic[[q]]$post_coef$std_error)
  
  tech2012_post <- format_coef(robustness_results$tech2012_post[[q]]$post_coef$estimate, 
                              robustness_results$tech2012_post[[q]]$post_coef$std_error)
  
  tech2012_antic <- format_coef(robustness_results$tech2012_antic[[q]]$post_coef$estimate, 
                               robustness_results$tech2012_antic[[q]]$post_coef$std_error)
  
  table_content <- paste0(table_content,
    " & ", quartile_name, " Quartile &",
    paste(blue_post, blue_antic, wz_post, wz_antic,
          tech2012_post, tech2012_antic, sep = " & "),
    "\\\\\n"
  )
}

# Create the complete LaTeX table
latex_table <- paste0(
"\\begin{table}[t]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Effect of IEEE policy change - Robustness checks I}
\\label{tab:robustness1}
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{7}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{Bluetooth}&\\multicolumn{2}{c}{Standard-related Patents (w0)}&\\multicolumn{2}{c}{Tech Distance 2012}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3} \\cmidrule{4-5} \\cmidrule{6-7} & & Post & Antic & Post & Antic & Post & Antic \\\\\t 
\\midrule\n",
table_content,
"\\hline
&&&&&&\\\\
Covariates & & Yes& Yes & Yes& Yes & Yes& Yes  \\\\
Standard Age FE & & Yes& Yes & Yes& Yes & Yes& Yes    \\\\
Standard FE & & Yes& Yes & Yes& Yes & Yes& Yes  \\\\
Firm FE & & Yes& Yes & Yes& Yes & Yes& Yes  \\\\

\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: The dependent variable is the weighted number of patents per firm-standard in the first and third columns. The first column reports the results for Bluetooth standards. In the second column, the dependent variable is weighted to account for zeros in the IPC classes related to the standard. In the third column, firms are clustered based on their patent portfolios from 2000 to 2012. The method of estimation is maximum likelihood for the Poisson model. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard. \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print the table
cat(latex_table)

# Write to file
writeLines(latex_table, file.path(OUT, "robustness_checks_table.tex"))

# Print summary of missing models
cat("\n=== Model Availability Summary ===\n")
for (set_name in names(model_sets)) {
  available_models <- sum(!sapply(model_sets[[set_name]], is.null))
  cat(set_name, ":", available_models, "/ 3 models available\n")
}