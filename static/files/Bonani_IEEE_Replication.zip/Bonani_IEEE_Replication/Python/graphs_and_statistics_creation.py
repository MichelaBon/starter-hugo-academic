import os
# ---------------------------------------------------------------------------
# Paths: all data are read from / written to the DATA folder.
# By default this is <replication package>/data. To run on the synthetic
# data instead, set the environment variable REPLICATION_DATA=data_synthetic.
# ---------------------------------------------------------------------------
try:
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
except NameError:  # interactive session: run from the package root
    ROOT = os.getcwd()
DATA = os.path.join(ROOT, os.environ.get("REPLICATION_DATA", "data"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import statistics 
import seaborn as sns

###Scatter plot showing the correlation between gamma and firm's type

final = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"),low_memory=False)
vertinteg = final[final.VI==1]
upstream = final[final.U==1]
downstream = final[final.D==1]

df1  =  pd.concat([vertinteg, upstream, downstream], axis=0,sort=True)
df  = df1[['company_id','TECH_before','VI','D','U']].drop_duplicates()

# Create a single categorical variable for firm type
def firm_type(row):
    if row['VI'] == 1:
        return 'Vertically Integrated'
    elif row['U'] == 1:
        return 'Upstream'
    elif row['D'] == 1:
        return 'Downstream'
    else:
        return 'Other'

df['FirmType'] = df.apply(firm_type, axis=1)

# Plot distribution of gamma (TECH_before) across firm types
plt.figure(figsize=(8, 6))
sns.violinplot(data=df, x='FirmType', y='TECH_before', inner='box', cut=0, palette='muted')

#plt.title('Technology Similarity (γ) by Firm Type')
plt.ylabel('Technological Similarity (γ)')
plt.xlabel('')
plt.xticks(rotation=20)
plt.tight_layout()
plt.show()

###Parallel trends graph####


##Creation of the dataset for the parallel trends assumption checking -standard-related patents IEEE
tech_sim = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEW10.xlsx"))
patenting_others = pd.read_csv(os.path.join(DATA, "data da usare/10Others patents revised_all patents with weights.csv"))
patenting_firms = pd.read_csv(os.path.join(DATA, "data da usare/10IEEE patents revised_all patents with weights.csv"))
final1 = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543_v2.csv"),low_memory=False)


tech_sim1 = tech_sim.sort_values('TECH_before')
a = final1.company_id.unique()
tech_sim1 = tech_sim1[tech_sim1.company_id.isin(a)]
np.quantile(tech_sim1['TECH_before'], [0.25,0.50,0.75,1])
df = pd.DataFrame()
item = tech_sim.company_id.unique()
#tech_sim['TECH_before'] = tech_sim['TECH_before'].abs()

for x in item:
    pr1 = tech_sim[tech_sim.company_id==x]
    #pr1 = pr[pr.standard_family1==y]
    a = pr1['TECH_before'].iloc[0]
    q1 = 0.1801442
    q2 = 0.2542376
    q3 = 0.3521804
    q4 = 0.60152217 
    if 0 < a <= q1:
        pr1['quart_tehc'] = 0.25
    elif q1 < a <= q2:
        pr1['quart_tehc'] = 0.50
    elif q2 < a <= q3:
        pr1['quart_tehc'] = 0.75
    elif a > q3:
        pr1['quart_tehc'] = 1
    elif a == 0:
        pr1['quart_tehc'] = 0
    df = pd.concat([pr1,df],axis=0,sort=True)


pat_others = patenting_others[['company_id','standard_family1','patT_c', 'patT_c_ws','patn', 'patn_ws','patn_ws_w0','year','patTOT']].drop_duplicates()
pat_firms = patenting_firms[['company_id','standard_family1','patT_c', 'patT_c_ws','patn', 'patn_ws','patn_ws_w0','year','patTOT']].drop_duplicates()
sample_all = pd.concat([pat_others,pat_firms],axis=0,sort=True)
df.drop('standard_family1',axis=1,inplace=True)
sample_all1 = pd.merge(sample_all, df, on=['company_id'])

sample_right_years = sample_all1[sample_all1.year>2009]
sample_right_years1 = sample_right_years[sample_right_years.year<2018]
prova = sample_right_years1.groupby(['company_id','standard_family1'])['year'].nunique().reset_index()
prova1 = prova[prova.year>3]
prova2 = prova1[['company_id','standard_family1']].drop_duplicates()
sample_finall = pd.merge(prova2,sample_right_years1,on=['company_id','standard_family1'])
a = final1.company_id.unique()
sample_final = sample_finall[sample_finall.company_id.isin(a)]

prova = sample_final[sample_final.year<2015]
mean_pat = prova['patn_ws'].mean()
prova1 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patn_ws'].mean().reset_index()
prova2 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patT_c_ws'].mean().reset_index()

sample_final1 = pd.merge(sample_final,prova1,on=['company_id'])
sample_final2 = pd.merge(sample_final1,prova2,on=['company_id'])
sample_final2['patn_nomr'] = sample_final2['patn_ws_x']/sample_final2['patn_ws_y']
sample_final2['patc_nomr'] = sample_final2['patT_c_ws_x']/sample_final2['patT_c_ws_y']

a = [0,0.25]
group1 = sample_final2[sample_final2.quart_tehc.isin(a)]
group2 = sample_final2[sample_final2.quart_tehc == 0.50]
group3 = sample_final2[sample_final2.quart_tehc == 0.75]
group4 = sample_final2[sample_final2.quart_tehc == 1]

group1['logPat'] = np.log(group1['patT_c_ws_x']+1).replace(np.inf,0)
group1['logPatn'] = np.log(group1['patn_nomr']+1).replace(np.inf,0)
group1['patn_nomr'] = group1['patn_nomr'].replace(np.inf,0)

group1_mean_nc_n = group1.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group1_mean_nc_log_n = group1.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()

group2['logPat'] = np.log(group2['patT_c_ws_x']+1)
group2['logPatn'] = np.log(group2['patn_nomr']+1)

group2_mean_nc_n = group2.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group2_mean_nc_log_n = group2.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()

group3['logPat'] = np.log(group3['patT_c_ws_x']+1)
group3['logPatn'] = np.log(group3['patn_nomr']+1)

group3_mean_nc_n = group3.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group3_mean_nc_log_n = group3.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()

group4['logPat'] = np.log(group4['patT_c_ws_x']+1)
group4['logPatn'] = np.log(group4['patn_nomr']+1)

group4_mean_nc_n = group4.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group4_mean_nc_log_n = group4.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()


plt.plot(group4_mean_nc_n['year'], group1_mean_nc_n['patn_nomr'],color='darkgrey', linestyle='-' ,label="group4")
plt.plot(group4_mean_nc_n['year'], group2_mean_nc_n['patn_nomr'], color='grey', linestyle='--',label="group3")
plt.plot(group4_mean_nc_n['year'], group3_mean_nc_n['patn_nomr'], color='dimgrey', linestyle='-.',label="group2")
plt.plot(group4_mean_nc_n['year'], group4_mean_nc_n['patn_nomr'],color='black', linestyle=':', label="group1")
#ax.set_xlabel()
plt.ylabel('Mean Patents filed per firm-standard')
plt.axvline(x=2015,color='lightgrey', linestyle='--')
plt.axvline(x=2013,color='lightgrey', linestyle='--')
plt.legend()
plt.show()


##Creation of the dataset for the parallel trends checking -standard-related patents ETSI (IEEE firms)
tech_sim = pd.read_excel(os.path.join(DATA, "data da usare/ETSI/tech similarity before 2015_allNEW10.xlsx"))
patenting_others = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10Others patents revised_all patents with weights2.csv"))
patenting_firms = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10IEEE patents revised_all patents with weights2.csv"))
final1 = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"),low_memory=False)

tech_sim1 = tech_sim.sort_values('TECH_before')
a = final1.company_id.unique()
tech_sim1 = tech_sim1[tech_sim1.company_id.isin(a)]
np.quantile(tech_sim1['TECH_before'], [0.25,0.50,0.75,1])
df = pd.DataFrame()
item = tech_sim.company_id.unique()
#tech_sim['TECH_before'] = tech_sim['TECH_before'].abs()

for x in item:
    pr1 = tech_sim[tech_sim.company_id==x]
    #pr1 = pr[pr.standard_family1==y]
    a = pr1['TECH_before'].iloc[0]
    q1 = 0.1801442
    q2 = 0.2542376
    q3 = 0.3521804
    q4 = 0.60152217 
    if 0 < a <= q1:
        pr1['quart_tehc'] = 0.25
    elif q1 < a <= q2:
        pr1['quart_tehc'] = 0.50
    elif q2 < a <= q3:
        pr1['quart_tehc'] = 0.75
    elif a > q3:
        pr1['quart_tehc'] = 1
    elif a == 0:
        pr1['quart_tehc'] = 0
    df = pd.concat([pr1,df],axis=0,sort=True)

pat_others = patenting_others[['company_id','standard_family1','patT_c', 'patT_c_ws','patn', 'patn_ws','patn_ws_w0','year','patTOT']].drop_duplicates()
pat_firms = patenting_firms[['company_id','standard_family1','patT_c', 'patT_c_ws','patn', 'patn_ws','patn_ws_w0','year','patTOT']].drop_duplicates()
sample_all = pd.concat([pat_others,pat_firms],axis=0,sort=True)
df.drop('standard_family1',axis=1,inplace=True)
sample_all1 = pd.merge(sample_all, df, on=['company_id'])

sample_right_years = sample_all1[sample_all1.year>2009]
sample_right_years1 = sample_right_years[sample_right_years.year<2018]
prova = sample_right_years1.groupby(['company_id','standard_family1'])['year'].nunique().reset_index()
prova1 = prova[prova.year>3]
prova2 = prova1[['company_id','standard_family1']].drop_duplicates()
sample_finall = pd.merge(prova2,sample_right_years1,on=['company_id','standard_family1'])
a = final1.company_id.unique()
sample_final = sample_finall[sample_finall.company_id.isin(a)]

prova = sample_final[sample_final.year<2015]
mean_pat = prova['patn_ws'].mean()
prova1 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patn_ws'].mean().reset_index()
prova2 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patT_c_ws'].mean().reset_index()

sample_final1 = pd.merge(sample_final,prova1,on=['company_id'])
sample_final2 = pd.merge(sample_final1,prova2,on=['company_id'])
sample_final2['patn_nomr'] = sample_final2['patn_ws_x']/sample_final2['patn_ws_y']
sample_final2['patc_nomr'] = sample_final2['patT_c_ws_x']/sample_final2['patT_c_ws_y']

a = [0,0.25]
group1 = sample_final2[sample_final2.quart_tehc.isin(a)]
group2 = sample_final2[sample_final2.quart_tehc == 0.50]
group3 = sample_final2[sample_final2.quart_tehc == 0.75]
group4 = sample_final2[sample_final2.quart_tehc == 1]

group1['logPat'] = np.log(group1['patT_c_ws_x']+1).replace(np.inf,0)
group1['logPatn'] = np.log(group1['patn_nomr']+1).replace(np.inf,0)
group1['patn_nomr'] = group1['patn_nomr'].replace(np.inf,0)

group1_mean_nc_n = group1.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group1_mean_nc_log_n = group1.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()

group2['logPat'] = np.log(group2['patT_c_ws_x']+1)
group2['logPatn'] = np.log(group2['patn_nomr']+1)

group2_mean_nc_n = group2.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group2_mean_nc_log_n = group2.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()

group3['logPat'] = np.log(group3['patT_c_ws_x']+1)
group3['logPatn'] = np.log(group3['patn_nomr']+1)

group3_mean_nc_n = group3.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group3_mean_nc_log_n = group3.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()

group4['logPat'] = np.log(group4['patT_c_ws_x']+1)
group4['logPatn'] = np.log(group4['patn_nomr']+1)

group4_mean_nc_n = group4.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_nomr'].mean().reset_index()
group4_mean_nc_log_n = group4.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('year')['logPatn'].mean().reset_index()

plt.plot(group4_mean_nc_n['year'], group1_mean_nc_n['patn_nomr'],color='darkgrey', linestyle='-' ,label="group4")
plt.plot(group4_mean_nc_n['year'], group2_mean_nc_n['patn_nomr'], color='grey', linestyle='--',label="group3")
plt.plot(group4_mean_nc_n['year'], group3_mean_nc_n['patn_nomr'], color='dimgrey', linestyle='-.',label="group2")
plt.plot(group4_mean_nc_n['year'], group4_mean_nc_n['patn_nomr'],color='black', linestyle=':', label="group1")
#ax.set_xlabel()
plt.ylabel('Mean Patents filed per firm-standard')
plt.axvline(x=2015,color='lightgrey', linestyle='--')
plt.axvline(x=2013,color='lightgrey', linestyle='--')
plt.legend()
plt.show()

####Graphs for ATE effects and confidence intervals #####

###Non-standard related patents

data = {
    "Period": ["Anticipation", "Anticipation", "Anticipation",
               "Post", "Post", "Post"],
    "Quartile": ["2nd Quartile", "3rd Quartile", "4th Quartile",
                 "2nd Quartile", "3rd Quartile", "4th Quartile"],
    "Coefficient": [0.252, 0.093, 0.349,
                    0.165, 0.106, 0.555],
    "SE": [0.040, 0.048, 0.057,
           0.058, 0.073, 0.075]
}

df = pd.DataFrame(data)
df["CI_low"] = df["Coefficient"] - 1.96 * df["SE"]
df["CI_high"] = df["Coefficient"] + 1.96 * df["SE"]

fig, ax = plt.subplots(figsize=(7, 5))

quartiles = df["Quartile"].unique()
x_positions = range(len(quartiles))

for i, period in enumerate(df["Period"].unique()):
    subset = df[df["Period"] == period]
    ax.errorbar(
        x=[x + i*0.15 for x in x_positions],  
        y=subset["Coefficient"],
        yerr=1.96*subset["SE"],
        fmt="o",
        label=period,
        capsize=4
    )

ax.axhline(0, color="gray", linestyle="--", linewidth=1)
ax.set_xticks(x_positions)
ax.set_xticklabels(quartiles)
ax.set_ylabel("Coefficient (with 95% CI)")
#ax.set_title("Effect of IEEE Policy on Non-standard-related Patents")
ax.legend(title="Period")

plt.tight_layout()
plt.show()

###Event study

data = [
    (2010, "2nd Quartile", 0.056, 0.072),
    (2011, "2nd Quartile", -0.035, 0.046),
    (2013, "2nd Quartile", 0.381, 0.031),
    (2014, "2nd Quartile", 0.516, 0.039),
    (2015, "2nd Quartile", 0.399, 0.052),
    (2016, "2nd Quartile", 0.313, 0.066),
    (2017, "2nd Quartile", 0.272, 0.066),

    (2010, "3rd Quartile", -0.075, 0.095),
    (2011, "3rd Quartile", 0.012, 0.084),
    (2013, "3rd Quartile", 0.282, 0.062),
    (2014, "3rd Quartile", 0.412, 0.074),
    (2015, "3rd Quartile", 0.387, 0.097),
    (2016, "3rd Quartile", 0.374, 0.094),
    (2017, "3rd Quartile", 0.253, 0.100),

    (2010, "4th Quartile", -0.033, 0.115),
    (2011, "4th Quartile", -0.090, 0.083),
    (2013, "4th Quartile", 0.162, 0.067),
    (2014, "4th Quartile", 0.419, 0.071),
    (2015, "4th Quartile", 0.366, 0.077),
    (2016, "4th Quartile", 0.232, 0.090),
    (2017, "4th Quartile", 0.585, 0.129)
]

df = pd.DataFrame(data, columns=["year", "quartile", "coef", "se"])

# Add baseline point at 2012 (coef=0, se=0)
for q in df["quartile"].unique():
    df = pd.concat([df, pd.DataFrame([[2012, q, 0, 0]], 
                                     columns=["year", "quartile", "coef", "se"])])

# Compute confidence intervals
df["ci_low"] = df["coef"] - 1.96 * df["se"]
df["ci_high"] = df["coef"] + 1.96 * df["se"]

quartiles = df["quartile"].unique()
fig, axes = plt.subplots(1, len(quartiles), figsize=(14, 4), sharey=True)

for ax, q in zip(axes, quartiles):
    sub = df[df["quartile"] == q].sort_values("year")
    ax.errorbar(sub["year"], sub["coef"], 
                yerr=1.96*sub["se"], fmt='o', capsize=3, label=q)  # fmt='o' = points only
    
    # Add horizontal zero line and vertical baseline
    ax.axhline(0, color="black", linestyle="dashed", linewidth=1)
    ax.axvline(2015, color="red", linestyle="dotted", linewidth=1)
    ax.axvline(2013, color="red", linestyle="dotted", linewidth=1)
    ax.set_title(q)
    ax.set_xticks(range(2010, 2018))
    ax.set_xlabel("Year")
    ax.grid(alpha=0.3)

axes[0].set_ylabel("Coefficient (relative to 2012)")
#fig.suptitle("Event Study: Effect of IEEE Policy Change on Patenting", fontsize=14)
plt.tight_layout()
plt.show()

###SEP holders vs non SEP holders mechanisms



data = [
    # --- Non-std Patents ---
    ("Non-std Patents", "1stQ SEP", "Antic", -0.060, 0.054),
    ("Non-std Patents", "2ndQ Non-SEP", "Antic", 0.229, 0.056),
    ("Non-std Patents", "2ndQ SEP", "Antic", 0.867, 0.099),

    ("Non-std Patents", "1stQ SEP", "Post", 0.061, 0.084),
    ("Non-std Patents", "2ndQ Non-SEP", "Post", 0.289, 0.082),
    ("Non-std Patents", "2ndQ SEP", "Post", -0.523, 0.268),

    # --- R&D ---
    ("R&D", "1stQ SEP", "Antic", -0.025, 0.022),
    ("R&D", "2ndQ Non-SEP", "Antic", -0.042, 0.015),
    ("R&D", "2ndQ SEP", "Antic", -0.170, 0.045),

    ("R&D", "1stQ SEP", "Post", -0.189, 0.038),
    ("R&D", "2ndQ Non-SEP", "Post", -0.072, 0.024),
    ("R&D", "2ndQ SEP", "Post", -0.125, 0.037),

    # --- Total Patents ---
    ("Total Patents", "1stQ SEP", "Antic", -0.037, 0.048),
    ("Total Patents", "2ndQ Non-SEP", "Antic", 0.266, 0.051),
    ("Total Patents", "2ndQ SEP", "Antic", 0.832, 0.097),

    ("Total Patents", "1stQ SEP", "Post", 0.069, 0.073),
    ("Total Patents", "2ndQ Non-SEP", "Post", 0.287, 0.073),
    ("Total Patents", "2ndQ SEP", "Post", -0.367, 0.197),
]

df = pd.DataFrame(data, columns=["outcome", "group", "period", "coef", "se"])


outcomes = df["outcome"].unique()
fig, axes = plt.subplots(1, len(outcomes), figsize=(16, 5), sharey=True)

colors = {"Post": "tab:blue", "Antic": "tab:orange"}

for ax, outcome in zip(axes, outcomes):
    sub = df[df["outcome"] == outcome]
    
    # assign x positions
    groups = sub["group"].unique()
    x = range(len(groups))
    
    for i, g in enumerate(groups):
        for p in ["Post", "Antic"]:
            row = sub[(sub["group"] == g) & (sub["period"] == p)]
            ax.errorbar(i + (0.1 if p=="Post" else -0.1), 
                        row["coef"], 
                        yerr=1.96*row["se"], 
                        fmt="o", 
                        capsize=3, 
                        color=colors[p], 
                        label=p if i==0 else "")
    
    ax.axhline(0, color="black", linestyle="dashed", linewidth=1)
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels(groups, rotation=45, ha="right")
    ax.set_title(outcome)

axes[0].set_ylabel("Coefficient")
#fig.suptitle("Mechanism Analysis: Effect of IEEE Policy Change", fontsize=14)
handles, labels = axes[0].get_legend_handles_labels()
fig.legend(handles, labels, loc="upper left")
plt.tight_layout(rect=[0,0,1,0.9])
plt.show()


###Robusntess check coefficients:

robust1 = [
    ("Bluetooth", "2ndQ", "Baseline",0.206, 0.063),
    ("Bluetooth", "2ndQ", "Post", 0.205, 0.158),
    ("Bluetooth", "3rdQ", "Baseline", 0.232, 0.084),
    ("Bluetooth", "3rdQ", "Post", -0.187, 0.159),
    ("Bluetooth", "4thQ", "Baseline", 0.352, 0.089),
    ("Bluetooth", "4thQ", "Post", 0.090, 0.145),

    ("StdPatents (w0)", "2ndQ", "Baseline",0.206, 0.063),
    ("StdPatents (w0)", "2ndQ", "Post", 0.207, 0.061),
    ("StdPatents (w0)", "3rdQ", "Baseline", 0.232, 0.084),
    ("StdPatents (w0)", "3rdQ", "Post", 0.215, 0.079),
    ("StdPatents (w0)",  "4thQ", "Baseline", 0.352, 0.089),
    ("StdPatents (w0)", "4thQ", "Post", 0.348, 0.087),

    ("Tech Distance", "2ndQ", "Baseline",0.206, 0.063),
    ("Tech Distance", "2ndQ", "Post", 0.219, 0.063),
    ("Tech Distance", "3rdQ", "Baseline", 0.232, 0.084),
    ("Tech Distance", "3rdQ", "Post", 0.182, 0.080),
    ("Tech Distance", "4thQ", "Baseline", 0.352, 0.089),
    ("Tech Distance", "4thQ", "Post", 0.370, 0.096),
]

robust2 = [
    ("StdPatents (All)", "2ndQ","Baseline",0.206, 0.063),
    ("StdPatents (All)", "3rdQ", "Baseline", 0.232, 0.084),
    ("StdPatents (All)", "4thQ", "Baseline", 0.352, 0.089),

    ("StdPatents (All)", "2ndQ", "Post", 0.203, 0.064),
    ("StdPatents (All)", "3rdQ", "Post", 0.235, 0.084),
    ("StdPatents (All)", "4thQ", "Post", 0.358, 0.088),
]


all_data = robust1 + robust2
df = pd.DataFrame(all_data, columns=["outcome", "group", "period", "coef", "se"])

outcomes = df["outcome"].unique()
n_outcomes = len(outcomes)

fig, axes = plt.subplots(2, 2, figsize=(14, 10), sharey=True)
axes = axes.flatten()

colors = {"Baseline": "tab:blue", "Post": "tab:orange"}
labels_map = {"Baseline": "Main spec. (Baseline)", 
              "Post": "Robustness (Post)"}

for ax, outcome in zip(axes, outcomes):
    sub = df[df["outcome"] == outcome]
    groups = sub["group"].unique()
    x = range(len(groups))
    
    for i, g in enumerate(groups):
        for p in ["Baseline", "Post"]:
            row = sub[(sub["group"] == g) & (sub["period"] == p)]
            if not row.empty:
                ax.errorbar(i + (0.1 if p=="Post" else -0.1), 
                            row["coef"], 
                            yerr=1.96*row["se"], 
                            fmt="o", 
                            capsize=3, 
                            color=colors[p], 
                            label=labels_map[p] if i==0 else "")
    
    ax.axhline(0, color="black", linestyle="dashed", linewidth=1)
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels(groups, rotation=45, ha="right")
    ax.set_title(outcome)

axes[0].set_ylabel("Coefficient")
handles, labels = axes[0].get_legend_handles_labels()
fig.legend(handles, labels, loc="upper left", ncol=2)
plt.tight_layout(rect=[0,0,1,0.92])
plt.savefig(os.path.join(OUT, "robustness_checks.png"), dpi=300, bbox_inches="tight")
plt.show()

#### Histogram for distribution of firm-standard pairs across technology distances ####
final = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543.csv"),low_memory=False)


hist1 = final[['company_id','TECH_before','standard_family1']].drop_duplicates()
hist2 = hist1.groupby('TECH_before')['company_id'].nunique().reset_index()
mu = statistics.mean(hist2['company_id'])
sigma = statistics.stdev(hist2['company_id'])
num_bins = 20


fig, ax = plt.subplots()
# the histogram of the data
n, bins, patches = ax.hist(hist2['TECH_before'], num_bins, density=True)

ax.set_xlabel('Technology Proximity')
ax.set_ylabel('Num. Firms')

fig.tight_layout()
plt.show()



####Distribution of firms characteristics across groups###
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler

pre = final[final.year<2015]
charact = pre[['company_id','quart_tehc', 'E','RD','SALE','patTOT']].drop_duplicates()

charact['RD_norm'] = (charact['RD'] - charact['RD'].mean())/ charact['RD'].std()
charact['E_norm'] = (charact['E'] - charact['E'].mean())/ charact['E'].std()
charact['Sale_norm'] = (charact['SALE'] - charact['SALE'].mean())/ charact['SALE'].std()
charact['pat_norm'] = (charact['patTOT'] - charact['patTOT'].mean())/ charact['patTOT'].std()


group11 = charact[charact.quart_tehc==1]
group21 = charact[charact.quart_tehc==0.75]
group31 = charact[charact.quart_tehc==0.50]
group41 = charact[charact.quart_tehc==0.25]


group1 = group11.dropna(subset=['RD_norm'])
group2 = group21.dropna(subset=['RD_norm'])
group3 = group31.dropna(subset=['RD_norm'])
group4 = group41.dropna(subset=['RD_norm'])


plt.clf()
sns.kdeplot(group1['RD_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group1['RD_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group2['RD_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group2['RD_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group3['RD_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group3['RD_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group4['RD_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group4['RD_norm']), color='red')
plt.show()

group1 = group11.dropna(subset=['Sale_norm'])
group2 = group21.dropna(subset=['Sale_norm'])
group3 = group31.dropna(subset=['Sale_norm'])
group4 = group41.dropna(subset=['Sale_norm'])


plt.clf()
sns.kdeplot(group1['Sale_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group1['Sale_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group2['Sale_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group2['Sale_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group3['Sale_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group3['Sale_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group4['Sale_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group4['Sale_norm']), color='red')
plt.show()

group1 = group11.dropna(subset=['E_norm'])
group2 = group21.dropna(subset=['E_norm'])
group3 = group31.dropna(subset=['E_norm'])
group4 = group41.dropna(subset=['E_norm'])


plt.clf()
sns.kdeplot(group1['E_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group1['E_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group2['E_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group2['E_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group3['E_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group3['E_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group4['E_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group4['E_norm']), color='red')
plt.show()

group1 = group11.dropna(subset=['pat_norm'])
group2 = group21.dropna(subset=['pat_norm'])
group3 = group31.dropna(subset=['pat_norm'])
group4 = group41.dropna(subset=['pat_norm'])


plt.clf()
sns.kdeplot(group1['pat_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group1['pat_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group2['pat_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group2['pat_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group3['pat_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group3['pat_norm']), color='red')
plt.show()

plt.clf()
sns.kdeplot(group4['pat_norm'], color="dimgrey", shade=True)
plt.xlabel('Count')
plt.ylabel('Density')
plt.axvline(np.mean(group4['pat_norm']), color='red')
plt.show()

####Box-blot showing the variation of technology closness as a % across quartiles
tech43 = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity group4 vs group3.xlsx")).drop_duplicates()
tech42 = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity group4 vs group2.xlsx")).drop_duplicates()
tech41 = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity group4 vs group1.xlsx")).drop_duplicates()
tech32 = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity group3 vs group2.xlsx")).drop_duplicates()
tech31 = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity group3 vs group1.xlsx")).drop_duplicates()
tech21 = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity group2 vs group1.xlsx")).drop_duplicates()


data_group4 = [tech43['TECH_before'], tech42['TECH_before'], tech41['TECH_before']]
labels = ['','3rd','2nd','1st']
default_x_ticks = range(len(data_group4)+1)
plt.clf()
fig, axs = plt.subplots()
axs.boxplot(data_group4)
axs.set(xticks=default_x_ticks, xticklabels=labels)
axs.set_xlabel('Quartile')
axs.set_ylabel('Technology Proximity')
plt.show()

data_group3 = [tech43['TECH_before'], tech32['TECH_before'], tech31['TECH_before']]
labels = ['','4th','2nd','1st']
default_x_ticks = range(len(data_group3)+1)
plt.clf()
fig, axs = plt.subplots()
axs.boxplot(data_group3)
axs.set(xticks=default_x_ticks, xticklabels=labels)
axs.set_xlabel('Quartile')
axs.set_ylabel('Technology Proximity')
plt.show()

data_group2 = [tech42['TECH_before'], tech32['TECH_before'], tech21['TECH_before']]
labels = ['','4th','3rd','1st']
default_x_ticks = range(len(data_group2)+1)
plt.clf()
fig, axs = plt.subplots()
axs.boxplot(data_group2)
axs.set(xticks=default_x_ticks, xticklabels=labels)
axs.set_xlabel('Quartile')
axs.set_ylabel('Technology Proximity')
plt.show()

data_group1 = [tech41['TECH_before'], tech31['TECH_before'], tech21['TECH_before']]
labels = ['','4th','3rd','2nd']
default_x_ticks = range(len(data_group1)+1)
plt.clf()
fig, axs = plt.subplots()
axs.boxplot(data_group1)
axs.set(xticks=default_x_ticks, xticklabels=labels)
axs.set_xlabel('Quartile')
axs.set_ylabel('Technology Proximity')
plt.show()

####Distribution of standard-related patents and R&D over time across groups

final = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543_v2.csv"),low_memory=False)

charact = final[['company_id','RD','patTOT','quart_tehc','year']].drop_duplicates()
charact['RD_norm'] = (charact['RD'] - charact['RD'].mean())/ charact['RD'].std()
charact['pat_norm'] = (charact['patTOT'] - charact['patTOT'].mean())/ charact['patTOT'].std()


group1 = charact[charact.quart_tehc==1]
group2 = charact[charact.quart_tehc==0.75]
group3 = charact[charact.quart_tehc==0.50]
group4 = charact[charact.quart_tehc==0.25]

group1_mean_nc_n = group1.groupby(['year','company_id'],as_index=False).mean().groupby('year')['RD'].mean().reset_index()
group2_mean_nc_n = group2.groupby(['year','company_id'],as_index=False).mean().groupby('year')['RD'].mean().reset_index()
group3_mean_nc_n = group3.groupby(['year','company_id'],as_index=False).mean().groupby('year')['RD'].mean().reset_index()
group4_mean_nc_n = group4.groupby(['year','company_id'],as_index=False).mean().groupby('year')['RD'].mean().reset_index()

plt.clf()

plt.plot(group4_mean_nc_n['year'], group4_mean_nc_n['RD'],color='darkgrey', linestyle='-' ,label="group4")
plt.plot(group4_mean_nc_n['year'], group3_mean_nc_n['RD'], color='grey', linestyle='--',label="group3")
plt.plot(group4_mean_nc_n['year'], group2_mean_nc_n['RD'], color='dimgrey', linestyle='-.',label="group2")
plt.plot(group4_mean_nc_n['year'], group1_mean_nc_n['RD'],color='black', linestyle=':', label="group1")
#ax.set_xlabel()
plt.ylabel('Mean RD Expenditure per firm')
plt.axvline(x=2015,color='lightgrey', linestyle='--')
plt.axvline(x=2013,color='lightgrey', linestyle='--')
plt.legend()
plt.show()

group1_mean_nc_n = group1.groupby(['year','company_id'],as_index=False).mean().groupby('year')['pat_norm'].mean().reset_index()
group2_mean_nc_n = group2.groupby(['year','company_id'],as_index=False).mean().groupby('year')['pat_norm'].mean().reset_index()
group3_mean_nc_n = group3.groupby(['year','company_id'],as_index=False).mean().groupby('year')['pat_norm'].mean().reset_index()
group4_mean_nc_n = group4.groupby(['year','company_id'],as_index=False).mean().groupby('year')['pat_norm'].mean().reset_index()

plt.clf()

plt.plot(group4_mean_nc_n['year'], group4_mean_nc_n['pat_norm'],color='darkgrey', linestyle='-' ,label="group4")
plt.plot(group4_mean_nc_n['year'], group3_mean_nc_n['pat_norm'], color='grey', linestyle='--',label="group3")
plt.plot(group4_mean_nc_n['year'], group2_mean_nc_n['pat_norm'], color='dimgrey', linestyle='-.',label="group2")
plt.plot(group4_mean_nc_n['year'], group1_mean_nc_n['pat_norm'],color='black', linestyle=':', label="group1")
#ax.set_xlabel()
plt.ylabel('Mean Total Patenting per firm')
plt.axvline(x=2015,color='lightgrey', linestyle='--')
plt.axvline(x=2013,color='lightgrey', linestyle='--')
plt.legend()
plt.show()


charact = final[['company_id','standard_family1','patn','patTOT','patn_ws','year','quart_tehc']].drop_duplicates()
charact['share'] = charact['patn']/ charact['patTOT']

group1 = charact[charact.quart_tehc==1]
group2 = charact[charact.quart_tehc==0.75]
group3 = charact[charact.quart_tehc==0.50]
group4 = charact[charact.quart_tehc==0.25]

group1_mean_nc_n = group1.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['share'].mean().reset_index()
group2_mean_nc_n = group2.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['share'].mean().reset_index()
group3_mean_nc_n = group3.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['share'].mean().reset_index()
group4_mean_nc_n = group4.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['share'].mean().reset_index()


plt.clf()
plt.plot(group4_mean_nc_n['year'], group4_mean_nc_n['share'],color='darkgrey', linestyle='-' ,label="group4")
plt.plot(group4_mean_nc_n['year'], group3_mean_nc_n['share'], color='grey', linestyle='--',label="group3")
plt.plot(group4_mean_nc_n['year'], group2_mean_nc_n['share'], color='dimgrey', linestyle='-.',label="group2")
plt.plot(group4_mean_nc_n['year'], group1_mean_nc_n['share'],color='black', linestyle=':', label="group1")
#ax.set_xlabel()
plt.ylabel('Mean Patents filed per firm-standard')
plt.axvline(x=2015,color='lightgrey', linestyle='--')
plt.axvline(x=2013,color='lightgrey', linestyle='--')
plt.legend()
plt.show()

charact = final[['company_id','standard_family1','patn','patTOT','patn_ws','year','quart_tehc','TREAT_declaring']].drop_duplicates()
charact['share'] = charact['patn']/ charact['patTOT']

group1 = charact[charact.TREAT_declaring==1]
group2 = charact[charact.TREAT_declaring==0]

group1_mean_nc_n = group1.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_ws'].mean().reset_index()
group2_mean_nc_n = group2.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_ws'].mean().reset_index()
group3_mean_nc_n = charact.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','standard_family1'],as_index=False).mean().groupby('year')['patn_ws'].mean().reset_index()


plt.clf()
plt.plot(group3_mean_nc_n['year'], group3_mean_nc_n['patn_ws'], color='grey', linestyle='--',label="Total")
plt.plot(group3_mean_nc_n['year'], group2_mean_nc_n['patn_ws'], color='dimgrey', linestyle='-.',label="NON SEP Holders")
plt.plot(group3_mean_nc_n['year'], group1_mean_nc_n['patn_ws'],color='black', linestyle=':', label="SEP Holders")
ax.set_xlabel()
plt.ylabel('Mean Patents filed per firm-standard')
plt.axvline(x=2015,color='lightgrey', linestyle='--')
plt.axvline(x=2013,color='lightgrey', linestyle='--')
plt.legend()
plt.show()

#####Distribution of patents across firms and time
std = final[['standard_family1','year','Sage']].drop_duplicates()

a = std.standard_family1.unique()
std1 = pd.DataFrame()

for i in a:
    add = std[std.standard_family1==i]
    year_min = add.year.min()
    add1 = add[add.year==year_min]
    add1['Sage'] = add1['Sage'].map(int)
    age_min = add1.Sage.min()
    new_year = list(range(1902,year_min - 1))
    min_age = len(new_year)
    min_age1 = age_min - min_age
    new_age = list(range(min_age1-1, age_min - 1))
    std_std = [i]*len(new_age)
    add2 = pd.DataFrame({'standard_family1': std_std, 'year': new_year,'Sage': new_age})
    std1 = pd.concat([std1,add2], axis=0, sort=True)

std2 = pd.concat([std,std1],axis=0,sort=True).drop_duplicates()

patenting_others = pd.read_csv(os.path.join(DATA, "data da usare/10Others patents revised_all patents with weights.csv"))
patenting_firms = pd.read_csv(os.path.join(DATA, "data da usare/10IEEE patents revised_all patents with weights.csv"))

df = pd.concat([patenting_firms, patenting_others],axis=0,sort=True)
df1 = pd.merge(df,std2,on=['standard_family1','year'])


df2 = df1[['standard_family1','Sage','patn_ws']]
df3 = df2[df2.Sage>-61]
hist2 = df2.groupby(['standard_family1','Sage'])['patn_ws'].sum().reset_index()


mu = statistics.mean(hist2['patn_ws'])
sigma = statistics.stdev(hist2['patn_ws'])
num_bins = 20

plt.clf()
fig, ax = plt.subplots()
# the histogram of the data
n, bins, patches = ax.hist(hist2['Sage'], num_bins, density=True)

ax.set_xlabel('Standard Age')
ax.set_ylabel('Num. Weighted Patents')

# Tweak spacing to prevent clipping of ylabel
fig.tight_layout()
plt.show()



###STATISTICS

####Distribution of firms across industries###
final = pd.read_csv(os.path.join(DATA, "data da usare/final_lag1_TECHall543_v2.csv"),low_memory=False)

industries = final[['company_id','naics','quart_tehc']].drop_duplicates()
industries['naics'] = industries['naics'].map(str)
industries['naics1'] = industries['naics'].str[0:3]
ind = industries.groupby(['naics1','quart_tehc'])['company_id'].nunique().reset_index()

group1 = ind[ind.quart_tehc==1]
group2 = ind[ind.quart_tehc==0.75]
group3 = ind[ind.quart_tehc==0.50]
group4 = ind[ind.quart_tehc==0.25]


#####Table for standards' observed characteristics ####


std = final[['standard_family1','year', 'company_name',
       'disclosure_id', 'disclosure_id_TOTF', 'doc_idn', 'doc_idn_TOTF',
       'ipc1', 'ipc_cumsum', 'letter_id', 'letter_id_TOTF', 'publicationyear',
       'sepTOTF', 'sep_hld_TOTF', 'Sage']].drop_duplicates()


std_pre = std[std.year<2013]
a =[2013,2014]
std_ant = std[std.year.isin(a)]
std_post = std[std.year>2014]

std_pre[['sep_hld_TOTF','disclosure_id','disclosure_id_TOTF','sepTOTF','doc_idn','doc_idn_TOTF','Sage','ipc_cumsum']].mean()
std_ant[['sep_hld_TOTF','disclosure_id','disclosure_id_TOTF','sepTOTF','doc_idn','doc_idn_TOTF','Sage','ipc_cumsum']].mean()
std_post[['sep_hld_TOTF','disclosure_id','disclosure_id_TOTF','sepTOTF','doc_idn','doc_idn_TOTF','Sage','ipc_cumsum']].mean()


#####Table for firms' observed characteristics ####
#final1 = final[final.year<2015]
final1 = final
firms = final1[['E', 'RD', 'SALE', 'TREAT_declaring', 'company_id',
       'curcd', 'inv_', 'inv_prop', 'loc', 'naics', 'patNS', 'patNS_c',
       'patTOT', 'patTOT_c', 'patT_c', 'patT_c_ws', 'patT_c_ws_w0', 'patn',
       'patn_ws', 'patn_ws_w0', 'year', 'S1', 'M1', 'L1', 'G1',  'quart_tehc', 'VI',
       'U', 'D', 'TECH_before_var','TECH_before']].drop_duplicates()


group1 = firms[firms.quart_tehc == 1.00]
group2 = firms[firms.quart_tehc == 0.75]
group3 = firms[firms.quart_tehc == 0.50]
group4 = firms[firms.quart_tehc == 0.25]

group1['std_prop'] = group1['patn']/ group1['patTOT']
group2['std_prop'] = group2['patn']/ group2['patTOT']
group3['std_prop'] = group3['patn']/ group3['patTOT']
group4['std_prop'] = group4['patn']/ group4['patTOT']

group1['RD_S'] = group1['RD']/ group1['SALE']
group2['RD_S'] = group2['RD']/ group2['SALE']
group3['RD_S'] = group3['RD']/ group3['SALE']
group4['RD_S'] = group4['RD']/ group4['SALE']

group1['RD_S'] = group1['RD_S'].replace(np.inf,0)
group2['RD_S'] = group2['RD_S'].replace(np.inf,0)
group3['RD_S'] = group3['RD_S'].replace(np.inf,0)
group4['RD_S'] = group4['RD_S'].replace(np.inf,0)

group1['inv_'] = group1['inv_'].replace(np.inf,0)
group2['inv_'] = group2['inv_'].replace(np.inf,0)
group3['inv_'] = group3['inv_'].replace(np.inf,0)
group4['inv_'] = group4['inv_'].replace(np.inf,0)


group1[['RD','E','inv_','patTOT','patn','std_prop','TECH_before','RD_S']].mean()
group2[['RD','E','inv_','patTOT','patn','std_prop','TECH_before', 'RD_S']].mean()
group3[['RD','E','inv_','patTOT','patn','std_prop', 'TECH_before', 'RD_S']].mean()
group4[['RD','E','inv_','patTOT','patn','std_prop','TECH_before', 'RD_S']].mean()

#SEP and non-SEP holders
group1 = firms[firms.TREAT_declaring == 1]
group2 = firms[firms.TREAT_declaring == 0]
group1['std_prop'] = group1['patn']/ group1['patTOT']
group2['std_prop'] = group2['patn']/ group2['patTOT']
group1['inv_'] = group1['inv_'].replace(np.inf,0)
group2['inv_'] = group2['inv_'].replace(np.inf,0)

group1['RD_S'] = group1['RD']/ group1['SALE']
group2['RD_S'] = group2['RD']/ group2['SALE']
group1['RD_S'] = group1['RD_S'].replace(np.inf,0)
group2['RD_S'] = group2['RD_S'].replace(np.inf,0)

group1[['RD','E','inv_','patTOT','patn','std_prop','TECH_before','RD_S']].mean()
group2[['RD','E','inv_','patTOT','patn','std_prop','TECH_before', 'RD_S']].mean()

sep_firms = group1.company_id.nunique()
NONsep_firms = group2.company_id.nunique()

####Getting the coefficients in percentages

a = np.exp(0.104)
coef2 = (a-1)*100

a = np.exp(0.130)
coef3 = (a-1)*100

a = np.exp(0.225)
coef4 = (a-1)*100




