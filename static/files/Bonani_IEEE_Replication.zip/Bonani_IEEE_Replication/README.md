# Replication package

**Michela Bonani (2026). "Standard-Setting and the Incentives to Innovate: Evidence from the IEEE Patent Policy Update." *International Journal of Industrial Organization*, 104, 103235.** https://doi.org/10.1016/j.ijindorg.2025.103235

This package contains the code used to build the data and produce the results in the paper. The underlying data are licensed and cannot be redistributed (see *Data availability*). To let users check that the code runs, the package includes a script that generates **synthetic data** with the same structure as the analysis files.

## Contents

```
Python/      data construction, descriptive statistics, figures, theoretical model
R/           main estimations (Poisson difference-in-differences) and tables
synthetic/   make_synthetic_data.R — creates fake data with the structure of the analysis files
data/        place the original data here (empty in this package)
output/      LaTeX tables are written here
```

## Data availability

The analysis combines several licensed sources:

- **Searle Center Database on Technology Standards and Standard Setting Organizations (SCDB):** standards, standard versions and declared standard-essential patents (SEPs).
- **PATSTAT (European Patent Office):** patent applications, technology classes and citations.
- **OECD HAN database:** harmonised applicant names linking PATSTAT applicants to firms.
- **Compustat and Orbis:** firm financials (sales, R&D, employees, industry, country).

These data cannot be shared under their terms of use. Researchers with access to them can place the raw files in `data/` (keeping the file names used in the scripts) and run the full pipeline.

## Running the code on synthetic data

Requirements: R with `data.table`, `fixest`, `car`, `lmtest`, `sandwich`.

From the package root:

```
Rscript synthetic/make_synthetic_data.R
REPLICATION_DATA=data_synthetic Rscript R/Main_Analysis.R
REPLICATION_DATA=data_synthetic Rscript R/R_code_SEP_analysis.R
REPLICATION_DATA=data_synthetic Rscript R/R_code_ETSI.R
REPLICATION_DATA=data_synthetic Rscript R/Robustness_checks.R
```

The synthetic data are random draws that only mimic the structure of the analysis files (variable names, types, panel dimensions). **Estimates obtained on them are not the results in the paper.**

## Running the code on the original data

Requirements: Python 3 with `pandas`, `numpy`, `scipy`, `statsmodels`, `scikit-learn`, `matplotlib`, `seaborn`, `dask`; R as above.

1. Data construction (Python), in this order:
   1. `Patstat_Data.py`: extracts patents, technology classes and citations from PATSTAT
   2. `Firms-standards-pats sample.py`: builds the firm–standard–patent sample for IEEE standards
   3. `Jaffe technology distance.py`: technological proximity between firms and standards
   4. `Dataset_for_DiD.py`: creates the analysis file `final_lag1_TECHall543.csv` and its variants
   5. `Bluetooth sample.py` and `Patenting_ETSI.py`: samples for the Bluetooth and ETSI robustness checks
2. Estimation (R): run the four scripts in `R/` from the package root, e.g. `Rscript R/Main_Analysis.R`.
3. Figures and descriptive statistics: `Python/graphs_and_statistics_creation.py`.
4. Theoretical model (Section 3): `Python/Theoretical_Analysis.py` (no data needed).

## Output

| Script | Output (in `output/`) | Content |
|---|---|---|
| `R/Main_Analysis.R` | `regression_table.tex` | Effect of the policy on firm–standard patenting |
| | `comparison2_table.tex`, `comparison3_table.tex`, `comparison4_table.tex` | Pairwise quartile comparisons |
| | `event_study_table.tex` | Event study |
| | `continuous_treatment_table.tex` | Robustness checks II (continuous treatment) |
| | `anticipation_specs_table.tex` | Anticipation-effect specifications |
| | `non_standard_patents_table.tex` | Non-standard-related patents |
| `R/R_code_SEP_analysis.R` | `sep_analysis_table.tex`, `mechanism_analysis_table.tex` | SEP holders; mechanism analysis |
| `R/R_code_ETSI.R` | `etsi_analysis_table.tex` | ETSI standard-related patents |
| `R/Robustness_checks.R` | `robustness_checks_table.tex` | Robustness checks I (Bluetooth, zero-weighted patents, 2012 technological distance) |

## Contact

Michela Bonani, Universitat Pompeu Fabra: michela.bonani@upf.edu
