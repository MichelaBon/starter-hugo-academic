import os
# ---------------------------------------------------------------------------
# Paths: all data are read from / written to the DATA folder.
# By default this is <replication package>/data. To run on the synthetic
# data instead, set the environment variable REPLICATION_DATA=data_synthetic.
# ---------------------------------------------------------------------------
try:
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
except NameError:  # interactive session: run from the package root
    ROOT = os.getcwd()
DATA = os.path.join(ROOT, os.environ.get("REPLICATION_DATA", "data"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
from numpy.linalg import solve, cond

# --- Model parameters ---
beta = 2.0
epsilon = 0.5
theta = 0.5


# -----------------------------
#  xi-yi case 
# -----------------------------

def F_vec(z, r, beta, epsilon, theta, gamma_i):
    # gamma_j enforced so gamma_i + gamma_j = 1
    gamma_j = 1.0 - gamma_i
    xi, yi, xj, yj = z
    V = 1.0 + xi + xj + beta * (1.0 + yi + yj)
    denom_x = 1.0 + xi + xj
    denom_y = 1.0 + yi + yj
    # --- firm i ---
    term1 = r * (xi + gamma_i) / denom_x
    term2 = (1.0 - r) * (yi + gamma_i) / denom_y
    # derivative part from differentiating the share w.r.t xi
    term3 = r * V * (1.0 + xj - gamma_i) / (denom_x**2)
    dbi_dxi = term1 + term2 + term3
    # Using identity: dπ/dxi = (1-eps)*dbi_dxi + eps  - cost'
    Fx_i = (1.0 - epsilon) * dbi_dxi + epsilon - xi + \
           (theta * yi**2) / (2.0 * (1.0 + theta * (xi + gamma_i))**2)
    term4 = r * (xi + gamma_i) / denom_x        # same as term1
    term5 = (1.0 - r) * (yi + gamma_i) / denom_y # same as term2
    dbi_dyi = beta * (term4 + term5) + (1.0 - r) * V * (1.0 + yj - gamma_i) / (denom_y**2)
    # Using identity: dπ/dyi = (1-eps)*dbi_dyi + eps*beta - cost'
    Fy_i = (1.0 - epsilon) * dbi_dyi + epsilon * beta - \
           yi / (1.0 + theta * (xi + gamma_i))
    # --- firm j (symmetric) ---
    denom_xj = denom_x  # same expression 1 + xj + xi
    denom_yj = denom_y
    term1j = r * (xj + gamma_j) / denom_xj
    term2j = (1.0 - r) * (yj + gamma_j) / denom_yj
    term3j = r * V * (1.0 + xi - gamma_j) / (denom_xj**2)
    dbj_dxj = term1j + term2j + term3j
    Fx_j = (1.0 - epsilon) * dbj_dxj + epsilon - xj + \
           (theta * yj**2) / (2.0 * (1.0 + theta * (xj + gamma_j))**2)
    term4j = r * (xj + gamma_j) / denom_xj
    term5j = (1.0 - r) * (yj + gamma_j) / denom_yj
    dbj_dyj = beta * (term4j + term5j) + (1.0 - r) * V * (1.0 + yi - gamma_j) / (denom_yj**2)
    Fy_j = (1.0 - epsilon) * dbj_dyj + epsilon * beta - \
           yj / (1.0 + theta * (xj + gamma_j))
    return np.array([Fx_i, Fy_i, Fx_j, Fy_j])

def solve_nash(r, gamma_i, guess):
    sol, info, ier, msg = fsolve(lambda z: F_vec(z, r, beta, epsilon, theta, gamma_i),
                                 x0=guess, full_output=True, xtol=1e-10, maxfev=2000)
    return sol, ier

def numerical_jacobian(fun, z0, r, eps=1e-6):
    n = len(z0)
    J = np.zeros((n, n))
    f0 = fun(z0, r)
    for k in range(n):
        dz = np.zeros(n); dz[k] = eps
        J[:, k] = (fun(z0 + dz, r) - f0) / eps
    return J

def dr_vector(fun, z_star, r, eps=1e-6):
    return (fun(z_star, r + eps) - fun(z_star, r - eps)) / (2*eps)

# --- Comparative statics loop ---
gamma_vals = [0.2, 0.5, 0.8]  
r_vals = np.linspace(0.1, 0.9, 20)

results = []
guess = np.array([0.5, 0.5, 0.5, 0.5])
for gamma_i in gamma_vals:
    for r in r_vals:
        sol, ier = solve_nash(r, gamma_i, guess)
        if ier == 1:
            xi, yi, xj, yj = sol
            J = numerical_jacobian(lambda z, rr: F_vec(z, rr, beta, epsilon, theta, gamma_i), sol, r)
            Fr = dr_vector(lambda z, rr: F_vec(z, rr, beta, epsilon, theta, gamma_i), sol, r)
            if cond(J) < 1e12:
                dzdr = -solve(J, Fr)
                dTi_dr = dzdr[0] + dzdr[1]  # derivative of I_i w.r.t r
                Ii = xi + yi  # total investment
                results.append({"gamma_i": gamma_i, "r": r, "dTi_dr": dTi_dr, "Ii": Ii})
            guess = sol


df = pd.DataFrame(results)

# --- Plot ---

##Partial derivatives
plt.figure(figsize=(8, 6))
for gamma_i in gamma_vals:
    subset = df[df["gamma_i"] == gamma_i]
    plt.plot(subset["r"], subset["dTi_dr"], marker="o", label=f"γi = {gamma_i}")

plt.axhline(0, color="gray", linestyle="--")
plt.xlabel("Royalty Rate r")
plt.ylabel(r"$\partial I_i / \partial r$")
#plt.title("Sensitivity of Total Investment to Royalty Rate")
plt.legend()
plt.grid(True)
plt.show()

#Optimal Investments

plt.figure(figsize=(8, 6))
for gamma_i in gamma_vals:
    subset = df[df["gamma_i"] == gamma_i]
    plt.plot(subset["r"], subset["Ii"], marker="o", label=f"γi = {gamma_i}")

plt.xlabel("Royalty r")
plt.ylabel(r"$I_i = x_i + y_i$")
#plt.title("Equilibrium Total Innovative Effort vs Royalty Rate")
plt.legend()
plt.grid(True)
plt.show()


# -----------------------------
#  xi-only case (y=0)
# -----------------------------

def F_vec_xi_only(z, r, beta, epsilon, theta, gamma_i):
    gamma_j = 1 - gamma_i
    xi, xj = z
    V = 1 + xi + xj + beta * 1  # downstream = 0, so only legacy beta*1
    denom_x = 1 + xi + xj
    # firm i
    term1 = r * (xi + gamma_i) / denom_x
    term2 = (1 - r) * gamma_i
    term3 = r * V * (1 + xj - gamma_i) / (denom_x**2)
    Fx_i = (1 - epsilon) * (term1 + term2 + term3) + epsilon - xi
    # firm j
    term1j = r * (xj + gamma_j) / denom_x
    term2j = (1 - r) * gamma_j
    term3j = r * V * (1 + xi - gamma_j) / (denom_x**2)
    Fx_j = (1 - epsilon) * (term1j + term2j + term3j) + epsilon - xj
    return np.array([Fx_i, Fx_j])

def solve_nash(fun, z0, r, gamma_i):
    sol, info, ier, msg = fsolve(lambda z: fun(z, r, beta, epsilon, theta, gamma_i),
                                 x0=z0, full_output=True, xtol=1e-10, maxfev=2000)
    return sol, ier

def numerical_jacobian(fun, z0, r, eps=1e-6):
    n = len(z0)
    J = np.zeros((n, n))
    f0 = fun(z0, r)
    for k in range(n):
        dz = np.zeros(n); dz[k] = eps
        J[:, k] = (fun(z0 + dz, r) - f0) / eps
    return J

def dr_vector(fun, z_star, r, eps=1e-6):
    return (fun(z_star, r + eps) - fun(z_star, r - eps)) / (2*eps)

# -----------------------------
#  Comparative statics loop
# -----------------------------
gamma_vals = [0.2, 0.5, 0.8]
r_vals = np.linspace(0.1, 0.9, 20)

results = []

for gamma_i in gamma_vals:
    guess = np.array([0.5, 0.5])
    for r in r_vals:
        sol, ier = solve_nash(F_vec_xi_only, guess, r, gamma_i)
        if ier == 1:
            J = numerical_jacobian(lambda z, rr: F_vec_xi_only(z, rr, beta, epsilon, theta, gamma_i), sol, r)
            Fr = dr_vector(lambda z, rr: F_vec_xi_only(z, rr, beta, epsilon, theta, gamma_i), sol, r)
            cnum = cond(J)
            if cnum < 1e12:
                dzdr = -solve(J, Fr)
                dxi_dr = dzdr[0]
                results.append({
                    "gamma_i": gamma_i,
                    "r": r,
                    "xi": sol[0],
                    "xj": sol[1],
                    "dxi_dr": dxi_dr,
                    "cond": cnum,
                    "converged": ier
                })
            guess = sol

# Collect results into dataframe
df = pd.DataFrame(results)

# -----------------------------
#  Plots
# -----------------------------

##Partial derivatives + Optimal Investment

fig, axes = plt.subplots(1, 2, figsize=(14,6))

# Plot equilibrium xi vs r
for gamma_i in gamma_vals:
    subset = df[df["gamma_i"] == gamma_i]
    axes[0].plot(subset["r"], subset["xi"], marker="o", label=f"γi = {gamma_i}")

axes[0].set_xlabel("Royalty Rate r")
axes[0].set_ylabel(r"$x_i$")
axes[0].set_title("Equilibrium upstream investment $x_i$ vs r (xi-only case)")
axes[0].legend()
axes[0].grid(True)


# Plot dxi/dr vs r
for gamma_i in gamma_vals:
    subset = df[df["gamma_i"] == gamma_i]
    axes[1].plot(subset["r"], subset["dxi_dr"], marker="o", label=f"γi = {gamma_i}")

axes[1].axhline(0, color="gray", linestyle="--")
axes[1].set_xlabel("Royalty Rate r")
axes[1].set_ylabel(r"$\partial I_i / \partial r$")
#axes[1].set_title("Comparative statics $dx_i/dr$ vs r (xi-only case)")
axes[1].legend()
axes[1].grid(True)

plt.tight_layout()
plt.show()

##Optimal Investment

plt.figure(figsize=(8, 6))
for gamma_i in gamma_vals:
    subset = df[df["gamma_i"] == gamma_i]
    plt.plot(subset["r"], subset["xi"], marker="o", label=f"γi = {gamma_i}")

plt.axhline(0, color="gray", linestyle="--")
plt.xlabel("Royalty r")
plt.ylabel(r"$x_i$")
#plt.title("Sensitivity of Total Investment to Royalty Rate")
plt.legend()
plt.grid(True)
plt.show()


# -----------------------------
#  yi-only case (x=0)
# -----------------------------

def F_vec_yi_only(z, r, beta, epsilon, theta, gamma_i):
    gamma_j = 1 - gamma_i
    yi, yj = z
    V = 1 + beta * (yi + yj)   
    denom_y = 1 + yi + yj
    # --- Firm i's FOC ---
    term1 = beta * (r * gamma_i + (1 - r) * (yi + gamma_i) / denom_y)
    term2 = (1 - r) * V * (1 + yj - gamma_i) / (denom_y**2)
    Fy_i = (1 - epsilon) * (term1 + term2) + epsilon * beta - yi / (1 + theta * gamma_i)
    # --- Firm j's FOC (symmetrical) ---
    term1j = beta * (r * gamma_j + (1 - r) * (yj + gamma_j) / denom_y)
    term2j = (1 - r) * V * (1 + yi - gamma_j) / (denom_y**2)
    Fy_j = (1 - epsilon) * (term1j + term2j) + epsilon * beta - yj / (1 + theta * gamma_j)
    return np.array([Fy_i, Fy_j])

def solve_nash(fun, z0, r, gamma_i):
    sol, info, ier, msg = fsolve(lambda z: fun(z, r, beta, epsilon, theta, gamma_i),
                                 x0=z0, full_output=True, xtol=1e-10, maxfev=2000)
    return sol, ier

def numerical_jacobian(fun, z0, r, eps=1e-6):
    n = len(z0)
    J = np.zeros((n, n))
    f0 = fun(z0, r)
    for k in range(n):
        dz = np.zeros(n); dz[k] = eps
        J[:, k] = (fun(z0 + dz, r) - f0) / eps
    return J

def dr_vector(fun, z_star, r, eps=1e-6):
    return (fun(z_star, r + eps) - fun(z_star, r - eps)) / (2*eps)

# -----------------------------
#  Comparative statics loop
# -----------------------------
gamma_vals = [0.2, 0.5, 0.8]
r_vals = np.linspace(0.1, 0.9, 20)

results = []

for gamma_i in gamma_vals:
    guess = np.array([0.5, 0.5])
    for r in r_vals:
        sol, ier = solve_nash(F_vec_yi_only, guess, r, gamma_i)
        if ier == 1:
            J = numerical_jacobian(lambda z, rr: F_vec_yi_only(z, rr, beta, epsilon, theta, gamma_i), sol, r)
            Fr = dr_vector(lambda z, rr: F_vec_yi_only(z, rr, beta, epsilon, theta, gamma_i), sol, r)
            cnum = cond(J)
            if cnum < 1e12:
                dzdr = -solve(J, Fr)
                dyi_dr = dzdr[0]
                results.append({
                    "gamma_i": gamma_i,
                    "r": r,
                    "yi": sol[0],
                    "yj": sol[1],
                    "dyi_dr": dyi_dr,
                    "cond": cnum,
                    "converged": ier
                })
            guess = sol

# Collect results into dataframe
df = pd.DataFrame(results)

# -----------------------------
#  Plots
# -----------------------------

##Partial derivatives

plt.figure(figsize=(8, 6))
for gamma_i in gamma_vals:
    subset = df[df["gamma_i"] == gamma_i]
    plt.plot(subset["r"], subset["dyi_dr"], marker="o", label=f"γi = {gamma_i}")

plt.axhline(0, color="gray", linestyle="--")
plt.xlabel("Royalty Rate r")
plt.ylabel(r"$\partial y_i / \partial r$")
#plt.title("Sensitivity of Total Investment to Royalty Rate")
plt.legend()
plt.grid(True)
plt.ylim(-1, 0)
plt.show()


##Optimal Investments
plt.figure(figsize=(8,6))
for gamma_i in gamma_vals:
    subset = df[df["gamma_i"] == gamma_i]
    plt.plot(subset["r"], subset["yi"], marker="o", label=f"γi = {gamma_i}")

plt.xlabel("Royalty r")
plt.ylabel(r"$y_i$")
#plt.title("Equilibrium Innovative Effort vs Royalty Rate")
plt.legend()
plt.grid(True)
plt.show()

