import os
# ---------------------------------------------------------------------------
# Paths: all data are read from / written to the DATA folder.
# By default this is <replication package>/data. To run on the synthetic
# data instead, set the environment variable REPLICATION_DATA=data_synthetic.
# ---------------------------------------------------------------------------
try:
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
except NameError:  # interactive session: run from the package root
    ROOT = os.getcwd()
DATA = os.path.join(ROOT, os.environ.get("REPLICATION_DATA", "data"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)


#####PATENT PORTAFOLIO COMPOSITION
####Declaring firms patent portfolio
import numpy as np
import pandas as pd
import seaborn as sb
import statsmodels.formula.api as smf
import dask.dataframe as dd
from dask.diagnostics import ProgressBar 
pbar = ProgressBar()
pbar.register()

per = pd.read_csv(os.path.join(DATA, "data da usare/HanPer_id fin 1.1.1.csv"))
#per = pd.read_csv(os.path.join(DATA, "data da usare/HanPer_id fin control.csv"))
a = per['person_id'].unique().tolist()

####TABLE 207

filed = ['person_id','appln_id']

dt1 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls207_part01.txt"), sep=',',header=0, usecols= filed, names=filed)
dt2 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls207_part02.txt"), sep=',',header=0, usecols= filed, names=filed)
dt3 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls207_part03.txt"), sep=',',header=0, usecols= filed, names=filed)
p = dd.concat([dt1,dt2,dt3],axis=0)
p1 = p.compute()
PerApp = p1[p1.person_id.isin(a)]
PerApp.to_csv(os.path.join(DATA, "data.csv"))

##TABLE 201
PerApp=pd.read_csv(os.path.join(DATA, "data.csv"))
ff = PerApp['appln_id'].unique() 
filed1 = ['appln_id','appln_nr','appln_filing_year','appln_nr_original','earliest_publn_year']

df9 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part01.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df10 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part02.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df11 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part03.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df12 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part04.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df13 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part05.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df14 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part06.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df15 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part07.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df16 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part08.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df17 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part09.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
df18 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls201_part10.txt"),sep=',',usecols= filed1,low_memory=False, dtype={'appln_nr': 'object','earliest_publn_year': 'object','appln_filing_year': 'object','appln_nr_original': 'object'})
p = dd.concat([df9,df10,df11,df12,df13,df14,df15,df16,df17,df18],axis=0)
p1 = p.compute()
App = p1[p1.appln_id.isin(ff)]
 
data = pd.merge(PerApp,App,on=['appln_id'],how='inner')
data.to_csv(os.path.join(DATA, "data1.csv"))


##TABLE 209
data=pd.read_csv(os.path.join(DATA, "data1.csv"),low_memory=False)

e = data['appln_id'].unique() 
filed2=['appln_id', 'ipc_class_symbol']

df19 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part01.txt"),  sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
df20 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part02.txt"),  sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
df21 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part03.txt"),  sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
df22 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part04.txt"),  sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
df23 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part05.txt"),  sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
df24 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part06.txt"),  sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
df25 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part07.txt"), sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
df26 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls209_part08.txt"), sep=',',header=0, usecols= filed2, names=filed2, low_memory=False)
p = dd.concat([df19,df20,df21,df22,df23,df24,df25,df26],axis=0)
p1 = p.compute()
Ipc = p1[p1.appln_id.isin(e)] 

data2 = pd.merge(data,Ipc,on=['appln_id'],how='left')

data2.to_csv(os.path.join(DATA, "data da usare/Patstat 1.csv"))
#data2.to_csv(os.path.join(DATA, "data da usare/Patstat 1 CONTROL.csv"))



######CITATION#####

pat = pd.read_csv(os.path.join(DATA, "data da usare/Patstat 1.csv"),low_memory=False)
#pat = pd.read_csv(os.path.join(DATA, "data da usare/Patstat 1 CONTROL.csv"),low_memory=False)

##TABLE 211
a = pat['appln_id'].unique()
filed1 = ['pat_publn_id','appln_id','publn_date']

df1 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls211_part01.txt"),low_memory=False,sep=',',usecols= filed1)
df2 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls211_part02.txt"),low_memory=False,sep=',',usecols= filed1)
df3 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls211_part03.txt"),low_memory=False,sep=',',usecols= filed1)
df4 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls211_part04.txt"),low_memory=False,sep=',',usecols= filed1)
df5 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls211_part05.txt"),low_memory=False,sep=',',usecols= filed1)
app = dd.concat([df1,df2,df3,df4,df5],axis=0)
p1 = app.compute()
app2 = p1[p1.appln_id.isin(a)]

##TABLE 212
b = app2['pat_publn_id'].unique()
filed = ['pat_publn_id','cited_pat_publn_id']
df1 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls212_part01.txt"), sep=',',usecols= filed)
df2 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls212_part02.txt"), sep=',', usecols= filed)
df3 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls212_part03.txt"), sep=',',usecols= filed)
df4 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls212_part04.txt"), sep=',',usecols= filed)
df5 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls212_part05.txt"), sep=',',usecols= filed)
df6 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls212_part06.txt"), sep=',',usecols= filed)
df7 = dd.read_csv(os.path.join(DATA, "PATSTAT/tls212_part07.txt"), sep=',',usecols= filed)
p = dd.concat([df1,df2,df3,df4,df5,df6,df7],axis=0)
p1 = p.compute()
p2 = p1[p1.pat_publn_id.isin(b)]
p3 = p2.groupby('pat_publn_id')['cited_pat_publn_id'].count().reset_index()


data = pd.merge(p3, app2,on=['pat_publn_id'])
data1 = data[['appln_id','cited_pat_publn_id']]
data2 = data1.groupby('appln_id')['cited_pat_publn_id'].sum().reset_index()

data3 = pd.merge(data2,pat,on=['appln_id'],how='right')
data3.to_csv(os.path.join(DATA, "data da usare/Patstat cited new.csv"))
#data3.to_csv(os.path.join(DATA, "data da usare/Patstat control cited.csv"))


