import os
# ---------------------------------------------------------------------------
# Paths: all data are read from / written to the DATA folder.
# By default this is <replication package>/data. To run on the synthetic
# data instead, set the environment variable REPLICATION_DATA=data_synthetic.
# ---------------------------------------------------------------------------
try:
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
except NameError:  # interactive session: run from the package root
    ROOT = os.getcwd()
DATA = os.path.join(ROOT, os.environ.get("REPLICATION_DATA", "data"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)


# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import seaborn as sb
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt
import scipy.stats as stats
from scipy import spatial
from numpy import dot
from numpy.linalg import norm
from sklearn.metrics.pairwise import cosine_similarity
from scipy.spatial import distance

def corr(x, y):
    n = len(x)
    top_term = n*np.sum(x*y) - np.sum(x)*np.sum(y)
    term1 = n*np.sum(x**2)-np.sum(x)**2
    term2 = n*np.sum(y**2)-np.sum(y)**2
    bottom_term = np.sqrt(term1*term2)
    return round(top_term/bottom_term,5)


def num_missing(x):
  return sum(x.isnull())

def tidy_split(df, column, sep='|', keep=False):
    indexes = []
    new_values = []
    df = df.dropna(subset=[column])
    for i, presplit in enumerate(df[column].astype(str)):
        values = presplit.split(sep)
        if keep and len(values) > 1:
            indexes.append(i)
            new_values.append(presplit)
        for value in values:
            indexes.append(i)
            new_values.append(value)
    new_df = df.iloc[indexes, :].copy()
    new_df[column] = new_values
    return new_df


### Measuring the technology distances --- IEEE sample

control_before = pd.read_csv(os.path.join(DATA, "data da usare/others patent portfolio_IEEE_before2015.csv"))
treat_before = pd.read_csv(os.path.join(DATA, "data da usare/firms patent portfolio_IEEE_before2015.csv"))
#control_all = pd.read_csv(os.path.join(DATA, "data da usare//others patent portfolio_IEEE.csv"))
#treat_all = pd.read_csv(os.path.join(DATA, "data da usare/firms patent portfolio_IEEE.csv"))
#standard = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_IEEE.csv"))
standard_before = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_IEEE10_before2015NEW.csv"))

firms = pd.read_csv(os.path.join(DATA, "data da usare/10IEEE patents revised_all patents with weights.csv"))
others = pd.read_csv(os.path.join(DATA, "data da usare/10Others patents revised_all patents with weights.csv"))
final = pd.read_csv(os.path.join(DATA, "data da usare/Total firms clean FINAL.csv"))

firms1 = firms[['company_id','standard_family1']].drop_duplicates()
others1 = others[['company_id','standard_family1']].drop_duplicates()
pr =  pd.concat([firms1,others1],axis=0,sort=True)
a = final.company_id.unique()
prova = pr[pr.company_id.isin(a)]

sample = pd.concat([treat_before,control_before],axis=0,sort=True)
standard_before1 = standard_before[['standard_family1','ipc1']].drop_duplicates()
standard_before2 = standard_before1[standard_before1.ipc1 != '0']
a = prova.standard_family1.unique()
std = standard_before2[standard_before2['standard_family1'].isin(a)]
std2 = std
#std2 = std.drop(['Unnamed: 0'],axis=1).drop_duplicates()
#std2 = std1.dropna(subset=['ipc1'])
a = std2.standard_family1.unique()
prova1 = prova[prova.standard_family1.isin(a)]
pair = prova1[['company_id','standard_family1']].drop_duplicates()
a = sample.company_id.unique()
pair1 = pair[pair.company_id.isin(a)]
b = pair.company_id.unique()
sample1 = sample[sample.company_id.isin(b)]
techn = pd.DataFrame()

for x,y in zip(pair1['company_id'],pair1['standard_family1']):
    pr = sample1[sample1['company_id']==x]
    tt=std2[std2['standard_family1']==y]
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']==y,1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':y,'TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2015NEW10.xlsx"))

###Measuring the technology similarity between a firms and all standards issued by IEEE in the sample without distinguishing between standards
std2 = std[['ipc1']].drop_duplicates()
std2['standard_family1'] = 'all'
item = sample1.company_id.unique()
techn = pd.DataFrame()

for x in item:
    pr = sample1[sample1['company_id']==x]
    tt = std2
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']=='all',1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':'all','TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEW10.xlsx"))

###Measuring the technology similarity between  firms
a = final.company_id.unique()
sample = pd.concat([treat_before,control_before],axis=0,sort=True)
smpl = sample[sample.company_id.isin(a)]
add = final[['company_id','quart_tehc']].drop_duplicates()
sample2 = pd.merge(smpl, add, on=['company_id'])
sample2.drop('Unnamed: 0',axis=1,inplace=True)

std2 = sample2[sample2.quart_tehc == 0.75]
std2.drop('quart_tehc',axis=1,inplace=True)
sample1 = sample2[sample2.quart_tehc == 1]
sample1.drop('quart_tehc',axis=1,inplace=True)
item = sample1.company_id.unique()
techn = pd.DataFrame()

for x,y in zip(sample1['company_id'],std2['company_id']):
    pr = sample1[sample1['company_id']==x]
    tt=std2[std2['company_id']==y]
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id_x']==x,1,0)
    prova1['std'] = np.where(prova1['company_id_y']==y,1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[2]])
    dataSetII = np.array([transpose.iloc[3]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':y,'TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity group2 vs group1.xlsx"))

####### Measuring the technology distances --- ETSI sample

firms = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10IEEE patents revised_all patents with weights2.csv"))
others = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/10Others patents revised_all patents with weights2.csv"))
standard_before = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/standard patent portfolio_ETSI_before2015NEW.csv"))

control_before = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/others patent portfolio_IEEE_before20152.csv"))
treat_before = pd.read_csv(os.path.join(DATA, "data da usare/ETSI/firms patent portfolio_IEEE_before20152.csv"))

firms1 = firms[['company_id','standard_family1']].drop_duplicates()
others1 = others[['company_id','standard_family1']].drop_duplicates()
prova =  pd.concat([firms1,others1],axis=0,sort=True)

sample = pd.concat([treat_before,control_before],axis=0,sort=True)
standard_before1 = standard_before[['standard_family1','ipc1']].drop_duplicates()
standard_before2 = standard_before1[standard_before1.ipc1 != '0']
a = prova.standard_family1.unique()
std = standard_before2[standard_before2['standard_family1'].isin(a)]
std2 = std
#std2 = std.drop(['Unnamed: 0'],axis=1).drop_duplicates()
#std2 = std1.dropna(subset=['ipc1'])
a = std2.standard_family1.unique()
prova1 = prova[prova.standard_family1.isin(a)]
pair = prova1[['company_id','standard_family1']].drop_duplicates()
a = sample.company_id.unique()
pair1 = pair[pair.company_id.isin(a)]
b = pair.company_id.unique()
sample1 = sample[sample.company_id.isin(b)]
techn = pd.DataFrame()

for x,y in zip(pair1['company_id'],pair1['standard_family1']):
    pr = sample1[sample1['company_id']==x]
    tt=std2[std2['standard_family1']==y]
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']==y,1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':y,'TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2015NEW10.xlsx"))

###Measuring the technology similarity between a firms and all standards issued by IEEE in the sample without distinguishing between standards
std2 = std[['ipc1']].drop_duplicates()
std2['standard_family1'] = 'all'
item = sample1.company_id.unique()
techn = pd.DataFrame()

for x in item:
    pr = sample1[sample1['company_id']==x]
    tt = std2
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']=='all',1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':'all','TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEW10.xlsx"))


####### Measuring the technology distances --- Bluetooth sample

control_before = pd.read_csv(os.path.join(DATA, "data da usare/others patent portfolio_Bluetooth_before2015.csv"))
treat_before = pd.read_csv(os.path.join(DATA, "data da usare/firms patent portfolio_Bluetooth_before2015.csv"))
standard_before = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_Bluetooth_before2015NEW.csv"))

firms = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth patents revised_all patents with weights.csv"))
others = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth Others patents revised_all patents with weights.csv"))
final = pd.read_csv(os.path.join(DATA, "data da usare/Total firms clean FINAL.csv"))

firms1 = firms[['company_id','standard_family1']].drop_duplicates()
others1 = others[['company_id','standard_family1']].drop_duplicates()
pr =  pd.concat([firms1,others1],axis=0,sort=True)
a = final.company_id.unique()
prova = pr[pr.company_id.isin(a)]

sample = pd.concat([treat_before,control_before],axis=0,sort=True)
standard_before1 = standard_before[['standard_family1','ipc1']].drop_duplicates()
standard_before2 = standard_before1[standard_before1.ipc1 != '0']
a = prova.standard_family1.unique()
std = standard_before2[standard_before2['standard_family1'].isin(a)]
a = std.standard_family1.unique()
prova1 = prova[prova.standard_family1.isin(a)]
pair = prova1[['company_id','standard_family1']].drop_duplicates()
a = sample.company_id.unique()
pair1 = pair[pair.company_id.isin(a)]
b = pair.company_id.unique()
sample1 = sample[sample.company_id.isin(b)]

std2 = std[['ipc1']].drop_duplicates()
std2['standard_family1'] = 'all'
item = sample1.company_id.unique()
techn = pd.DataFrame()

for x in item:
    pr = sample1[sample1['company_id']==x]
    tt = std2
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']=='all',1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':'all','TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEWBluetooth.xlsx"))


####### Measuring the technology distances --- IEEE sample 2012 tech distance 


control_before = pd.read_csv(os.path.join(DATA, "data da usare/others patent portfolio_IEEE_before2012.csv"))
treat_before = pd.read_csv(os.path.join(DATA, "data da usare/firms patent portfolio_IEEE_before2012.csv"))
#control_all = pd.read_csv(os.path.join(DATA, "data da usare//others patent portfolio_IEEE.csv"))
#treat_all = pd.read_csv(os.path.join(DATA, "data da usare/firms patent portfolio_IEEE.csv"))
#standard = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_IEEE.csv"))
standard_before = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_IEEE10_before2012NEW.csv"))

firms = pd.read_csv(os.path.join(DATA, "data da usare/10IEEE patents revised_all patents with weights 2012.csv"))
others = pd.read_csv(os.path.join(DATA, "data da usare/10Others patents revised_all patents with weights 2012.csv"))
final = pd.read_csv(os.path.join(DATA, "data da usare/Total firms clean FINAL.csv"))

firms1 = firms[['company_id','standard_family1']].drop_duplicates()
others1 = others[['company_id','standard_family1']].drop_duplicates()
pr =  pd.concat([firms1,others1],axis=0,sort=True)
a = final.company_id.unique()
prova = pr[pr.company_id.isin(a)]

sample = pd.concat([treat_before,control_before],axis=0,sort=True)
standard_before1 = standard_before[['standard_family1','ipc1']].drop_duplicates()
standard_before2 = standard_before1[standard_before1.ipc1 != '0']
a = prova.standard_family1.unique()
std = standard_before2[standard_before2['standard_family1'].isin(a)]
std2 = std
#std2 = std.drop(['Unnamed: 0'],axis=1).drop_duplicates()
#std2 = std1.dropna(subset=['ipc1'])
a = std2.standard_family1.unique()
prova1 = prova[prova.standard_family1.isin(a)]
pair = prova1[['company_id','standard_family1']].drop_duplicates()
a = sample.company_id.unique()
pair1 = pair[pair.company_id.isin(a)]
b = pair.company_id.unique()
sample1 = sample[sample.company_id.isin(b)]
techn = pd.DataFrame()

for x,y in zip(pair1['company_id'],pair1['standard_family1']):
    pr = sample1[sample1['company_id']==x]
    tt=std2[std2['standard_family1']==y]
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']==y,1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':y,'TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2013NEW10.xlsx"))

###Measuring the technology similarity between a firms and all standards issued by IEEE in the sample without distinguishing between standards
std2 = std[['ipc1']].drop_duplicates()
std2['standard_family1'] = 'all'
item = sample1.company_id.unique()
techn = pd.DataFrame()

for x in item:
    pr = sample1[sample1['company_id']==x]
    tt = std2
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']=='all',1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':'all','TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2013_allNEW10.xlsx"))

