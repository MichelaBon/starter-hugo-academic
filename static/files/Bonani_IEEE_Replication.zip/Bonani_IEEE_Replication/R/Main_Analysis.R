# ---------------------------------------------------------------------------
# Paths: run this script from the replication package root, e.g.
#   Rscript R/Main_Analysis.R
# Data are read from the DATA folder (default "data"). To run on the synthetic
# data instead:  REPLICATION_DATA=data_synthetic Rscript R/Main_Analysis.R
# Tables (.tex) are written to the "output" folder.
# ---------------------------------------------------------------------------
DATA <- Sys.getenv("REPLICATION_DATA", "data")
OUT  <- "output"
dir.create(OUT, showWarnings = FALSE)

# Load libraries
library(data.table)
library(fixest)  
library(car)       
library(lmtest)   
library(sandwich) 


####MAIN ANALYSIS ACROSS QUARTILES
# Load data
df <- fread(file.path(DATA, "data da usare/final_lag1_TECHall543.csv"))

# Create grouping variables
df[, group_country := .GRP, by = loc]
df[, group_industryFE := .GRP, by = naics]
df[, firms_fe := .GRP, by = company_id]
df[, std_fe := .GRP, by = standard_family1]
df[, firms_std_fe := .GRP, by = .(company_id, standard_family1)]
df[, group_Sage := .GRP, by = Sage]

# Create transformed variables
df[, logsephld := log(sep_hld_TOTF + 1)]
df[, logdocid := log(doc_idn + 1)]
df[, loge := log(E + 1)]
df[, logsale := logSALE]


# Create quartiles based on tech_before
df[, quant := cut(TECH_before, 
                 breaks = quantile(TECH_before, probs = 0:4/4, na.rm = TRUE),
                 labels = FALSE, include.lowest = TRUE)]

df[, quart_tech_u := fcase(
  quant == 1, 0.25,
  quant == 2, 0.50,
  quant == 3, 0.75,
  quant == 4, 1.00
)]

df[, treat1 := (1 - quart_tech_u) + 0.25]
df[, treatt := 1 - TECH_before]
df[, treattt := 1 - TECH_before_var]

# Time variables
df[, post := fifelse(year > 2014, 1L, 0L)]
df[, post_antic := fifelse(year == 2014, 1L, 0L)]
# Alternative definitions:
df[, post_antic_1 := fifelse(year > 2012 & year < 2015, 1L, 0L)]
df[, post_antic_2013 := fifelse(year == 2013, 1L, 0L)]



# Create treatment groups
df[, group_treatment := fcase(
  treat1 == 0.25, 1L,
  treat1 == 0.50, 2L,
  treat1 == 0.75, 3L,
  treat1 == 1.00, 4L
)]

# Create group dummies (not needed in R's formula syntax)
df[, group1 := fifelse(group_treatment == 1, 1L, 0L)]
df[, group2 := fifelse(group_treatment == 2, 1L, 0L)]
df[, group3 := fifelse(group_treatment == 3, 1L, 0L)]
df[, group4 := fifelse(group_treatment == 4, 1L, 0L)]
df[, group1 := 0L]  # Set as reference


# Create year dummies for 2010–2017 with 2012 as the omitted (baseline) year
yrs <- 2010:2017
for (yr in setdiff(yrs, 2012)) {
  df[, paste0("f", yr) := fifelse(year == yr, 1L, 0L)]
}

# Filter for Q1 vs Q2 comparison
df_q12 <- df[treat1 %in% c(0.25, 0.50)]
df_q12[, group_treatment2Q := fifelse(treat1 == 0.50, 1L, 0L)]

# Filter for Q1 vs Q3 comparison
df_q13 <- df[treat1 %in% c(0.25, 0.75)]
df_q13[, group_treatment2Q := fifelse(treat1 == 0.75, 1L, 0L)]

# Filter for Q1 vs Q4 comparison
df_q14 <- df[treat1 %in% c(0.25, 1)]
df_q14[, group_treatment2Q := fifelse(treat1 == 1, 1L, 0L)]


###Getting the name of firms in Q1 and Q4

# Create a unique dataset with one row per company and their TECH_before value
unique_firms <- unique(df, by = "company_id")[, .(company_id, TECH_before, quant)]

# Get top 10 firms in Q1 (lowest tech distance)
top10_q1 <- unique_firms[quant == 1, .(company_id, TECH_before)][
  order(TECH_before), ][1:10]

# Get top 10 firms in Q4 (highest tech distance)
top10_q4 <- unique_firms[quant == 4, .(company_id, TECH_before)][
  order(-TECH_before), ][1:10]


# Print the results
cat("Top 10 firms in Q1 (lowest tech distance):\n")
print(top10_q1)

cat("\nTop 10 firms in Q4 (highest tech distance):\n")
print(top10_q4)


####DID MAIN ANALYSIS

# Function for Specification 1: Sage FE (Post Only)
run_sage_fe_post <- function(data) {
  fepois(
    patn_ws ~ group_treatment2Q:post + 
      post + group_treatment2Q + treattt + logsale + 
      logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Function for Specification 1: Sage FE (Anticipation Effect)
run_sage_fe_antic <- function(data) {
  fepois(
    patn_ws ~ group_treatment2Q:post_antic + group_treatment2Q:post + 
      post_antic + post + group_treatment2Q + treattt + logsale + 
      logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Function for Specification 2: Year FE (Post Only)
run_year_fe_post <- function(data) {
  fepois(
    patn_ws ~ group_treatment2Q:post + 
      post + group_treatment2Q + treattt + logsale + 
      logsephld + logdocid + i(year) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Function for Specification 2: Year FE (Anticipation Effect)
run_year_fe_antic <- function(data) {
  fepois(
    patn_ws ~ group_treatment2Q:post_antic + group_treatment2Q:post + 
      post_antic + post + group_treatment2Q + treattt + logsale + 
      logsephld + logdocid + i(year) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Function for Specification 3: Sage Trends (Post Only)
run_sage_trends_post <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post + 
      post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treattt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}


# Function for Specification 3: Sage Trends (Regular Anticipation Effect)
run_sage_trends_antic <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post_antic + group_treatment2Q:post + 
      post_antic + post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treattt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Now run all models for each dataset
run_all_models_for_dataset <- function(data, dataset_name = "") {
  results <- list()
  
  cat("Running models for", dataset_name, "\n")
  
  # Specification 1: Sage FE
  results[[paste0(dataset_name, "_sage_post")]] <- run_sage_fe_post(data)
  results[[paste0(dataset_name, "_sage_antic")]] <- run_sage_fe_antic(data)
  
  # Specification 2: Year FE
  results[[paste0(dataset_name, "_year_post")]] <- run_year_fe_post(data)
  results[[paste0(dataset_name, "_year_antic")]] <- run_year_fe_antic(data)
  
  # Specification 3: Sage Trends
  results[[paste0(dataset_name, "_trends_post")]] <- run_sage_trends_post(data)
  results[[paste0(dataset_name, "_trends_antic")]] <- run_sage_trends_antic(data)

  
  return(results)
}

# Runing all models for all three datasets
all_models <- list(
  q12 = run_all_models_for_dataset(df_q12, "q12"),
  q13 = run_all_models_for_dataset(df_q13, "q13"),
  q14 = run_all_models_for_dataset(df_q14, "q14")
)

summary(all_models$q12$q12_sage_post)
summary(all_models$q13$q13_sage_post)
summary(all_models$q14$q14_sage_post)

summary(all_models$q12$q12_trends_antic)

# Function to extract specific coefficients
extract_did_coefficients <- function(models_list, coef_name) {
  results <- data.frame()
  
  for (model_name in names(models_list)) {
    model <- models_list[[model_name]]
    
    if (coef_name %in% names(coef(model))) {
      coef_value <- coef(model)[coef_name]
      se <- sqrt(vcov(model, cluster = ~firms_std_fe)[coef_name, coef_name])
      p_value <- summary(model)$coeftable[coef_name, "Pr(>|z|)"]
      
      results <- rbind(results, data.frame(
        model = model_name,
        coefficient = coef_name,
        estimate = coef_value,
        std_error = se,
        p_value = p_value
      ))
    }
  }
  
  return(results)
}

# Extract post coefficients
post_coefs <- extract_did_coefficients(unlist(all_models, recursive = FALSE), "post:group_treatment2Q")
antic_coefs <- extract_did_coefficients(unlist(all_models, recursive = FALSE), "post_antic:group_treatment2Q")

# Print results
print("Post-period coefficients:")
print(post_coefs)

print("Anticipation-period coefficients:")
print(antic_coefs)


# Creation of the latex table

# Function to extract coefficients by quartile and specification
extract_by_quartile_spec <- function(coef_df, quartile_pattern, spec_pattern) {
  subset(coef_df, 
         grepl(quartile_pattern, model) & 
         grepl(spec_pattern, model))
}

# Organize anticipation coefficients
antic_q12 <- extract_by_quartile_spec(antic_coefs, "q12", "sage_antic|year_antic|trends_antic")
antic_q13 <- extract_by_quartile_spec(antic_coefs, "q13", "sage_antic|year_antic|trends_antic") 
antic_q14 <- extract_by_quartile_spec(antic_coefs, "q14", "sage_antic|year_antic|trends_antic")

# Organize post coefficients
post_q12 <- extract_by_quartile_spec(post_coefs, "q12", "sage_post|year_post|trends_post")
post_q13 <- extract_by_quartile_spec(post_coefs, "q13", "sage_post|year_post|trends_post")
post_q14 <- extract_by_quartile_spec(post_coefs, "q14", "sage_post|year_post|trends_post")

# Function to create the LaTeX table content
create_latex_table_content <- function(antic_q12, antic_q13, antic_q14, post_coefs) {
  
  # Function to format coefficients with stars and parentheses
  format_coef <- function(estimate, se, digits = 3) {
    # Determine significance stars based on p-value (you might want to use actual p-values)
    stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                   ifelse(abs(estimate) > 1.96 * se, "^{**}",
                         ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
    
    # Format estimate and standard error
    est_formatted <- sprintf(paste0("$%.", digits, "f"), estimate)
    se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
    
    # Return formatted string
    paste0(est_formatted, stars, " & ", se_formatted)
  }
  
  # Extract post coefficients for each quartile and specification
  post_q12_sage_post <- subset(post_coefs, grepl("q12.*sage_post", model))
  post_q12_sage_antic <- subset(post_coefs, grepl("q12.*sage_antic", model))
  post_q12_year_post <- subset(post_coefs, grepl("q12.*year_post", model))
  post_q12_year_antic <- subset(post_coefs, grepl("q12.*year_antic", model))
  post_q12_trends_post <- subset(post_coefs, grepl("q12.*trends_post", model))
  post_q12_trends_antic <- subset(post_coefs, grepl("q12.*trends_antic", model))
  
  post_q13_sage_post <- subset(post_coefs, grepl("q13.*sage_post", model))
  post_q13_sage_antic <- subset(post_coefs, grepl("q13.*sage_antic", model))
  post_q13_year_post <- subset(post_coefs, grepl("q13.*year_post", model))
  post_q13_year_antic <- subset(post_coefs, grepl("q13.*year_antic", model))
  post_q13_trends_post <- subset(post_coefs, grepl("q13.*trends_post", model))
  post_q13_trends_antic <- subset(post_coefs, grepl("q13.*trends_antic", model))
  
  post_q14_sage_post <- subset(post_coefs, grepl("q14.*sage_post", model))
  post_q14_sage_antic <- subset(post_coefs, grepl("q14.*sage_antic", model))
  post_q14_year_post <- subset(post_coefs, grepl("q14.*year_post", model))
  post_q14_year_antic <- subset(post_coefs, grepl("q14.*year_antic", model))
  post_q14_trends_post <- subset(post_coefs, grepl("q14.*trends_post", model))
  post_q14_trends_antic <- subset(post_coefs, grepl("q14.*trends_antic", model))
  
  # Create anticipation period content (columns 2, 4, 6)
  antic_content <- paste0(
    " Anticipation-Period &&&&&&\\\\\n",
    " & 2nd Quartile && ", format_coef(antic_q12$estimate[1], antic_q12$std_error[1]), 
    " & & ", format_coef(antic_q12$estimate[2], antic_q12$std_error[2]), 
    " & & ", format_coef(antic_q12$estimate[3], antic_q12$std_error[3]), " \\\\\n",
    " & 3rd Quartile && ", format_coef(antic_q13$estimate[1], antic_q13$std_error[1]), 
    " && ", format_coef(antic_q13$estimate[2], antic_q13$std_error[2]), 
    " && ", format_coef(antic_q13$estimate[3], antic_q13$std_error[3]), "\\\\\n",
    " & 4th Quartile && ", format_coef(antic_q14$estimate[1], antic_q14$std_error[1]), 
    " & & ", format_coef(antic_q14$estimate[2], antic_q14$std_error[2]), 
    " & & ", format_coef(antic_q14$estimate[3], antic_q14$std_error[3]), "\\\\\n",
    "&&&&&&\\\\\n"
  )
  
  # Create post period content with ALL coefficients
  post_content <- paste0(
    " Post-Period  &&&&&&\\\\\n",
    " & 2nd Quartile &", format_coef(post_q12_sage_post$estimate[1], post_q12_sage_post$std_error[1]), 
    "& ", format_coef(post_q12_sage_antic$estimate[1], post_q12_sage_antic$std_error[1]), 
    "&", format_coef(post_q12_year_post$estimate[1], post_q12_year_post$std_error[1]), 
    " & ", format_coef(post_q12_year_antic$estimate[1], post_q12_year_antic$std_error[1]), 
    " &", format_coef(post_q12_trends_post$estimate[1], post_q12_trends_post$std_error[1]), 
    "& ", format_coef(post_q12_trends_antic$estimate[1], post_q12_trends_antic$std_error[1]), "\\\\\n",
    " & 3rd Quartile &", format_coef(post_q13_sage_post$estimate[1], post_q13_sage_post$std_error[1]), 
    "& ", format_coef(post_q13_sage_antic$estimate[1], post_q13_sage_antic$std_error[1]), 
    " &", format_coef(post_q13_year_post$estimate[1], post_q13_year_post$std_error[1]), 
    "& ", format_coef(post_q13_year_antic$estimate[1], post_q13_year_antic$std_error[1]), 
    " &", format_coef(post_q13_trends_post$estimate[1], post_q13_trends_post$std_error[1]), 
    "& ", format_coef(post_q13_trends_antic$estimate[1], post_q13_trends_antic$std_error[1]), "\\\\\n",
    " & 4th Quartile &", format_coef(post_q14_sage_post$estimate[1], post_q14_sage_post$std_error[1]), 
    "& ", format_coef(post_q14_sage_antic$estimate[1], post_q14_sage_antic$std_error[1]), 
    " &", format_coef(post_q14_year_post$estimate[1], post_q14_year_post$std_error[1]), 
    "& ", format_coef(post_q14_year_antic$estimate[1], post_q14_year_antic$std_error[1]), 
    " &", format_coef(post_q14_trends_post$estimate[1], post_q14_trends_post$std_error[1]), 
    "& ", format_coef(post_q14_trends_antic$estimate[1], post_q14_trends_antic$std_error[1]), "\\\\\n"
  )
  
  return(paste0(antic_content, post_content))
}

# Create the table content
table_content <- create_latex_table_content(antic_q12, antic_q13, antic_q14, post_coefs)

# Create the complete LaTeX table
latex_table <- paste0(
"\\begin{table}[t]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Effect of IEEE policy change on firm-standard patenting}
\\label{tab:diff} 
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{7}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{Standard-related Patents}&\\multicolumn{2}{c}{Standard-related Patents}&\\multicolumn{2}{c}{Standard-related Patents}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3} \\cmidrule{4-5} \\cmidrule{6-7}& & (1) & (2)  & (3) & (4)  & (5) & (6) \\\\\t 
\\midrule\n",
table_content,
"\\hline

&&&&&&\\\\
Covariates & & Yes& Yes & Yes & Yes & Yes & Yes \\\\
Standard Age FE & & Yes& Yes & No & No & Yes & Yes  \\\\
Year FE & & No& No & Yes & Yes & No & No  \\\\
Quartile\\\\_Time\\\\_trend & & No & No & No & No & Yes & Yes  \\\\
Standard FE & & Yes& Yes & Yes & Yes & Yes & Yes \\\\
Firm FE & & Yes& Yes & Yes & Yes & Yes & Yes \\\\

\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: The coefficients reported for each quartile are estimated separately comparing the outcomes of the quartile of interest with the baseline group, represented by firms in the first quartile. The dependent variable is the weighted number of patents per firm-standard. The method of estimation is maximum likelihood for the Poisson
model. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard. \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.For more granular difference-in-differences coefficients, see Appendix Tables \\ref{tab:full1},  \\ref{tab:full2}, and  \\ref{tab:full3}.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print the LaTeX table
cat(latex_table)

# Write to a file
writeLines(latex_table, file.path(OUT, "regression_table.tex"))

# Function to extract all coefficients from the main analysis
extract_all_coefficients <- function(models_list, coef_patterns) {
  results <- data.frame()
  
  for (model_name in names(models_list)) {
    model <- models_list[[model_name]]
    coef_names <- names(coef(model))
    
    # Find coefficients matching any pattern
    matched_coefs <- character()
    for (pattern in coef_patterns) {
      matched <- grep(pattern, coef_names, value = TRUE)
      matched_coefs <- c(matched_coefs, matched)
    }
    
    for (coef_name in matched_coefs) {
      tryCatch({
        coef_value <- coef(model)[coef_name]
        vcov_matrix <- vcov(model, cluster = ~firms_std_fe)
        se <- sqrt(vcov_matrix[coef_name, coef_name])
        p_value <- summary(model)$coeftable[coef_name, "Pr(>|z|)"]
        
        results <- rbind(results, data.frame(
          model = model_name,
          coefficient = coef_name,
          estimate = coef_value,
          std_error = se,
          p_value = p_value
        ))
      }, error = function(e) {
        message("Error extracting ", coef_name, " from ", model_name, ": ", e$message)
      })
    }
  }
  
  return(results)
}

# Extract all coefficients
all_coefs <- extract_all_coefficients(unlist(all_models, recursive = FALSE), 
                                     c("post:group_treatment2Q", "post_antic:group_treatment2Q", 
                                       "treattt", "logsale", "logsephld", "logdocid"))

# Function to create individual quartile table
create_quartile_table <- function(comparison_num, all_coefs, num_obs, wald_chi2) {
  # comparison_num should be 2, 3, or 4 (for q12, q13, q14 comparisons)
  
  # Filter coefficients for this comparison
  comparison_pattern <- paste0("q1", comparison_num)
  comparison_coefs <- subset(all_coefs, grepl(comparison_pattern, model))
  
  # Check if we found any coefficients
  if (nrow(comparison_coefs) == 0) {
    stop(paste("No coefficients found for comparison", comparison_num, 
               "using pattern '", comparison_pattern, "'"))
  }
  
  cat("Using pattern:", comparison_pattern, "for comparison", comparison_num, "\n")
  cat("Models found:", unique(comparison_coefs$model), "\n")
  
  # Function to extract and order coefficients by model type
  extract_coefs_by_type <- function(coef_df, coef_pattern) {
    coefs <- subset(coef_df, grepl(coef_pattern, coefficient))
    
    # Define the desired order of models
    model_order <- c("sage_post", "sage_antic", "year_post", "year_antic", "trends_post", "trends_antic")
    
    # Create a factor variable for model type ordering
    pattern_to_remove <- paste0(comparison_pattern, "\\.")
    coefs$model_type <- gsub(pattern_to_remove, "", coefs$model)
    coefs$model_type <- factor(coefs$model_type, levels = model_order)
    
    # Order by model type
    ordered_coefs <- coefs[order(coefs$model_type), ]
    
    return(ordered_coefs)
  }
  
  # Extract all coefficient types
  post_coefs <- extract_coefs_by_type(comparison_coefs, "post:group_treatment2Q")
  antic_coefs <- extract_coefs_by_type(comparison_coefs, "post_antic:group_treatment2Q")
  treattt_coefs <- extract_coefs_by_type(comparison_coefs, "treattt")
  logsale_coefs <- extract_coefs_by_type(comparison_coefs, "logsale")
  logsephld_coefs <- extract_coefs_by_type(comparison_coefs, "logsephld")
  logdocid_coefs <- extract_coefs_by_type(comparison_coefs, "logdocid")
  
 
  cat("\n=== Debug for Comparison", comparison_num, "===\n")
  cat("Post coefficients found:", nrow(post_coefs), "\n")
  cat("Anticipation coefficients found:", nrow(antic_coefs), "\n")
  
  # Function to format coefficients
  format_coef <- function(estimate, se, digits = 3) {
    if (is.na(estimate) || is.na(se)) {
      return("&")
    }
    stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                   ifelse(abs(estimate) > 1.96 * se, "^{**}",
                         ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
    est_formatted <- sprintf(paste0("$%.", digits, "f"), estimate)
    se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
    paste0(est_formatted, stars, "&", se_formatted)
  }
  
  # Create table content with safe indexing
  table_content <- paste0(
    " &&&&&&\\\\\n",
    "  Anticipation-Period && ", format_coef(antic_coefs$estimate[2], antic_coefs$std_error[2]), 
    " && ", format_coef(antic_coefs$estimate[4], antic_coefs$std_error[4]), 
    " && ", format_coef(antic_coefs$estimate[6], antic_coefs$std_error[6]), " \\\\\n",
    "$dPOST*dGroup_{i,EEE} = ", comparison_num, "$ &", 
    format_coef(post_coefs$estimate[1], post_coefs$std_error[1]), 
    "& ", format_coef(post_coefs$estimate[2], post_coefs$std_error[2]), 
    "&", format_coef(post_coefs$estimate[3], post_coefs$std_error[3]), 
    " & ", format_coef(post_coefs$estimate[4], post_coefs$std_error[4]), 
    " &", format_coef(post_coefs$estimate[5], post_coefs$std_error[5]), 
    "& ", format_coef(post_coefs$estimate[6], post_coefs$std_error[6]), "\\\\\n",
    "Standard-firm technology distance &", 
    format_coef(treattt_coefs$estimate[1], treattt_coefs$std_error[1]),
    "&", format_coef(treattt_coefs$estimate[2], treattt_coefs$std_error[2]),
    "&", format_coef(treattt_coefs$estimate[3], treattt_coefs$std_error[3]),
    "&", format_coef(treattt_coefs$estimate[4], treattt_coefs$std_error[4]),
    "&", format_coef(treattt_coefs$estimate[5], treattt_coefs$std_error[5]),
    "&", format_coef(treattt_coefs$estimate[6], treattt_coefs$std_error[6]), "\\\\\n",
    "Sales (log)  &", format_coef(logsale_coefs$estimate[1], logsale_coefs$std_error[1]),
    "&", format_coef(logsale_coefs$estimate[2], logsale_coefs$std_error[2]),
    "&", format_coef(logsale_coefs$estimate[3], logsale_coefs$std_error[3]),
    "&", format_coef(logsale_coefs$estimate[4], logsale_coefs$std_error[4]),
    "&", format_coef(logsale_coefs$estimate[5], logsale_coefs$std_error[5]),
    "&", format_coef(logsale_coefs$estimate[6], logsale_coefs$std_error[6]), "\\\\\n",
    "N of SEP holders (log) &", format_coef(logsephld_coefs$estimate[1], logsephld_coefs$std_error[1]),
    "&", format_coef(logsephld_coefs$estimate[2], logsephld_coefs$std_error[2]),
    "&", format_coef(logsephld_coefs$estimate[3], logsephld_coefs$std_error[3]),
    "&", format_coef(logsephld_coefs$estimate[4], logsephld_coefs$std_error[4]),
    "&", format_coef(logsephld_coefs$estimate[5], logsephld_coefs$std_error[5]),
    "&", format_coef(logsephld_coefs$estimate[6], logsephld_coefs$std_error[6]), "\\\\\n",
    "Standard's documents (log)  &", format_coef(logdocid_coefs$estimate[1], logdocid_coefs$std_error[1]),
    "&", format_coef(logdocid_coefs$estimate[2], logdocid_coefs$std_error[2]),
    "&", format_coef(logdocid_coefs$estimate[3], logdocid_coefs$std_error[3]),
    "&", format_coef(logdocid_coefs$estimate[4], logdocid_coefs$std_error[4]),
    "&", format_coef(logdocid_coefs$estimate[5], logdocid_coefs$std_error[5]),
    "&", format_coef(logdocid_coefs$estimate[6], logdocid_coefs$std_error[6]), "\\\\\n"
  )
  
  # Create the complete LaTeX table
  latex_table <- paste0(
    "\\begin{table}[t]\\centering\n",
    "\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}\n",
    "\\footnotesize\n",
    "\\caption{Effect of IEEE policy change on firm-standard patenting - Quartile 1 vs ", 
    switch(comparison_num, "2" = "2", "3" = "3", "4" = "4"), 
    " Comparison}\n",
    "\\label{tab:full", comparison_num, "} \n",
    "\\adjustbox{max width = \\textwidth}{\n",
    "\\begin{threeparttable}\n",
    "\\begin{tabular}{l*{6}{c}}\n",
    "\\hline\\hline\n",
    "\t&\\multicolumn{2}{c}{Standard-related Patents}&\\multicolumn{2}{c}{Standard-related Patents}&\\multicolumn{2}{c}{Standard-related Patents}\\\\\n",
    "\t\\cmidrule{1-2} \\cmidrule{3-4} \\cmidrule{5-6}&  (1) & (2)  & (3) & (4)  & (5) & (6) \\\\\t \n",
    "\\midrule\n",
    table_content,
    "\\hline\n\n",
    "&&&&&&\\\\\n",
    "Standard Age FE  & Yes& Yes & No & No & Yes & Yes  \\\\\n",
    "Year FE  & No& No & Yes & Yes & No & No  \\\\\n",
    "Polynomial FE  & No & No & No & No & Yes & Yes  \\\\\n",
    "Standard FE  & Yes& Yes & Yes & Yes & No & No \\\\\n",
    "Firm FE  & Yes& Yes & Yes & Yes & Yes & Yes \\\\\n\n",
    "\\hline\n\n",
    "&&&&&&\\\\\n",
    "Num.Obs. &", num_obs, "&", num_obs, "&", num_obs, "&", num_obs, "&", num_obs, "& ", num_obs, "\\\\\n",
    "Wald chi2 &", sprintf("%.2f", wald_chi2[1]), "&", sprintf("%.2f", wald_chi2[2]), 
    "&", sprintf("%.2f", wald_chi2[3]), "&", sprintf("%.2f", wald_chi2[4]), 
    "&", sprintf("%.2f", wald_chi2[5]), "& ", sprintf("%.2f", wald_chi2[6]), "\\\\\n",
    "\\hline\\hline\n",
    "\\end{tabular}\n",
    "\\begin{tablenotes}[flushleft]\n",
    "\\setlength\\labelsep{0pt}\n",
    "\\item \n",
    "\\footnotesize{\n",
    "\t\\textit{Note}: The dependent variable is the weighted number of patents per firm-standard. The method of estimation is maximum likelihood for the Poisson\n",
    "model. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard. \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}\n",
    "    \\end{tablenotes}\n",
    "\\end{threeparttable}}\n",
    "\\end{table}"
  )
  
  return(latex_table)
}


# Function to extract model statistics
extract_model_stats <- function(models_list) {
  stats <- data.frame()
  
  for (model_name in names(models_list)) {
    model <- models_list[[model_name]]
    stats <- rbind(stats, data.frame(
      model = model_name,
      nobs = nobs(model),
      loglik = logLik(model),
      wald_chi2 = ifelse(!is.null(summary(model)$wald$statistic), 
                         summary(model)$wald$statistic, NA)
    ))
  }
  
  return(stats)
}

# Extract model statistics
model_stats <- extract_model_stats(unlist(all_models, recursive = FALSE))

# Get number of observations and Wald chi2 for each quartile
num_obs_q2 <- 18598  
num_obs_q3 <- 18436
num_obs_q4 <- 18522

wald_chi2_q2 <- c(-85008.25, -84740.39, -85013.02 ,-84831.37 , -84899.69, -84639.46)  

wald_chi2_q3 <- c(-77926.11 , -77800.47 ,-77950.26, -77921.40 ,-77914.32, -77789.48)  

wald_chi2_q4 <- c(-76686.94, -76562.64, -76713.02, -76686.96, -76664.60, -76540.79)  


#Create the tables
table_q2 <- create_quartile_table(2, all_coefs, num_obs_q2, wald_chi2_q2)
table_q3 <- create_quartile_table(3, all_coefs, num_obs_q3, wald_chi2_q3)
table_q4 <- create_quartile_table(4, all_coefs, num_obs_q4, wald_chi2_q4)

# Save the tables
writeLines(table_q2, file.path(OUT, "comparison2_table.tex"))
writeLines(table_q3, file.path(OUT, "comparison3_table.tex"))
writeLines(table_q4, file.path(OUT, "comparison4_table.tex"))

########ROBUSTENSS CHECKS ##########

##EVENT STUDY


# Function to run event study 
run_event_study <- function(data) {
  feglm(
    patn_ws ~ 
      # Event study interactions (group_treatment2Q × year dummies)
    i(group_treatment2Q, f2010, ref = 0) +
    i(group_treatment2Q, f2011, ref = 0) +
    i(group_treatment2Q, f2013, ref = 0) +
    i(group_treatment2Q, f2014, ref = 0) +  # anticipation year estimated
    i(group_treatment2Q, f2015, ref = 0) +
    i(group_treatment2Q, f2016, ref = 0) +
    i(group_treatment2Q, f2017, ref = 0) +
    f2010+f2011 + f2013 + f2014 + f2015 + f2016 + f2017 + group_treatment2Q 	+i(group_treatment2Q):sage_cont +
      # Controls
      treattt + logsale + logsephld + logdocid ,
    data = data,
    family = "poisson",
    fixef = c("std_fe", "firms_fe"),
    cluster = ~firms_std_fe
  )
}

# Run models for all quartile comparisons
event_q12 <- run_event_study(df_q12)  # Q1 vs Q2
event_q13 <- run_event_study(df_q13)  # Q1 vs Q3
event_q14 <- run_event_study(df_q14)  # Q1 vs Q4

# Summarize results
summary(event_q12)
summary(event_q13)
summary(event_q14)

# Function to test pre-trends (f2010 and f2011)
test_pre_trends <- function(model) {
  # Get coefficient names
  coef_names <- names(coef(model))
  
  # Identify pre-trend interactions 
  pre_coefs <- coef_names[grepl("group_treatment2Q.*f2010|group_treatment2Q.*f2011", coef_names)]
  
  # Run Wald test (joint test = coefficients = 0)
  wald(model, pre_coefs)
}

# Apply to models
test_pre_trends(event_q12)
test_pre_trends(event_q13)
test_pre_trends(event_q14)


# Function to extract event study coefficients and create table
create_event_study_table <- function(event_q12, event_q13, event_q14) {
  
  # Function to extract coefficients for a specific year pattern
  extract_year_coefs <- function(model, year_pattern) {
    coef_names <- names(coef(model))
    year_coefs <- coef_names[grepl(year_pattern, coef_names)]
    
    results <- data.frame()
    for (coef_name in year_coefs) {
      coef_value <- coef(model)[coef_name]
      se <- sqrt(vcov(model, cluster = ~firms_std_fe)[coef_name, coef_name])
      p_value <- summary(model)$coeftable[coef_name, "Pr(>|z|)"]
      
      results <- rbind(results, data.frame(
        coefficient = coef_name,
        estimate = coef_value,
        std_error = se,
        p_value = p_value
      ))
    }
    return(results)
  }
  
  # Define the specific years for each period
  pre_years <- c(2010, 2011, 2013)  # Pre-period years
  anticipation_year <- 2014          # Anticipation year
  post_years <- c(2015, 2016, 2017)  # Post-period years
  
  all_years <- c(pre_years, anticipation_year, post_years)
  
  # Create empty data frame to store results
  event_results <- data.frame(
    year = rep(all_years, each = 3),
    quartile = rep(c("q12", "q13", "q14"), times = length(all_years)),
    estimate = NA,
    std_error = NA,
    p_value = NA
  )
  
  # Fill in the results
  for (year in all_years) {
    year_pattern <- paste0("f", year)
    
    # Q12
    q12_coefs <- extract_year_coefs(event_q12, year_pattern)
    if (nrow(q12_coefs) > 0) {
      event_results[event_results$year == year & event_results$quartile == "q12", 
                   c("estimate", "std_error", "p_value")] <- q12_coefs[1, c("estimate", "std_error", "p_value")]
    }
    
    # Q13
    q13_coefs <- extract_year_coefs(event_q13, year_pattern)
    if (nrow(q13_coefs) > 0) {
      event_results[event_results$year == year & event_results$quartile == "q13", 
                   c("estimate", "std_error", "p_value")] <- q13_coefs[1, c("estimate", "std_error", "p_value")]
    }
    
    # Q14
    q14_coefs <- extract_year_coefs(event_q14, year_pattern)
    if (nrow(q14_coefs) > 0) {
      event_results[event_results$year == year & event_results$quartile == "q14", 
                   c("estimate", "std_error", "p_value")] <- q14_coefs[1, c("estimate", "std_error", "p_value")]
    }
  }
  
  # Function to format coefficients
  format_coef <- function(estimate, se, digits = 3) {
    stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                   ifelse(abs(estimate) > 1.96 * se, "^{**}",
                         ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
    est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
    se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
    paste0("$", est_formatted, stars, "$ & ", se_formatted)
  }
  
  # Create table content
  table_content <- ""
  
  # Pre-period (2010, 2011, 2013)
  table_content <- paste0(table_content, "Pre-Period &&&&\\\\\n")
  for (year in pre_years) {
    year_data <- event_results[event_results$year == year, ]
    table_content <- paste0(table_content,
      "& ", year, " &", 
      format_coef(year_data$estimate[year_data$quartile == "q12"], year_data$std_error[year_data$quartile == "q12"]),
      "&", format_coef(year_data$estimate[year_data$quartile == "q13"], year_data$std_error[year_data$quartile == "q13"]),
      "&", format_coef(year_data$estimate[year_data$quartile == "q14"], year_data$std_error[year_data$quartile == "q14"]),
      "\\\\\n"
    )
  }
  
  # Anticipation period (2014)
  table_content <- paste0(table_content, "&&&&\\\\\nAnticipation-Period &&&&\\\\\n")
  year_2014 <- event_results[event_results$year == anticipation_year, ]
  table_content <- paste0(table_content,
    "& 2014 &", 
    format_coef(year_2014$estimate[year_2014$quartile == "q12"], year_2014$std_error[year_2014$quartile == "q12"]),
    "&", format_coef(year_2014$estimate[year_2014$quartile == "q13"], year_2014$std_error[year_2014$quartile == "q13"]),
    "&", format_coef(year_2014$estimate[year_2014$quartile == "q14"], year_2014$std_error[year_2014$quartile == "q14"]),
    "\\\\\n"
  )
  
  # Post-period (2015, 2016, 2017)
  table_content <- paste0(table_content, "&&&&\\\\\nPost-Period  &&&&\\\\\n")
  for (year in post_years) {
    year_data <- event_results[event_results$year == year, ]
    table_content <- paste0(table_content,
      "& ", year, " &", 
      format_coef(year_data$estimate[year_data$quartile == "q12"], year_data$std_error[year_data$quartile == "q12"]),
      "&", format_coef(year_data$estimate[year_data$quartile == "q13"], year_data$std_error[year_data$quartile == "q13"]),
      "&", format_coef(year_data$estimate[year_data$quartile == "q14"], year_data$std_error[year_data$quartile == "q14"]),
      "\\\\\n"
    )
  }
  
  # Create the complete LaTeX table
  latex_table <- paste0(
    "\\begin{table}[htbp]\\centering\n",
    "\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}\n",
    "\\footnotesize\n",
    "\\caption{Effect of IEEE policy change on firm-standard patenting - Event Study}\n",
    "\\label{tab:robustness3}\n",
    "\\adjustbox{max width = \\textwidth}{\n",
    "\\begin{threeparttable}\n",
    "\\begin{tabular}{l*{4}{c}}\n",
    "\\hline\\hline\n",
    "\t&\\multicolumn{1}{c}{}&\\multicolumn{1}{c}{2nd Quartile}&\\multicolumn{1}{c}{3rd Quartile}&\\multicolumn{1}{c}{4th Quartile}\\\\\n",
    "\\midrule\n",
    table_content,
    "\\hline\n\n",
    "&&&&\\\\\n",
    "Covariates & & Yes& Yes & Yes  \\\\\n",
    "Quartile_time_trend & & Yes& Yes &  Yes   \\\\\n",
    "Standard FE & & Yes& Yes & Yes  \\\\\n",
    "Firm FE & & Yes& Yes & Yes   \\\\\n\n",
    "\\hline\\hline\n",
    "\\end{tabular}\n",
    "\\begin{tablenotes}[flushleft]\n",
    "\\setlength\\labelsep{0pt}\n",
    "\\item \n",
    "\\footnotesize{\n",
    "\t\\textit{Note}: The dependent variable is the weighted number of patents per firm-standard. The baseline period is 2012. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard. \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}\n",
    "    \\end{tablenotes}\n",
    "\\end{threeparttable}}\n",
    "\\end{table}"
  )
  
  return(latex_table)
}

# Create the event study table
event_table <- create_event_study_table(event_q12, event_q13, event_q14)

# Print the table
cat(event_table)

# Write to file
writeLines(event_table, file.path(OUT, "event_study_table.tex"))


#####CONTINOUS TREATMENT

# Center standard age 
df[, sage_cont := group_Sage - median(group_Sage)]  

#Post Only
# Estimate with standard-age-specific trends
model_sage_trends_contin <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group1:post + group2:post + group3:post + group4:post +
    
    post +
    group1 + group2 + group3 + group4 +
    
    # Group-specific trends by standard age
    i(group2):sage_cont +  # Treated vs. control trends by age
    i(group3):sage_cont + 
    i(group4):sage_cont + 
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df,
  vcov = ~firms_std_fe
)

# Summary of the results
summary(model_sage_trends_contin)

#Anticicaption Effect
# Estimate with standard-age-specific trends
model_sage_trends_cont_ant <- fepois(
  patn_ws ~ 
    # DiD terms (policy effects)
    group1:post_antic + group2:post_antic + group3:post_antic + group4:post_antic +
    group1:post + group2:post + group3:post + group4:post +
    
    post_antic + post +
    group1 + group2 + group3 + group4 +
    
    # Group-specific trends by standard age
    i(group2):sage_cont +  # Treated vs. control trends by age
    i(group3):sage_cont + 
    i(group4):sage_cont + 
   # Treated vs. control trends by age
    
    # Controls
    treattt + logsale + logsephld + logdocid  + 
    i(group_Sage) |  # Standard age FE (non-linear adjustments)
    
    # Fixed effects
    std_fe + firms_fe,
  
  data = df,
  vcov = ~firms_std_fe
)

# Summary of the results
summary(model_sage_trends_cont_ant)

# Extract coefficients 
extract_coefs_by_exact_names <- function(model, coef_names) {
  results <- data.frame()
  for (coef_name in coef_names) {
    if (coef_name %in% names(coef(model))) {
      # Extract quartile number
      quartile <- as.numeric(gsub(".*group", "", coef_name))
      
      results <- rbind(results, data.frame(
        coefficient = coef_name,
        quartile = quartile,
        estimate = coef(model)[coef_name],
        std_error = sqrt(vcov(model, cluster = ~firms_std_fe)[coef_name, coef_name]),
        p_value = summary(model)$coeftable[coef_name, "Pr(>|z|)"],
        stringsAsFactors = FALSE
      ))
    }
  }
  return(results[order(results$quartile), ])
}

# Extract coefficients from both models
post_coefs_contin <- extract_coefs_by_exact_names(model_sage_trends_contin, 
                                                 c("post:group2", "post:group3", "post:group4"))

post_coefs_cont_ant <- extract_coefs_by_exact_names(model_sage_trends_cont_ant,
                                                   c("post:group2", "post:group3", "post:group4"))

antic_coefs_cont_ant <- extract_coefs_by_exact_names(model_sage_trends_cont_ant,
                                                    c("post_antic:group2", "post_antic:group3", "post_antic:group4"))

# Print
cat("Post coefficients from contin model:\n")
print(post_coefs_contin)

cat("\nPost coefficients from cont_ant model:\n")
print(post_coefs_cont_ant)

cat("\nAnticipation coefficients from cont_ant model:\n")
print(antic_coefs_cont_ant)

# Function to format coefficients with stars
format_coef <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) {
    return("&")
  }
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ & ", se_formatted)
}

# Create table content
table_content <- paste0(
  " Anticipation-Period  &&&\\\\\n",
  " & 2nd Quartile && ", format_coef(antic_coefs_cont_ant$estimate[antic_coefs_cont_ant$quartile == 2], 
                                    antic_coefs_cont_ant$std_error[antic_coefs_cont_ant$quartile == 2]), "  \\\\\n",
  " &&& ", format_coef(NA, antic_coefs_cont_ant$std_error[antic_coefs_cont_ant$quartile == 2]), " \\\\\n",
  " & 3rd Quartile && ", format_coef(antic_coefs_cont_ant$estimate[antic_coefs_cont_ant$quartile == 3], 
                                    antic_coefs_cont_ant$std_error[antic_coefs_cont_ant$quartile == 3]), " \\\\\n",
  " &&& ", format_coef(NA, antic_coefs_cont_ant$std_error[antic_coefs_cont_ant$quartile == 3]), " \\\\\n",
  " & 4th Quartile && ", format_coef(antic_coefs_cont_ant$estimate[antic_coefs_cont_ant$quartile == 4], 
                                    antic_coefs_cont_ant$std_error[antic_coefs_cont_ant$quartile == 4]), "\\\\\n",
  " &&& ", format_coef(NA, antic_coefs_cont_ant$std_error[antic_coefs_cont_ant$quartile == 4]), " \\\\\n",
  "&&&\\\\\n",
  " Post-Period  &&&\\\\\n",
  " & 2nd Quartile &", format_coef(post_coefs_contin$estimate[post_coefs_contin$quartile == 2], 
                                  post_coefs_contin$std_error[post_coefs_contin$quartile == 2]),
  "&", format_coef(post_coefs_cont_ant$estimate[post_coefs_cont_ant$quartile == 2], 
                  post_coefs_cont_ant$std_error[post_coefs_cont_ant$quartile == 2]), " \\\\\n",
  " & 3rd Quartile &", format_coef(post_coefs_contin$estimate[post_coefs_contin$quartile == 3], 
                                  post_coefs_contin$std_error[post_coefs_contin$quartile == 3]),
  "&", format_coef(post_coefs_cont_ant$estimate[post_coefs_cont_ant$quartile == 3], 
                  post_coefs_cont_ant$std_error[post_coefs_cont_ant$quartile == 3]), "  \\\\\n",
  " & 4th Quartile &", format_coef(post_coefs_contin$estimate[post_coefs_contin$quartile == 4], 
                                  post_coefs_contin$std_error[post_coefs_contin$quartile == 4]),
  "&", format_coef(post_coefs_cont_ant$estimate[post_coefs_cont_ant$quartile == 4], 
                  post_coefs_cont_ant$std_error[post_coefs_cont_ant$quartile == 4]), "  \\\\\n"
)

# Create the complete LaTeX table
latex_table <- paste0(
"\\begin{table}[htbp]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Effect of IEEE policy change - Robustness checks II}
\\label{tab:robustness2}
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{4}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{Standard-related Patents}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3} & & (1) & (2)   \\\\\t 
\\midrule\n",
table_content,
"\\hline
&&&&\\\\
Covariates & & Yes& Yes  \\\\
Standard Age FE & & Yes& Yes \\\\
Standard FE & & Yes& Yes   \\\\
Firm FE & & Yes& Yes  \\\\

\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: The dependent variable is the weighted number of patents per firm-standard. The method of estimation is maximum likelihood for the Poisson model in the multiple regression, accounting for all groups in a single specification. The control group is the first quartile, and the baseline period is 2010-2014. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard.  \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print the table
cat(latex_table)

# Write to file
writeLines(latex_table, file.path(OUT, "continuous_treatment_table.tex"))


###Different Anticipation Effects

# Function for Specification : Sage Trends (Extended Anticipation Effect)
run_sage_trends_antic_ext <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post_antic_2013 + group_treatment2Q:post_antic + 
      group_treatment2Q:post + post_antic_2013 + post_antic + post + 
      group_treatment2Q + i(group_treatment2Q):sage_cont + treattt + logsale + 
      logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Function for Specification 3: Sage Trends (Extended Anticipation Effect)
run_sage_trends_antic_ext_pool <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patn_ws ~ group_treatment2Q:post_antic_1  + 
      group_treatment2Q:post + post_antic_1 + post + 
      group_treatment2Q + i(group_treatment2Q):sage_cont + treattt + logsale + 
      logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}
 
q12_ant_ext = run_sage_trends_antic_ext(df_q12)
q13_ant_ext = run_sage_trends_antic_ext(df_q13)
q14_ant_ext = run_sage_trends_antic_ext(df_q14)

q12_ant_ext_pool = run_sage_trends_antic_ext_pool(df_q12)
q13_ant_ext_pool = run_sage_trends_antic_ext_pool(df_q13)
q14_ant_ext_pool = run_sage_trends_antic_ext_pool(df_q14)

# Function to extract coefficients from the models
extract_anticipation_coefs <- function(model, coef_patterns) {
  results <- data.frame()
  coef_names <- names(coef(model))
  
  for (pattern in coef_patterns) {
    matched_coefs <- coef_names[grepl(pattern, coef_names)]
    for (coef_name in matched_coefs) {
      results <- rbind(results, data.frame(
        coefficient = coef_name,
        estimate = coef(model)[coef_name],
        std_error = sqrt(vcov(model, cluster = ~firms_std_fe)[coef_name, coef_name]),
        p_value = summary(model)$coeftable[coef_name, "Pr(>|z|)"],
        stringsAsFactors = FALSE
      ))
    }
  }
  
  return(results)
}

# Extract coefficients for all quartiles
extract_all_quartile_coefs <- function(models_list, coef_patterns, model_type) {
  results <- data.frame()
  quartiles <- c("q12", "q13", "q14")
  
  for (i in 1:3) {
    quartile <- quartiles[i]
    model <- models_list[[i]]
    coefs <- extract_anticipation_coefs(model, coef_patterns)
    coefs$quartile <- i + 1  # 2, 3, 4
    coefs$model_type <- model_type
    results <- rbind(results, coefs)
  }
  
  return(results)
}

# Extract coefficients from both model types
# For the extended model (separate 2013 and 2014) 
ext_patterns <- c("post_antic_2013:group_treatment2Q", "post_antic:group_treatment2Q", "post:group_treatment2Q")
ext_results <- extract_all_quartile_coefs(list(q12_ant_ext, q13_ant_ext, q14_ant_ext), 
                                         ext_patterns, "extended")

# For the pooled model (pooled 2013-2014) 
pool_patterns <- c("post_antic_1:group_treatment2Q", "post:group_treatment2Q")
pool_results <- extract_all_quartile_coefs(list(q12_ant_ext_pool, q13_ant_ext_pool, q14_ant_ext_pool), 
                                          pool_patterns, "pooled")

# Combine results
all_results <- rbind(ext_results, pool_results)

# Function to format coefficients with stars
format_coef <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) {
    return("&")
  }
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ & ", se_formatted)
}

# Create table content
table_content <- ""

# Add anticipation periods
table_content <- paste0(table_content, " Anticipation-Period  &&&&\\\\\n")

# Extended model (separate 2013 and 2014)
for (q in 2:4) {
  # 2013 anticipation - group interaction
  coef_2013 <- ext_results[ext_results$quartile == q & grepl("2013", ext_results$coefficient), ]
  table_content <- paste0(table_content,
    " & ", ifelse(q == 2, "2nd", ifelse(q == 3, "3rd", "4th")), " Quartile (2013) && ",
    format_coef(coef_2013$estimate, coef_2013$std_error), "  \\\\\n",
    " &&& ", format_coef(NA, coef_2013$std_error), " \\\\\n"
  )
  
  # 2014 anticipation - group interaction
  coef_2014 <- ext_results[ext_results$quartile == q & grepl("post_antic:group", ext_results$coefficient) & !grepl("2013", ext_results$coefficient), ]
  table_content <- paste0(table_content,
    " & ", ifelse(q == 2, "2nd", ifelse(q == 3, "3rd", "4th")), " Quartile (2014) && ",
    format_coef(coef_2014$estimate, coef_2014$std_error), "  \\\\\n",
    " &&& ", format_coef(NA, coef_2014$std_error), " \\\\\n"
  )
}

# Pooled model (2013-2014) - group interaction
for (q in 2:4) {
  coef_pool <- pool_results[pool_results$quartile == q & grepl("post_antic_1:group", pool_results$coefficient), ]
  table_content <- paste0(table_content,
    " & ", ifelse(q == 2, "2nd", ifelse(q == 3, "3rd", "4th")), " Quartile (Pooled) && ",
    format_coef(coef_pool$estimate, coef_pool$std_error), "  \\\\\n",
    " &&& ", format_coef(NA, coef_pool$std_error), " \\\\\n"
  )
}

table_content <- paste0(table_content, "&&&\\\\\n")

# Add post periods - group interactions
table_content <- paste0(table_content, " Post-Period  &&&&\\\\\n")

# Post coefficients from both models
for (q in 2:4) {
  # Extended model post - group interaction
  coef_ext_post <- ext_results[ext_results$quartile == q & grepl("post:group_treatment2Q", ext_results$coefficient), ]
  # Pooled model post - group interaction
  coef_pool_post <- pool_results[pool_results$quartile == q & grepl("post:group_treatment2Q", pool_results$coefficient), ]
  
  table_content <- paste0(table_content,
    " & ", ifelse(q == 2, "2nd", ifelse(q == 3, "3rd", "4th")), " Quartile &",
    format_coef(coef_ext_post$estimate, coef_ext_post$std_error),
    "&", format_coef(coef_pool_post$estimate, coef_pool_post$std_error), " \\\\\n"
  )
}

# Create the complete LaTeX table
latex_table <- paste0(
"\\begin{table}[htbp]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Effect of IEEE policy change - Anticipation Effect Specifications}
\\label{tab:anticipation_specs}
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{4}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{Standard-related Patents}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3} & & Extended & Pooled \\\\\t 
\\midrule\n",
table_content,
"\\hline
&&&&\\\\
Covariates & & Yes& Yes  \\\\
Standard Age FE & & Yes& Yes \\\\
Standard FE & & Yes& Yes   \\\\
Firm FE & & Yes& Yes  \\\\

\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: The dependent variable is the weighted number of patents per firm-standard. Column (1) shows results from the extended specification with separate coefficients for 2013 and 2014 anticipation effects. Column (2) shows results from the pooled specification with a single coefficient for the 2013-2014 anticipation period. All coefficients represent interaction effects between the treatment group and time periods. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard.  \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print the table
cat(latex_table)

# Write to file
writeLines(latex_table, file.path(OUT, "anticipation_specs_table.tex"))

###MECHANISMS

##1. NON-STANDARD RELATED PATENTS

# Function for Specification 3: Sage Trends (Post Only)
run_sage_trends_post_ns <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patNS ~ group_treatment2Q:post + 
      post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treattt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}


# Function for Specification 3: Sage Trends (Regular Anticipation Effect)
run_sage_trends_antic_ns <- function(data) {
  # Ensure sage_cont exists
  if (!"sage_cont" %in% names(data)) {
    data[, sage_cont := group_Sage - median(group_Sage, na.rm = TRUE)]
  }
  
  fepois(
    patNS ~ group_treatment2Q:post_antic + group_treatment2Q:post + 
      post_antic + post + group_treatment2Q + i(group_treatment2Q):sage_cont + 
      treattt + logsale + logsephld + logdocid + i(group_Sage) | std_fe + firms_fe,
    data = data,
    vcov = ~firms_std_fe
  )
}

# Now run the models using the adapted functions
q12_ns <- run_sage_trends_post_ns(df_q12)
q13_ns <- run_sage_trends_post_ns(df_q13)
q14_ns <- run_sage_trends_post_ns(df_q14)

q12_ns_antic <- run_sage_trends_antic_ns(df_q12)
q13_ns_antic <- run_sage_trends_antic_ns(df_q13)
q14_ns_antic <- run_sage_trends_antic_ns(df_q14)

# Summarize the results
summary(q12_ns)
summary(q13_ns)
summary(q14_ns)

summary(q12_ns_antic)
summary(q13_ns_antic)
summary(q14_ns_antic)

# Function to extract coefficients 
extract_coefs_specific <- function(model, coef_type = "post") {
  tryCatch({
    if (is.null(model)) {
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_names <- names(coef(model))
    cat("Available coefficients:", paste(coef_names, collapse = ", "), "\n")
    
    if (coef_type == "post") {
      # Look for post coefficient (not post_antic)
      target_coef <- coef_names[grepl("group_treatment2Q:post$|post:group_treatment2Q$", coef_names)]
      if (length(target_coef) == 0) {
        target_coef <- coef_names[grepl(":post[^_]|post[^_]:", coef_names)]
      }
    } else if (coef_type == "antic") {
      # Look specifically for post_antic coefficient
      target_coef <- coef_names[grepl("group_treatment2Q:post_antic|post_antic:group_treatment2Q", coef_names)]
      if (length(target_coef) == 0) {
        target_coef <- coef_names[grepl("post_antic", coef_names)]
      }
    }
    
    if (length(target_coef) == 0) {
      cat("No coefficient found for type:", coef_type, "\n")
      return(data.frame(estimate = NA, std_error = NA))
    }
    
    coef_name <- target_coef[1]
    cat("Using coefficient for", coef_type, ":", coef_name, "\n")
    
    vcov_matrix <- vcov(model, cluster = ~firms_std_fe)
    std_error <- sqrt(vcov_matrix[coef_name, coef_name])
    
    return(data.frame(
      estimate = coef(model)[coef_name],
      std_error = std_error
    ))
  }, error = function(e) {
    cat("Error:", e$message, "\n")
    return(data.frame(estimate = NA, std_error = NA))
  })
}

#Extract coefficients
cat("\n=== Re-extracting coefficients with specific patterns ===\n")
ns_results <- list()
for (q in c("q12", "q13", "q14")) {
  cat("\n=== Extracting non-standard patents for", q, "===\n")
  ns_results[[q]] <- list(
    post = extract_coefs_specific(get(paste0(q, "_ns")), "post"),
    antic = extract_coefs_specific(get(paste0(q, "_ns_antic")), "antic"),
    post_from_antic = extract_coefs_specific(get(paste0(q, "_ns_antic")), "post")
  )
}

# Function to format coefficients for table
format_coef_table <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) return(" & ")
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ & ", se_formatted)
}

# Function to format coefficients with line break
format_coef_multiline <- function(estimate, se, digits = 3) {
  if (is.na(estimate) || is.na(se)) return(" & \\\\\n")
  stars <- ifelse(abs(estimate) > 2.576 * se, "^{***}",
                 ifelse(abs(estimate) > 1.96 * se, "^{**}",
                       ifelse(abs(estimate) > 1.645 * se, "^{*}", "")))
  est_formatted <- sprintf(paste0("%.", digits, "f"), estimate)
  se_formatted <- sprintf(paste0("(%.", digits, "f)"), se)
  paste0("$", est_formatted, stars, "$ \\\\\n & ", se_formatted, " \\\\\n")
}

# Table 1: Non-standard patents
table1_content <- ""

# Anticipation-Period section
table1_content <- paste0(table1_content, " Anticipation-Period &&\\\\\n")
for (q in c("q12", "q13", "q14")) {
  quartile_name <- switch(q, "q12" = "2nd", "q13" = "3rd", "q14" = "4th")
  
  antic_coef <- format_coef_multiline(
    ns_results[[q]]$antic$estimate, 
    ns_results[[q]]$antic$std_error
  )
  
  table1_content <- paste0(table1_content,
    " & ", quartile_name, " Quartile", antic_coef
  )
}
table1_content <- paste0(table1_content, "&&\\\\\n")

# Post-Period section
table1_content <- paste0(table1_content, " Post-Period &&\\\\\n")
for (q in c("q12", "q13", "q14")) {
  quartile_name <- switch(q, "q12" = "2nd", "q13" = "3rd", "q14" = "4th")
  
  post_coef <- format_coef_table(
    ns_results[[q]]$post$estimate, 
    ns_results[[q]]$post$std_error
  )
  
  post_antic_coef <- format_coef_table(
    ns_results[[q]]$post_from_antic$estimate, 
    ns_results[[q]]$post_from_antic$std_error
  )
  
  table1_content <- paste0(table1_content,
    " & ", quartile_name, " Quartile", post_coef, post_antic_coef, "\\\\\n"
  )
}

# Create non-standard patents table
latex_table1 <- paste0(
"\\begin{table}[t]\\centering
\\def\\sym#1{\\ifmmode^{#1}\\else\\(^{#1}\\)\\fi}
\\footnotesize
\\caption{Effect of IEEE policy change on Non-standard-related Patents}
\\label{tab:diff2} 
\\adjustbox{max width = \\textwidth}{
\\begin{threeparttable}
\\begin{tabular}{l*{3}{c}}
\\hline\\hline
\t&\\multicolumn{1}{c}{}&\\multicolumn{2}{c}{Non-std Patents}\\\\
\t\\cmidrule{1-1} \\cmidrule{2-3} & & (1) & (2)  \\\\\t 
\\midrule\n",
table1_content,
"\\hline
&&\\\\
Covariates & & Yes & Yes  \\
Standard Age FE & & Yes & Yes   \\
Standard FE & & Yes & Yes   \\
Firm FE & & Yes & Yes  \\

\\hline\\hline
\\end{tabular}
\\begin{tablenotes}[flushleft]
\\setlength\\labelsep{0pt}
\\item 
\\footnotesize{
\t\\textit{Note}: The dependent variable is the number of non-standard-related patents per firm-standard. The method of estimation is maximum likelihood for the Poisson
model. Standard errors are presented in parentheses and allow for serial correlation through clustering by firm-standard.  \\sym{*} \\(p<0.1\\), \\sym{**} \\(p<0.05\\), \\sym{***} \\(p<0.01\\) significant levels.}
    \\end{tablenotes}
\\end{threeparttable}}
\\end{table}"
)

# Print and save table 
cat(latex_table1)
writeLines(latex_table1, file.path(OUT, "non_standard_patents_table.tex"))


