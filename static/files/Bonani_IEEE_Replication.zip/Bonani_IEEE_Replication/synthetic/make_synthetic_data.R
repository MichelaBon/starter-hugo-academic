# ---------------------------------------------------------------------------
# Synthetic data for "Standard-Setting and the Incentives to Innovate:
# Evidence from the IEEE Patent Policy Update" (Bonani, IJIO 2026)
#
# The original analysis data are built from licensed sources (SCDB, PATSTAT,
# Compustat) and cannot be redistributed. This script creates FAKE data with
# the same structure (variable names, types, panel dimensions) as the
# analysis files, so that every script in R/ can be run end to end.
#
# The numbers are random draws. Results obtained on these data are NOT the
# results reported in the paper and should not be interpreted.
#
# Usage (from the replication package root):
#   Rscript synthetic/make_synthetic_data.R
# then run the analysis on the synthetic data with, e.g.
#   REPLICATION_DATA=data_synthetic Rscript R/Main_Analysis.R
# ---------------------------------------------------------------------------

library(data.table)
set.seed(20260101)

OUT_DIR <- file.path("data_synthetic", "data da usare")
dir.create(file.path(OUT_DIR, "ETSI"), recursive = TRUE, showWarnings = FALSE)

make_panel <- function(n_firms = 543, n_std = 12, years = 2010:2017,
                       policy_year = 2015, effect = 0.25) {

  # --- firms: time-invariant characteristics -------------------------------
  firms <- data.table(
    company_id      = sprintf("F%04d", seq_len(n_firms)),
    loc             = sample(c("USA", "JPN", "KOR", "CHN", "DEU", "FIN", "GBR",
                               "FRA", "TWN", "CAN", "NLD", "SWE"),
                             n_firms, replace = TRUE,
                             prob = c(.30, .15, .08, .08, .07, .05, .05, .05,
                                      .05, .04, .04, .04)),
    naics           = sample(c(334220, 334413, 334111, 517311, 511210, 541512,
                               334290, 334418), n_firms, replace = TRUE),
    TREAT_declaring = rbinom(n_firms, 1, 0.35),       # 1 = SEP holder
    size            = rlnorm(n_firms, meanlog = 0, sdlog = 1.2)
  )

  # --- standards: each has a first-publication year -------------------------
  stds <- data.table(
    standard_family1 = sprintf("IEEE 802.%d", seq_len(n_std)),
    first_year       = sample(1995:2009, n_std, replace = TRUE)
  )

  # --- firm-standard pairs: each firm participates in 1-6 standards ---------
  pairs <- firms[, .(standard_family1 = sample(stds$standard_family1,
                                               min(sample(1:6, 1), n_std))),
                 by = company_id]
  pairs[, TECH_before := pmin(pmax(rbeta(.N, 2.2, 6), 0.01), 0.95)]
  pairs[, TECH_before_var := pmin(pmax(TECH_before + rnorm(.N, 0, 0.03), 0.01), 0.99)]
  pairs[, pair_effect := rnorm(.N, 0, 0.5)]

  # --- panel: pair x year ----------------------------------------------------
  df <- pairs[, .(year = years), by = .(company_id, standard_family1,
                                       TECH_before, TECH_before_var, pair_effect)]
  df <- merge(df, firms, by = "company_id")
  df <- merge(df, stds,  by = "standard_family1")

  df[, Sage := year - first_year]
  df[, post := as.integer(year >= policy_year)]

  # firm financials
  df[, E       := round(size * 2000 * exp(rnorm(.N, 0, 0.1)))]
  df[, SALE    := size * 800 * exp(rnorm(.N, 0, 0.15))]
  df[, logSALE := log(SALE + 1)]
  df[, RD      := SALE * runif(.N, 0.05, 0.2)]
  df[, logRD   := log(RD + 1)]

  # standard-related activity
  df[, sep_hld_TOTF := rpois(.N, 2 + 10 * TREAT_declaring * size)]
  df[, doc_idn      := rpois(.N, 3 + 5 * size)]

  # patent outcomes: firms farther from the standard (low TECH_before)
  # patent more after the policy (a stylised, made-up effect)
  mu <- with(df, exp(0.5 + 0.6 * log(size + 1) + pair_effect +
                     0.03 * (year - 2010) +
                     effect * post * (1 - TECH_before)))
  df[, patn_ws    := rpois(.N, mu)]
  df[, patn_ws_w0 := rpois(.N, mu * 0.9)]
  df[, patNS      := rpois(.N, mu * 1.5)]
  df[, patTOT     := patn_ws + patNS]

  df[, c("pair_effect", "size", "first_year", "post", "SALE", "RD") := NULL]
  setcolorder(df, c("company_id", "standard_family1", "year"))
  df[order(company_id, standard_family1, year)]
}

main <- make_panel()
fwrite(main, file.path(OUT_DIR, "final_lag1_TECHall543.csv"))

# Robustness samples (same structure)
fwrite(main[company_id %in% sample(unique(company_id), 500)],
       file.path(OUT_DIR, "final_lag1_TECHall5432012.csv"))
fwrite(make_panel(n_firms = 150, n_std = 4),
       file.path(OUT_DIR, "final_lag1_TECHallBluetooth.csv"))
fwrite(make_panel(n_firms = 400, n_std = 10),
       file.path(OUT_DIR, "ETSI", "ETSI final.csv"))

cat("Synthetic data written to", OUT_DIR, "\n")
