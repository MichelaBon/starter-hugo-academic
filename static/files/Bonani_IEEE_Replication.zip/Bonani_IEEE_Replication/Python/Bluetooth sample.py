import os
# ---------------------------------------------------------------------------
# Paths: all data are read from / written to the DATA folder.
# By default this is <replication package>/data. To run on the synthetic
# data instead, set the environment variable REPLICATION_DATA=data_synthetic.
# ---------------------------------------------------------------------------
try:
    ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
except NameError:  # interactive session: run from the package root
    ROOT = os.getcwd()
DATA = os.path.join(ROOT, os.environ.get("REPLICATION_DATA", "data"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)




# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
#import seaborn as sb
from scipy.stats import chisquare
#import matplotlib
import matplotlib.pyplot as plt
#import dask.dataframe as dd
#from dask.diagnostics import ProgressBar 
from itertools import tee, islice, chain

####### USEFULL FUNCTION

def num_missing(x):
  return sum(x.isnull())

def tidy_split(df, column, sep='|', keep=False):
    indexes = []
    new_values = []
    df = df.dropna(subset=[column])
    for i, presplit in enumerate(df[column].astype(str)):
        values = presplit.split(sep)
        if keep and len(values) > 1:
            indexes.append(i)
            new_values.append(presplit)
        for value in values:
            indexes.append(i)
            new_values.append(value)
    new_df = df.iloc[indexes, :].copy()
    new_df[column] = new_values
    return new_df

def previous_and_next(some_iterable):
    prevs, current, nexts = tee(some_iterable, 3)
    prevs = chain([None], prevs)
    nexts = chain(islice(nexts, 1, None), [None])
    return zip(prevs, current, nexts)


###########CREATION OF THE DATABASE MERGING FIRMS, ESSENTIAL PATENTS (all) AND STANDARDS

#####SCDB data final: database including only the information about standards, sso and their evolution over time (id variable common to all standard documents with a common version history)

### Standards grouped by version history

standards = pd.read_excel(os.path.join(DATA, "data da usare/SCDB_standards.xlsx"))
history = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_version_history.csv"),low_memory=False)
replacement = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_replacement.csv"),low_memory=False)

std_dic = {row['doc_idn']: row['doc_idn_versionhistory'] for _, row in history.iterrows()}
std_replacement = {row['doc_idn']: row['replaced_doc_idn'] for _, row in replacement.iterrows()}

standards['standard_project'] = standards['doc_idn'].map(std_dic)
standards['standard_replacement'] = standards['doc_idn'].map(std_replacement)
standards1 = standards.dropna(subset=['standard_project'])

#####STANDARD DATABASE for SSOs

##merging with table of correspondences with declarations
disc = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_discl_to_docidn.csv"),low_memory=False)
#standard_declared = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_discl_to_stand_doc.csv"),low_memory=False)

a = disc['doc_idn'].unique()
b = standards1['doc_idn'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]

disc1 = disc[disc.doc_idn.isin(kk)]
standards2  = standards1[standards1.doc_idn.isin(kk)]
disc2 = disc1[['disclosure_id', 'sso','doc_idn','letter_id', 'company_name', 'publicationyear', 'version','documentid','declaration_date']].drop_duplicates()
standards3 = standards2[['doc_idn', 'publicationyear', 'issuingbody', 'withdrawalyear','standard_project']]
std = pd.merge(disc2,standards3, on=['doc_idn','publicationyear'])

std3 = std.join(std['declaration_date'].str.split('-',expand=True).add_prefix('declaration_date'))
std4 = std3.drop(['declaration_date','declaration_date1','declaration_date2'],axis=1).drop_duplicates()
#std5 = std4.dropna(subset=['company_name'])

std_family = {row['standard_project']: row['documentid'] for _, row in std4.iterrows()}
std_family1 = {row['documentid']: row['standard_project'] for _, row in std4.iterrows()}

std4['standard_family'] = std4['standard_project'].map(std_family)
std4['standard_family1'] = std4['documentid'].map(std_family1)
std5 = std4[std4.sso=='IEEE']

prova = ['IEEE 802.15.4','IEEE 802.15.6','IEEE 802.15.3','IEEE 802.15.4a','IEEE 802.15.1','IEEE 802.15.3c','IEEE 802.15.7','IEEE 802.15.4', 'IEEE 802.15.5','IEEE 802.15.4g','IEEE 802.15.4m','IEEE 802.15.3b',
'IEEE 802.15.2','IEEE 802.15.4f']

std6 = std5[std5.documentid.isin(prova)]

###########CREATION OF THE DATABASE MERGING ESSENTIAL PATENTS AND STANDARDS FOR IPC CLASSES AND FIRMS

###Adding IPC classification and creating the standards patent portfolios
###File linking standard projects with the set of associated IPC codes.

test = std5[['standard_family1','disclosure_id','letter_id','company_name']].drop_duplicates()
p1 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_declared_number.csv"),low_memory=False)
test1 = pd.merge(test,p1,on=['disclosure_id','letter_id','company_name'])
p2 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_patn.csv"),low_memory=False)
test2 = pd.merge(test1,p2,on=['patstring_id'])
p3 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_patn_applicationnr.csv"),low_memory=False)
test3 = pd.merge(test2,p3,on=['patn'])
p4 = pd.read_csv(os.path.join(DATA, "data da usare/SCDB_patent_info.csv"),low_memory=False)
test4 = pd.merge(test3,p4,on=['application_nr'])

ipc1 = test4[['standard_family1','ipc_current']].drop_duplicates().fillna(0)

#ipc3 = ipc1[ipc1.ipc_current !=0]
ipc4 = tidy_split(ipc1,'ipc_current')
ipc4['ipc_current'] = ipc4['ipc_current'].map(lambda x: x.strip())
ipc4['ipc1'] = ipc4['ipc_current'].str[0:4]

a = ipc4['standard_family1'].unique()
b = std6['standard_family1'].unique()
kk = set(a).intersection(b)
ipc5 = ipc4[ipc4.standard_family1.isin(kk)]

data2 = ipc5

##IPC classes before 2015 (after 2015 is data2 since I have all the ipc classes declared)

ipc1 = test4[['standard_family1','ipc_current','declaration_date']].drop_duplicates().fillna(0)
a = data2.standard_family1.unique()
ipc3 = ipc1[ipc1.standard_family1.isin(a)]
#ipc3 = ipc1[ipc1.ipc_current !=0]
ipc4 = tidy_split(ipc3,'ipc_current')
ipc4['ipc_current'] = ipc4['ipc_current'].map(lambda x: x.strip())
ipc4['ipc1'] = ipc4['ipc_current'].str[0:4]
#ipc5 = ipc4[ipc4.declaration_date !=0]
ipc5 = ipc4
ipc6 = ipc5.join(ipc5['declaration_date'].str.split('-',expand=True).add_prefix('declaration_date'))
ipc7 = ipc6.drop(['declaration_date','declaration_date1','declaration_date2'],axis=1).drop_duplicates()
ipc7['declaration_date0'] = ipc7['declaration_date0'].fillna(0)
ipc7['year'] = ipc7['declaration_date0'].map(int)
ipc8 = ipc7[ipc7.year<2015]

ipc9 = ipc8.drop('ipc_current',axis=1).drop_duplicates()
ipc9.to_csv(os.path.join(DATA, "data da usare/standard patent portfolio_Bluetooth_before2015NEW.csv"))



#### STANDARDS INFORMATION and creation of the standards databases based on contributions before and after

##Selecting the standard families for which I have information about less than 25% of disclosures/ipc-current classes missing info and less than 10% of 4-digit IPC classes == 0
std7 = std6[std6.standard_family1.isin(a)]
#Creation of the dictionary for the 4 main standard projects in my sample
std_family2 = {'SCDB711219':'1394', 'SCDB806783': '1394', 'SCDB720029':'802.11', 'SCDB805653':'802.11', 'SCDB808954': '802.11', 'SCDB850960': '802.11', 'SCDB803404':'1666', 'SCDB808500': '802.16'}
std7['standard_family2'] = std7['standard_family1'].map(std_family2)

### Creating standards information using std7 
std7 = std7.dropna(subset=['declaration_date0'])

std7['year'] = std7['declaration_date0'].map(int)
std_info = std7.groupby(['year','standard_family1'])['disclosure_id', 'doc_idn', 'letter_id', 'company_name'].nunique().reset_index()

#Adding info about the number of SEPs declared per standard
a = std7.standard_family1.unique()
seps_info = test4[test4.standard_family1.isin(a)]
seps_info['standard_family2'] = seps_info['standard_family1'].map(std_family2)

seps_info1 = seps_info.join(seps_info['declaration_date'].str.split('-',expand=True).add_prefix('declaration_date'))
seps_info2 = seps_info1.drop(['declaration_date','declaration_date1','declaration_date2'],axis=1).drop_duplicates()
seps_info3 = seps_info2.dropna(subset=['declaration_date0'])
seps_info3['year'] = seps_info3['declaration_date0'].map(int)

seps_info4 = seps_info3.groupby(['year','standard_family1'])['patn'].nunique().reset_index()
std_info1 = pd.merge(std_info,seps_info4,on=['year','standard_family1'])

a = std_info1.standard_family1.unique()
std_info2 = pd.DataFrame()

for item in a:
    add = std_info1[std_info1.standard_family1 == item]
    add1 = add.sort_values("year")
    add1['sepTOTF'] = add1['patn'].cumsum()
    add1['sep_hld_TOTF'] = add1['company_name'].cumsum()
    add1['disclosure_id_TOTF'] = add1['disclosure_id'].cumsum()
    add1['doc_idn_TOTF'] = add1['doc_idn'].cumsum()
    add1['letter_id_TOTF'] = add1['letter_id'].cumsum()
    std_info2 = pd.concat([add1,std_info2],sort=True)


item = std_info2.standard_family1.unique()
std_final = pd.DataFrame()

for i in item:
    add = std_info2[std_info2.standard_family1==i]
    indeces = add.index.tolist()
    add1_master = pd.DataFrame()
    add2_master = pd.DataFrame()
    add3_master = pd.DataFrame()
    df0 = pd.DataFrame()
    for idx in indeces:
        if idx==min(indeces):
            add1 = add[add.index.isin([idx])]
            add1_master = pd.concat([add1,add1_master],axis=0,sort=True)
        elif idx==max(indeces):
            add2 = add[add.index.isin([idx])]
            add2_master = pd.concat([add2,add2_master],axis=0,sort=True)
        else:
            index_pre = indeces.index(idx) -1
            index_pre1 = indeces[index_pre]
            year_pre = add.loc[index_pre1, 'year']
            #index_post = indeces[idx] 
            year_post = add.loc[idx, 'year']
            if year_post == year_pre+1:
                add3 = add[add.year==year_post]
                add3_master = pd.concat([add3,add3_master],axis=0,sort=True)
            elif year_post != year_pre+1:
                lenght = year_post - year_pre
                years_new = list(range(year_pre+1,year_post+1))
                for y in years_new:
                    transition_df = add[add.year==year_pre]
                    add4 = pd.DataFrame({'year': [y], 'standard_family1': [i], 'disclosure_id': transition_df['disclosure_id'],'disclosure_id_TOTF': transition_df['disclosure_id_TOTF'],'doc_idn':transition_df['doc_idn'], 'doc_idn_TOTF':transition_df['doc_idn_TOTF'], 'letter_id_TOTF':transition_df['letter_id_TOTF'],'letter_id':transition_df['letter_id'], 'company_name':transition_df['company_name'],  'sep_hld_TOTF':transition_df['sep_hld_TOTF'],  'patn':transition_df['patn'],  'sepTOTF':transition_df['sepTOTF']})
                    df0 = pd.concat([add4,df0], axis=0,sort=True)
        df1 = pd.concat([add1_master,add2_master], axis=0,sort=True)
        df2 = pd.concat([add3_master,df1], axis=0,sort=True)
        df3 = pd.concat([df0,df2], axis=0,sort=True)
        std_final = pd.concat([df3,std_final], axis=0,sort=True)   

std_final.drop_duplicates(inplace=True)
std_final.to_csv(os.path.join(DATA, "data da usare/Bluetoothstandards_family_info.csv"))


a = std_final.standard_family1.unique()
ipc1 = test4[['standard_family1','ipc_current','patn']].drop_duplicates().fillna(0)
ipc1['standard_family2'] = ipc1['standard_family1'].map(std_family2)
ipc3 = ipc1[ipc1.standard_family1.isin(a)]
ipc4 = tidy_split(ipc3,'ipc_current')
ipc4['ipc_current'] = ipc4['ipc_current'].map(lambda x: x.strip())
ipc4['ipc1'] = ipc4['ipc_current'].str[0:4]
ipc5 = ipc4.drop('ipc_current',axis=1).drop_duplicates()
ipc6 = ipc5.groupby(['standard_family1','ipc1'])['patn'].nunique().reset_index()

item = ipc6.standard_family1.unique()
standard = pd.DataFrame()

for x in item:
    prova = ipc6[ipc6.standard_family1==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight'] = prova1['patn']/total
        standard = pd.concat([prova1,standard],axis=0,sort=True)

ipc7 = ipc6[ipc6.ipc1 != '0']
item = ipc7.standard_family1.unique()
standard0 = pd.DataFrame()

for x in item:
    prova = ipc7[ipc7.standard_family1==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight_w0'] = prova1['patn']/total
        standard0 = pd.concat([prova1,standard0],axis=0,sort=True)

standard_all = pd.merge(standard, standard0, on=['standard_family1','patn','ipc1'],how='left')
standard_all.to_csv(os.path.join(DATA, "data da usare/Bluetoothstandard_weighted classes.csv"))

####PATSTAT DATABASE of all FIRMS ---  (I need this information to then compute the cosine similarity in the pre-period, in post-period and the differences even if I do not know whether it makes sense)

####Firms declaring standard essential patents to IEEE
#Including info about company_id

pers = pd.read_excel(os.path.join(DATA, "data da usare/SCDB_ Firms names.xlsx"))
a = std7['company_name'].unique()
b = pers['company_name'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
pers2 = pers[pers.company_name.isin(kk)]
a = std7['company_name'].unique()
b = pers2['company_name'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
std8 = pd.merge(std7,pers2,on='company_name')


##Selecting the firms for which I am able to collect info on patstat (ipc, patn, appl date)

per = pd.read_csv(os.path.join(DATA, "data da usare/HanPer_id fin 1.1.1.csv"))
a = std8['company_id'].unique()
b = per['company_id'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
pr = per[per['company_id'].isin(kk)]

pat = pd.read_csv(os.path.join(DATA, "data da usare/Patstat cited new.csv"),low_memory=False)
a = pr['person_id'].unique()
b = pat['person_id'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
per4 = pr[pr.person_id.isin(kk)]
per5 = per4[['person_id','company_id']].drop_duplicates()

data = pd.merge(per5,pat,on='person_id',how='inner')
data1 = data.drop_duplicates()
agg = data1.loc[data1['appln_filing_year']!=9999]
data2 = agg[['company_id','appln_nr','appln_filing_year','appln_nr_original', 'ipc_class_symbol','cited_pat_publn_id']].drop_duplicates()
a = data2['company_id'].unique()
b = std8['company_id'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
#data3 = data2.loc[data2['appln_filing_year']>1999]
data2['family_proxy'] = (
    data2['company_id'].astype(str) + "_" +
    data2['appln_nr_original'].astype(str).fillna("") + "_" +
    data2['appln_filing_year'].astype(str)
)

df_sorted = data2.sort_values(by=['company_id','appln_filing_year'])
data3 = df_sorted.drop_duplicates(subset=['family_proxy'], keep='first')
data3['ipc1'] = data3['ipc_class_symbol'].str[0:4]
data3['year'] = data3['appln_filing_year'].map(int)
data3['patn'] = data3['appln_nr_original']
data3['citation'] = data3['cited_pat_publn_id']
daa3 = data3[['company_id', 'ipc1', 'year', 'patn','citation']].drop_duplicates()

####Creation of the patent portfolio for the similarity comparison

pat_port = daa3[daa3.year<2015]
pat_port1 = pat_port.groupby(['company_id','ipc1'])['patn'].count().reset_index().drop_duplicates()

item = pat_port1.company_id.unique()
firms_portfolio = pd.DataFrame()

for x in item:
    prova = pat_port1[pat_port1.company_id==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight'] = prova1['patn']/total
        firms_portfolio = pd.concat([prova1,firms_portfolio],axis=0,sort=True)

firms_portfolio.to_csv(os.path.join(DATA, "data da usare/firms_portfolio_for_similarity_Bluetooth.csv"))

###Collecting the set of ipc associated to each standard
#IEEE_ipc = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_IEEE.csv"))

daa3[['patn','citation']] = daa3[['patn','citation']].fillna(1)
da6 = daa3.fillna(0)
patot = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index()
da6['weight'] = da6['citation']
da1 = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index().drop_duplicates()
da2 = da6.groupby(['company_id','year','ipc1'])['weight'].sum().reset_index().drop_duplicates()
da3 = pd.merge(da1,da2,on=['company_id','year','ipc1'])
da3['patT_c'] = da3['patn']*da3['weight']

standard_weights = pd.read_csv(os.path.join(DATA, "data da usare/Bluetoothstandard_weighted classes.csv"))
standard_weights['weights_s'] = standard_weights['weight']
standard_weights['weights_s_w0'] = standard_weights['weight_w0']

a = da3['ipc1'].unique()
b = standard_weights['ipc1'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
da5 = da3[da3.ipc1.isin(kk)]
ipc_weight = standard_weights[['standard_family1','ipc1','weights_s','weights_s_w0']].drop_duplicates()
daa = pd.merge(ipc_weight,da5,on='ipc1').drop_duplicates()
daa['patn_ws'] = daa['patn']*daa['weights_s']
daa['patT_c_ws'] = daa['patT_c']*daa['weights_s']
daa['patn_ws_w0'] = daa['patn']*daa['weights_s_w0']
daa['patT_c_ws_w0'] = daa['patT_c']*daa['weights_s_w0']

daa1 = daa.groupby(['company_id','year','standard_family1'])['patT_c'].sum().reset_index().drop_duplicates()
daa2 = daa.groupby(['company_id','year','standard_family1'])['patn'].sum().reset_index().drop_duplicates()
daa11 = daa.groupby(['company_id','year','standard_family1'])['patn_ws'].sum().reset_index().drop_duplicates()
daa22 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws'].sum().reset_index().drop_duplicates()
daa110 = daa.groupby(['company_id','year','standard_family1'])['patn_ws_w0'].sum().reset_index().drop_duplicates()
daa220 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws_w0'].sum().reset_index().drop_duplicates()

daa111 = pd.merge(daa1,daa2,on=['company_id','year','standard_family1'])
daa222 = pd.merge(daa11,daa22,on=['company_id','year','standard_family1'])
daa333 = pd.merge(daa110, daa220, on=['company_id','year','standard_family1'])
daa0 = pd.merge(daa111,daa222,on=['company_id','year','standard_family1'])
daa3_new = pd.merge(daa333,daa0,on=['company_id','year','standard_family1'])


#proxy = std8[['company_id','standard_family1']].drop_duplicates()
#a = daa3['standard_family1'].unique()
#proxy1 = proxy[proxy.standard_family1.isin(a)]
#testf = pd.DataFrame()

#for i,z in zip(proxy1['company_id'],proxy1['standard_family1']):
#    test = daa3[daa3['company_id']==i]
#    test1 = test[test['standard_family1']==z]
#    testf = pd.concat([testf,test1],axis=0)


testf = daa3_new
df1 = pd.DataFrame()
a = testf.company_id.unique()

for item in a:
    test = testf[testf['company_id']== item]
    c = test.standard_family1.unique().tolist()
    d = test.year.unique()
    for x in d:
        test1 = test[test.year==x]
        e = test1.standard_family1.unique()
        if len(c)==len(e):
            print(x)
        else:
            f = [item for item in c if item not in e]
            for idx, val in enumerate(f):
                test2 = pd.DataFrame({'standard_family1':[val],'year':[x],'company_id': [item]})
                df1 = pd.concat([df1,test2],axis=0)

patstd = pd.concat([df1,testf],axis=0,sort=True)
patstd['patT_c'] = patstd['patT_c'].fillna(0)
patstd['patn'] = patstd['patn'].fillna(0)
patstd['patn_ws'] = patstd['patn_ws'].fillna(0)
patstd['patT_c_ws'] = patstd['patT_c_ws'].fillna(0)
patstd['patn_ws_w0'] = patstd['patn_ws_w0'].fillna(0)
patstd['patT_c_ws_w0'] = patstd['patT_c_ws_w0'].fillna(0)

patstd.to_csv(os.path.join(DATA, "data da usare/Bluetooth 10std patents.csv"))

a = patstd.company_id.unique()
patot1 = da3[da3.company_id.isin(a)]
patot2 = patot1.groupby(['company_id','year'])['patT_c'].sum().reset_index().drop_duplicates()
patot3 = patot1.groupby(['company_id','year'])['patn'].sum().reset_index().drop_duplicates()
patot4 = pd.merge(patot2,patot3,on=['company_id','year'])

patot4.to_csv(os.path.join(DATA, "data da usare/Bluetooth patents.csv"))

sep = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth 10std patents.csv"))
pat = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth patents.csv"))

sep1 = sep.drop('Unnamed: 0',axis=1).drop_duplicates()
sep1['patT_c']=sep1['patT_c'].map(int)

pat['patTOT_c'] = pat['patT_c']
pat['patTOT'] = pat['patn']
pat['patTOT_c']=pat['patTOT_c'].map(int)
pat1 = pat.drop(['patT_c','patn','Unnamed: 0'],axis=1)
df1 = pd.merge(pat1,sep1,on=['company_id','year'],how='outer')

df1['standard_family1'] = df1['standard_family1'].fillna(11)
tt = df1
tt1 = tt[tt.standard_family1==11]
tt2 = tt1
a = tt2['company_id'].unique()
df2 = pd.DataFrame()

for i in a:
    test = df1[df1['company_id']==i]
    mam = test.dropna()
    c = mam.standard_family1.unique().tolist()
    for idx, val in enumerate(c):
        test2 = test.fillna({'standard_family1':val})
        df2 = pd.concat([df2,test2],axis=0)

b = df1.company_id.unique()
c=[item for item in b if item not in a]
df3 = df1[df1.company_id.isin(c)]
df4 = pd.concat([df3,df2],axis=0,sort=True).drop_duplicates()
df4['patT_c'] = df4['patT_c'].fillna(0) 
df4['patn'] = df4['patn'].fillna(0) 
df4['patNS_c'] = df4['patTOT_c'] - df4['patT_c']
df4['patNS'] = df4['patTOT'] - df4['patn']


df4['sso'] = 'IEEE'
df4['POST'] = np.where(df4['year'] > 2014, 1, 0)
df4['TREAT_declaring'] = 1
df5 = df4[df4.standard_family1 != 11]
patenting_IEEE = df5

df5.to_csv(os.path.join(DATA, "data da usare/Bluetooth patents revised_all patents with weights.csv"))

##Creating the patent portfolio of firms before and after 2015

pat_port = daa3[['company_id','ipc1','year']].drop_duplicates()

pat_port_tot = daa3[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])
pat_port_before = daa3[daa3.year<2015]
pat_port_before1 = pat_port_before[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])

pat_port.to_csv(os.path.join(DATA, "data da usare/firms patent portfolio_Bluetooth.csv"))
pat_port_before1.to_csv(os.path.join(DATA, "data da usare/firms patent portfolio_Bluetooth_before2015.csv"))


###Firms active in the same industries as IEEE firms but with no SEPs

han_per_control = pd.read_csv(os.path.join(DATA, "data da usare/HanPer_id fin control.csv"))
pat = pd.read_csv(os.path.join(DATA, "data da usare/Patstat control cited.csv"),low_memory=False)

a = han_per_control['person_name_clean'].unique()
b = per['person_name_clean'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
per1 = han_per_control[han_per_control.person_name_clean.isin(c)]
a = per1['person_id'].unique()
b = pat['person_id'].unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]
per4 = per1[per1.person_id.isin(kk)]
per5 = per4[['person_id','company_id']].drop_duplicates()

data = pd.merge(per5,pat,on='person_id',how='inner')
data1 = data.drop_duplicates()
agg = data1.loc[data1['appln_filing_year']!=9999]
data2 = agg[['company_id','appln_nr','appln_filing_year','appln_nr_original', 'ipc_class_symbol','cited_pat_publn_id']].drop_duplicates()
#data3 = data2.loc[data2['appln_filing_year']>1999]
data2['family_proxy'] = (
    data2['company_id'].astype(str) + "_" +
    data2['appln_nr_original'].astype(str).fillna("") + "_" +
    data2['appln_filing_year'].astype(str)
)

df_sorted = data2.sort_values(by=['company_id','appln_filing_year'])
data3 = df_sorted.drop_duplicates(subset=['family_proxy'], keep='first')
data3['ipc1'] = data3['ipc_class_symbol'].str[0:4]
data3['year'] = data3['appln_filing_year'].map(int)
data3['patn'] = data3['appln_nr_original']
data3['citation'] = data3['cited_pat_publn_id']
daa3 = data3[['company_id', 'ipc1', 'year', 'patn','citation']].drop_duplicates()


####Creation of the patent portfolio for the similarity comparison

pat_port = daa3[daa3.year<2015]
pat_port1 = pat_port.groupby(['company_id','ipc1'])['patn'].count().reset_index().drop_duplicates()

item = pat_port1.company_id.unique()
firms_portfolio = pd.DataFrame()

for x in item:
    prova = pat_port1[pat_port1.company_id==x]
    ipc_class = prova.ipc1.unique().tolist()
    for y in ipc_class:
        prova1 = prova[prova.ipc1==y]
        total = prova['patn'].sum()
        prova1['weight'] = prova1['patn']/total
        firms_portfolio = pd.concat([prova1,firms_portfolio],axis=0,sort=True)

firms_portfolio.to_csv(os.path.join(DATA, "data da usare/firms_portfolio_for_similarity_others_Bluetooth.csv"))

###Collecting the set of ipc associated to each standard

daa3[['patn','citation']] = daa3[['patn','citation']].fillna(1)
da6 = daa3.fillna(0)
patot = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index()
da6['weight'] = da6['citation']
da1 = da6.groupby(['company_id','year','ipc1'])['patn'].count().reset_index().drop_duplicates()
da2 = da6.groupby(['company_id','year','ipc1'])['weight'].sum().reset_index().drop_duplicates()
da3 = pd.merge(da1,da2,on=['company_id','year','ipc1'])
da3['patT_c'] = da3['patn']*da3['weight']

standard_weights = pd.read_csv(os.path.join(DATA, "data da usare/Bluetoothstandard_weighted classes.csv"))
standard_weights['weights_s'] = standard_weights['weight']
standard_weights['weights_s_w0'] = standard_weights['weight_w0']

a = da3['ipc1'].unique()
b = standard_weights['ipc1'].unique()
kk = set(a).intersection(b)
c=[item for item in b if item not in kk]
da5 = da3[da3.ipc1.isin(kk)]
ipc_weight = standard_weights[['standard_family1','ipc1','weights_s','weights_s_w0']].drop_duplicates()
daa = pd.merge(ipc_weight,da5,on='ipc1').drop_duplicates()
daa['patn_ws'] = daa['patn']*daa['weights_s']
daa['patT_c_ws'] = daa['patT_c']*daa['weights_s']
daa['patn_ws_w0'] = daa['patn']*daa['weights_s_w0']
daa['patT_c_ws_w0'] = daa['patT_c']*daa['weights_s_w0']

daa1 = daa.groupby(['company_id','year','standard_family1'])['patT_c'].sum().reset_index().drop_duplicates()
daa2 = daa.groupby(['company_id','year','standard_family1'])['patn'].sum().reset_index().drop_duplicates()
daa11 = daa.groupby(['company_id','year','standard_family1'])['patn_ws'].sum().reset_index().drop_duplicates()
daa22 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws'].sum().reset_index().drop_duplicates()
daa110 = daa.groupby(['company_id','year','standard_family1'])['patn_ws_w0'].sum().reset_index().drop_duplicates()
daa220 = daa.groupby(['company_id','year','standard_family1'])['patT_c_ws_w0'].sum().reset_index().drop_duplicates()

daa111 = pd.merge(daa1,daa2,on=['company_id','year','standard_family1'])
daa222 = pd.merge(daa11,daa22,on=['company_id','year','standard_family1'])
daa333 = pd.merge(daa110, daa220, on=['company_id','year','standard_family1'])
daa0 = pd.merge(daa111,daa222,on=['company_id','year','standard_family1'])
daa3_new = pd.merge(daa333,daa0,on=['company_id','year','standard_family1'])

df1 = pd.DataFrame()
a = daa3_new.company_id.unique()

for item in a:
    test = daa3_new[daa3_new['company_id']== item]
    c = test.standard_family1.unique().tolist()
    d = test.year.unique()
    for x in d:
        test1 = test[test.year==x]
        e = test1.standard_family1.unique()
        if len(c)==len(e):
            print(x)
        else:
            f = [item for item in c if item not in e]
            for idx, val in enumerate(f):
                test2 = pd.DataFrame({'standard_family1':[val],'year':[x],'company_id': [item]})
                df1 = pd.concat([df1,test2],axis=0)

patstd = pd.concat([df1,daa3_new],axis=0,sort=True)
patstd['patT_c'] = patstd['patT_c'].fillna(0)
patstd['patn'] = patstd['patn'].fillna(0)
patstd['patn_ws'] = patstd['patn_ws'].fillna(0)
patstd['patT_c_ws'] = patstd['patT_c_ws'].fillna(0)
patstd['patn_ws_w0'] = patstd['patn_ws_w0'].fillna(0)
patstd['patT_c_ws_w0'] = patstd['patT_c_ws_w0'].fillna(0)

patstd.to_csv(os.path.join(DATA, "data da usare/Others Bluetooth patents.csv"))

a = patstd.company_id.unique()
patot1 = da3[da3.company_id.isin(a)]
patot2 = patot1.groupby(['company_id','year'])['patT_c'].sum().reset_index().drop_duplicates()
patot3 = patot1.groupby(['company_id','year'])['patn'].sum().reset_index().drop_duplicates()
patot4 = pd.merge(patot2,patot3,on=['company_id','year'])

patot4.to_csv(os.path.join(DATA, "data da usare/Others patents Bluetooth.csv"))

sep = pd.read_csv(os.path.join(DATA, "data da usare/Others Bluetooth patents.csv"))
pat = pd.read_csv(os.path.join(DATA, "data da usare/Others patents Bluetooth.csv"))

sep1 = sep.drop('Unnamed: 0',axis=1).drop_duplicates()
sep1['patT_c']=sep1['patT_c'].map(int)

##Adding patenting behavior 

pat['patTOT_c'] = pat['patT_c']
pat['patTOT'] = pat['patn']
pat['patTOT_c']=pat['patTOT_c'].map(int)
pat1 = pat.drop(['patT_c','patn','Unnamed: 0'],axis=1)
df1 = pd.merge(pat1,sep1,on=['company_id','year'],how='outer')

df1['standard_family1'] = df1['standard_family1'].fillna(11)
tt = df1
tt1 = tt[tt.standard_family1==11]
tt2 = tt1
a = tt2['company_id'].unique()
df2 = pd.DataFrame()

for i in a:
    test = df1[df1['company_id']==i]
    mam = test.dropna()
    c = mam.standard_family1.unique().tolist()
    for idx, val in enumerate(c):
        test2 = test.fillna({'standard_family1':val})
        df2 = pd.concat([df2,test2],axis=0)

b = df1.company_id.unique()
c=[item for item in b if item not in a]
df3 = df1[df1.company_id.isin(c)]
df4 = pd.concat([df3,df2],axis=0,sort=True).drop_duplicates()
df4['patT_c'] = df4['patT_c'].fillna(0) 
df4['patn'] = df4['patn'].fillna(0) 
df4['patNS_c'] = df4['patTOT_c'] - df4['patT_c']
df4['patNS'] = df4['patTOT'] - df4['patn']

df4['sso'] = 'IEEE'
df4['POST'] = np.where(df4['year'] > 2014, 1, 0)
df4['TREAT_declaring'] = 0
df5 = df4[df4.standard_family1 != 11]
patenting_others = df5

patenting_others.to_csv(os.path.join(DATA, "data da usare/Bluetooth Others patents revised_all patents with weights.csv"))

##Creating the patent portfolio of firms before and after 2015

pat_port = daa3[['company_id','ipc1','year']].drop_duplicates()

pat_port_tot = daa3[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])
pat_port_before = daa3[daa3.year<2015]
pat_port_before1 = pat_port_before[['company_id','ipc1']].drop_duplicates().dropna(subset=['ipc1'])

pat_port.to_csv(os.path.join(DATA, "data da usare/others patent portfolio_Bluetooth.csv"))
pat_port_before1.to_csv(os.path.join(DATA, "data da usare/others patent portfolio_Bluetooth_before2015.csv"))



###MEASURING THE TECHNOLOGY DISTANCE

control_before = pd.read_csv(os.path.join(DATA, "data da usare/others patent portfolio_Bluetooth_before2015.csv"))
treat_before = pd.read_csv(os.path.join(DATA, "data da usare/firms patent portfolio_Bluetooth_before2015.csv"))
standard_before = pd.read_csv(os.path.join(DATA, "data da usare/standard patent portfolio_Bluetooth_before2015NEW.csv"))

firms = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth patents revised_all patents with weights.csv"))
others = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth Others patents revised_all patents with weights.csv"))
final = pd.read_csv(os.path.join(DATA, "data da usare/Total firms clean FINAL.csv"))

firms1 = firms[['company_id','standard_family1']].drop_duplicates()
others1 = others[['company_id','standard_family1']].drop_duplicates()
pr =  pd.concat([firms1,others1],axis=0,sort=True)
a = final.company_id.unique()
prova = pr[pr.company_id.isin(a)]

sample = pd.concat([treat_before,control_before],axis=0,sort=True)
standard_before1 = standard_before[['standard_family1','ipc1']].drop_duplicates()
standard_before2 = standard_before1[standard_before1.ipc1 != '0']
a = prova.standard_family1.unique()
std = standard_before2[standard_before2['standard_family1'].isin(a)]
a = std.standard_family1.unique()
prova1 = prova[prova.standard_family1.isin(a)]
pair = prova1[['company_id','standard_family1']].drop_duplicates()
a = sample.company_id.unique()
pair1 = pair[pair.company_id.isin(a)]
b = pair.company_id.unique()
sample1 = sample[sample.company_id.isin(b)]

std2 = std[['ipc1']].drop_duplicates()
std2['standard_family1'] = 'all'
item = sample1.company_id.unique()
techn = pd.DataFrame()

for x in item:
    pr = sample1[sample1['company_id']==x]
    tt = std2
    prova1 = pd.merge(pr,tt,on=['ipc1'],how='outer')
    prova1['comn'] = np.where(prova1['company_id']==x,1,0)
    prova1['std'] = np.where(prova1['standard_family1']=='all',1,0)
    transpose = prova1.set_index('ipc1').T
    dataSetI = np.array([transpose.iloc[3]])
    dataSetII = np.array([transpose.iloc[4]])
    result = cosine_similarity(dataSetI,dataSetII)
    result1 = result[0][0]
    tt3 = pd.DataFrame({'company_id':x,'standard_family1':'all','TECH_before':[result1]})
    techn = pd.concat([techn,tt3],axis=0,sort=True)

techn.to_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEWBluetooth.xlsx"))

##Adding patenting behaviors

tech_sim = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEWBluetooth.xlsx"))
patenting_others = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth Others patents revised_all patents with weights.csv"))
patenting_firms = pd.read_csv(os.path.join(DATA, "data da usare/Bluetooth patents revised_all patents with weights.csv"))
firms_charact1 = pd.read_csv(os.path.join(DATA, "data da usare/Total firms clean FINAL.csv"))

pat_others = patenting_others.drop_duplicates()
pat_firms = patenting_firms.drop_duplicates()
sample_all = pd.concat([pat_others,pat_firms],axis=0,sort=True)
tech_sim.drop('standard_family1',axis=1,inplace=True)
sample_all1 = pd.merge(sample_all, tech_sim, on=['company_id'])
#sample_all2 = pd.merge(sample_all1,firms_charact1,on=['company_id','year'],how='right')

sample_right_years = sample_all1[sample_all1.year>2009]
sample_right_years1 = sample_right_years[sample_right_years.year<2019]
prova = sample_right_years1.groupby(['company_id','standard_family1'])['year'].nunique().reset_index()
prova1 = prova[prova.year>3]
prova2 = prova1[['company_id','standard_family1']].drop_duplicates()
sample_final_patenting = pd.merge(prova2,sample_right_years1,on=['company_id','standard_family1'])

add = sample_final_patenting[sample_final_patenting.year>2014]
a = add.company_id.unique()
sample_patenting = sample_final_patenting[sample_final_patenting.company_id.isin(a)]

##Merging infor about firms

fn = pd.merge(sample_patenting,firms_charact1,on=['company_id','year'], how='right')
fn[['patNS','patNS_c','patTOT', 'patTOT_c','patT_c','patT_c_ws','patT_c_ws_w0','patn','patn_ws','patn_ws_w0']] = fn[['patNS','patNS_c','patTOT', 'patTOT_c','patT_c','patT_c_ws','patT_c_ws_w0','patn','patn_ws','patn_ws_w0']].fillna(0)
fn['sso']  = fn['sso'].fillna('IEEE')

prova = fn[fn.year<2015]
prova1 = fn[fn.year>2014]
a = prova['company_id'].unique()
b = prova1['company_id'].unique()
kk = set(a).intersection(b)
final = fn[fn.company_id.isin(kk)]

df = pd.DataFrame()
company = final.company_id.unique()

for x in company:
    add = final[final.company_id==x]
    add1 = add.sort_values("year")
    year = add1.year.unique()
    prova = add1.dropna(subset=['standard_family1'])
    min_year_std = prova.year.min()
    for y in year:
        if y == min_year_std:
            add2 = add1[add1.year==y]
            df = pd.concat([df,add2], axis=0,sort=True)
        else:
            add3 = add1[add1.year==min_year_std]
            std_family1 = add1.standard_family1.unique()
            std_family = [x for x in std_family1 if str(x) != 'nan']
            add4 = add1[add1.year==y]
            standard = add4.standard_family1.unique()
            standard1 = standard[0]
            df_add = pd.DataFrame()
            if str(standard1) != 'nan':
                df = pd.concat([df,add4],axis=0,sort=True)
            else:
                for s in std_family:
                    add5 = add1[add1.year==y]
                    add5['standard_family1'] = add5['standard_family1'].fillna(s)
                    a = add3['TREAT_declaring'].unique()
                    aa = a[0]
                    add5['TREAT_declaring'] = add5['TREAT_declaring'].fillna(aa)
                    b = add3['TECH_before'].unique()
                    bb =  b[0]
                    add5['TECH_before'] = add5['TECH_before'].fillna(bb)
                    df_add = pd.concat([df_add,add5],axis=0,sort=True)
                df = pd.concat([df, df_add], axis=0, sort=True)

            
df1 = df.dropna(subset=['standard_family1'])


##Adding standards information

std = pd.read_csv(os.path.join(DATA, "data da usare/Bluetoothstandards_family_info.csv"))

age = std7[['standard_family1','publicationyear']].drop_duplicates()

a = std7.standard_family1.unique()
age_min = pd.DataFrame()

for x in a:
    add = age[age.standard_family1==x]
    min_year = add.publicationyear.min()
    add1 = add[add.publicationyear==min_year]
    age_min = pd.concat([age_min,add1], axis=0, sort= True)

age_min['standard_family1'] = age_min['standard_family1'].map(float)
df_age = pd.merge(age_min,std, on=['standard_family1'])
df_age['Sage'] = df_age['year'] - df_age['publicationyear']

tot_ipc_peryear = ipc7.groupby(['standard_family1','year'])['ipc1'].nunique().reset_index()

ipc_tot = ipc7[['standard_family1','year','ipc1']].drop_duplicates()
ipc_tot1 = ipc_tot[ipc_tot.ipc1 != '0']
a = ipc_tot1.standard_family1.unique()
tot_ipc_cumsum = pd.DataFrame()
tot_ipc_cumsum1 = pd.DataFrame()

for x in a:
    add = ipc_tot1[ipc_tot1.standard_family1 == x]
    add1 = add.sort_values("year")
    year = add1.year.unique()
    for previous, current, nxt in previous_and_next(year):
        if current ==  min(year):
            add2 = add1[add1.year==current]
            add3 = add2.groupby(['standard_family1','year'])['ipc1'].nunique().reset_index()
            tot_ipc_cumsum = pd.concat([tot_ipc_cumsum,add3],axis=0,sort=True)
        else:
            add4 = add1[add1.year==previous]
            add5 = add1[add1.year==current]
            e = add4.ipc1.unique()
            c = add5.ipc1.unique()
            f = [item for item in c if item not in e]
            add6 = add5[add5.ipc1.isin(f)]
            add7 = add6.groupby(['standard_family1','year'])['ipc1'].nunique().reset_index()
            tot_ipc_cumsum = pd.concat([tot_ipc_cumsum,add7],axis=0,sort=True)
        tot_ipc_cumsum['ipc_cumsum'] = tot_ipc_cumsum['ipc1'].cumsum()
        tot_ipc_cumsum1 = pd.concat([tot_ipc_cumsum,tot_ipc_cumsum1],axis=0,sort=True)
    
tot_ipc_cumsum1.drop_duplicates(inplace=True)
tot_ipc_cumsum1['year'] = tot_ipc_cumsum1['year'].map(int)
tot_ipc_cumsum_final = pd.DataFrame()

for x in a:
    add = tot_ipc_cumsum1[tot_ipc_cumsum1.standard_family1 == x]
    add1 = add.sort_values("year")
    year = add1.year.unique()
    for previous, current, nxt in previous_and_next(year):
        if current ==  min(year):
            add2 = add1[add1.year==current]
            tot_ipc_cumsum_final = pd.concat([tot_ipc_cumsum_final,add2],axis=0,sort=True)
        else:
            if current == previous + 1:
                add3 = add1[add1.year==current]
                tot_ipc_cumsum_final = pd.concat([tot_ipc_cumsum_final,add3],axis=0,sort=True)
            else:
                add4 = add1[add1.year==previous]
                add5 = add1[add1.year==current]
                diff = current - previous
                new_years = list(range(previous+1, current))
                tot_ipc_cumsum_final = pd.concat([tot_ipc_cumsum_final,add5],axis=0,sort=True)
                for y in new_years:
                    new_df = pd.DataFrame({'ipc1': add4['ipc1'], 'ipc_cumsum': add4['ipc_cumsum'], 'standard_family1': [x], 'year': [y]})
                    tot_ipc_cumsum_final = pd.concat([tot_ipc_cumsum_final,new_df],axis=0,sort=True)

b = tot_ipc_cumsum_final.standard_family1.unique()
df_age1 = df_age[df_age.standard_family1.isin(b)]
tot_ipc_cumsum_final['standard_family2'] = tot_ipc_cumsum_final['standard_family1'].map(float)
std_info_new = pd.merge(df_age1, tot_ipc_cumsum_final, on=['standard_family1','year'], how='left') 
std_info_new['ipc1'] = std_info_new['ipc1'].fillna(0)
std_info_new['ipc_cumsum'] = std_info_new['ipc_cumsum'].fillna(0)

a = std_info_new.standard_family1.unique()
std_info_new1 = pd.DataFrame()

for x in a:
    add = std_info_new[std_info_new.standard_family1 == x]
    add1 = add.sort_values("year")
    year = add1.year.unique()
    for y in year:
        if y< max(year):
            add2 = add1[add1.year==y]
            std_info_new1 = pd.concat([std_info_new1,add2],axis=0,sort=True)
        else:
            add3 = add1[add1.year==y]
            new_years = list(range(y+1, 2018))
            std_info_new1 = pd.concat([std_info_new1,add3],axis=0,sort=True)
            for yrs in new_years:
                new_df = pd.DataFrame({'ipc1': add3['ipc1'], 'ipc_cumsum': add3['ipc_cumsum'], 'standard_family1': [x], 'year': [yrs], 'publicationyear': add3['publicationyear'],'company_name': add3['company_name'],'disclosure_id': add3['disclosure_id'],'disclosure_id_TOTF': add3['disclosure_id_TOTF'], 'doc_idn': add3['doc_idn'],'doc_idn_TOTF': add3['doc_idn_TOTF'],'letter_id': add3['letter_id'],'letter_id_TOTF':add3['letter_id_TOTF'],'patn': add3['patn'], 'sepTOTF':add3['sepTOTF'],'sep_hld_TOTF':add3['sep_hld_TOTF']})
                std_info_new1 = pd.concat([std_info_new1,new_df],axis=0,sort=True)

std_info_new1.drop(['Unnamed: 0','Sage'],axis=1,inplace=True)

#final = pd.read_csv(os.path.join(DATA, "data da usare/Final database lag 1.csv"))

a = std_info_new1.standard_family1.unique()
finall = final[final.standard_family1.isin(a)]

final1 = pd.merge(finall,std_info_new1, on=['standard_family1','year'],how='left').drop_duplicates()
final2 = pd.DataFrame()

for item in a:
    add1 = final1[final1.standard_family1==item]
    if item == 'SCDB803404':
        b = add1.publicationyear.unique()
        pub_year = b[1]
        add1['publicationyear'] = add1['publicationyear'].fillna(pub_year)
        final2 = pd.concat([final2,add1],axis=0,sort=True)
    else:
        b = add1.publicationyear.unique()
        pub_year = b[0]
        add1['publicationyear'] = add1['publicationyear'].fillna(pub_year)
        final2 = pd.concat([final2,add1],axis=0,sort=True)


final2['Sage'] = final2['year'] - final2['publicationyear']
final2[['company_name', 'disclosure_id', 'disclosure_id_TOTF',
       'doc_idn', 'doc_idn_TOTF', 'letter_id', 'letter_id_TOTF', 'patn_y',
       'sepTOTF', 'sep_hld_TOTF','ipc1','ipc_cumsum']] = final2[['company_name', 'disclosure_id', 'disclosure_id_TOTF',
       'doc_idn', 'doc_idn_TOTF', 'letter_id', 'letter_id_TOTF', 'patn_y',
       'sepTOTF', 'sep_hld_TOTF','ipc1','ipc_cumsum']].fillna(0)


final2.to_csv(os.path.join(DATA, "data da usare/Final database lag 1_Bluetooth.csv"))

a = final2.company_id.unique()
b = df1.company_id.unique()
kk = set(a).intersection(b)
c=[item for item in a if item not in kk]

df2 = df1[df1.company_id.isin(kk)]
df3 = df2.drop(['S1','M1','L1','G1','POST','Unnamed: 0', 'Unnamed: 0.1', 'Unnamed: 0.1.1','Unnamed: 0_x', 'Unnamed: 0_y'], axis=1)
df3['POST'] = np.where(df3.year>2014,1,0)

a = df3.company_id.unique()
size = pd.DataFrame()

for i in a :
    test = df3[df3['company_id']==i]
    test2 = test[test.E == test.E.max()]
    size = pd.concat([size,test2],axis=0)

size1 = size[['company_id','E']].drop_duplicates()
size1['S1'] = np.where(size1['E'] <= 1.000, 1, 0)
size1['M1'] = np.where(((size1['E']  > 1.000) & (size1['E'] <= 10.000)), 1, 0)
size1['L1'] = np.where(((size1['E'] > 10.000)&(size1['E'] <= 100.000)), 1, 0)
size1['G1'] = np.where(size1['E'] > 100.000, 1, 0)
size1.drop('E',axis=1, inplace=True)

df4 = pd.merge(df3,size1,on=['company_id'],how='left')

add_std_info = final2.drop(['Unnamed: 0', 'E', 'G1', 'L1', 'M1', 'POST', 'RD', 'S1', 'SALE',
       'TECH_before', 'TREAT_declaring', 'Unnamed: 0.1', 'Unnamed: 0.1.1',
        'Unnamed: 0_x', 'Unnamed: 0_y', 'company_id',
        'curcd', 'inv_', 'inv_prop',  'loc', 'naics', 'patNS', 'patNS_c',
       'patTOT', 'patTOT_c', 'patT_c', 'patT_c_ws', 'patT_c_ws_w0', 'patn_ws',
       'patn_ws_w0',  'sso', 'year-1', 'year-2','patn_x','patn_y'], axis=1).drop_duplicates()

df5 = pd.merge(df4, add_std_info, on=['standard_family1','year']).drop_duplicates()
df5.to_csv(os.path.join(DATA, "data da usare/Final database lag 1_Bluetoothfirms.csv"))

final = pd.read_csv(os.path.join(DATA, "data da usare/Final database lag 1_Bluetoothfirms.csv"))

final['TREAT'] = 1 + final['TECH_before']
#final['interaction'] = final['TREAT']*final['POST']
final['interaction'] = (final['TREAT'])*np.log(1+final['quart_tehc'])*final['POST']
final['interaction_check'] = final['TECH_before']*final['POST']
final['logPat'] = np.log(final['patn_ws']+1)
final['logPat_w0'] = np.log(final['patn_ws_w0']+1)
pd.get_dummies(final, 'standard_family1')
final['standards'] = pd.Categorical(final.standard_family1).codes
final['firms'] = pd.Categorical(final.company_id)
final['combination'] = final[['company_id','standard_family1']].agg(tuple, axis=1)
final['firms-standard-pair'] = final['combination'].factorize()[0]
final['logSALE'] = np.log(final['SALE']+1)
final['logPat_NS'] = np.log(final['patNS']+1)
final['logPat_cit'] = np.log(final['patT_c_ws']+1)
final['logPatTOT'] = np.log(final['patTOT']+1)
final['logRD'] = np.log(final['RD']+1)
final['logRD2'] = final['logRD']*final['logRD']

prova = final[final.year<2015]
mean_pat = prova['patn_ws'].mean()
prova1 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patn_ws'].mean().reset_index()
prova2 = prova.groupby(['year','company_id', 'standard_family1'], as_index=False).mean().groupby(['year','company_id'],as_index=False).mean().groupby('company_id')['patT_c_ws'].mean().reset_index()
prova1['patn_mean_before'] = prova1['patn_ws']
prova1.drop('patn_ws',axis=1,inplace=True)
prova2['patn_mean_before_cited'] = prova2['patT_c_ws']
prova2.drop('patT_c_ws',axis=1,inplace=True)

sample_final1 = pd.merge(final,prova1,on=['company_id'])
sample_final2 = pd.merge(sample_final1,prova2,on=['company_id'])
sample_final2['patn_nomr'] = sample_final2['patn_ws']/sample_final2['patn_mean_before']
sample_final2['patc_nomr'] = sample_final2['patT_c_ws']/sample_final2['patn_mean_before_cited']
sample_final2['logPatn'] = np.log(sample_final2['patn_nomr']+1)
sample_final2['logPatn'] = sample_final2['logPatn'].replace([np.inf, -np.inf], 0)

business_model = pd.read_csv(os.path.join(DATA, "data da usare/dic_lic_lic187.csv"))
sample_final3 = pd.merge(sample_final2, business_model,on=['company_id'], how='left')

tech_sim_var = pd.read_excel(os.path.join(DATA, "data da usare/tech similarity before 2015_allNEWBluetooth.xlsx"))
tech_sim_var['TECH_before_var'] = tech_sim_var['TECH_before']
tech_sim_var1 = tech_sim_var[['company_id', 'standard_family1','TECH_before_var']].drop_duplicates()
sample_final4 = sample_final3
#sample_final5 = pd.merge(sample_final4,tech_sim_var1,on=['company_id','standard_family1'])
sample_final5 = sample_final4


###543 is the number of firms that have data post 2014 but also before 2014, so more than 1 year in the pre period!!!! THIS IS THE ONE

prova =  sample_final5[sample_final5.year<2014]
a = prova.company_id.unique()

sample_final6 = sample_final5[sample_final5.company_id.isin(a)]
sample_final6.to_csv(os.path.join(DATA, "data da usare/final_lag1_TECHallBluetooth.csv"))



