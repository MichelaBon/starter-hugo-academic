Place the original data here (see README.md, Data availability).
The scripts expect the subfolders 'data da usare/' and 'PATSTAT/'.
